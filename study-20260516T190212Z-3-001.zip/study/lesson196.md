# Bài 196 — GraphQL Basics

## 1. Intro

GraphQL - query language cho APIs, linh hoạt hơn REST

## 2. Code

```python
from flask import Flask
from flask_graphql import GraphQLView
import graphene

class Query(graphene.ObjectType):
    hello = graphene.String(name=graphene.String(default_value="World"))
    
    def resolve_hello(self, info, name):
        return f"Hello {name}!"

class Mutation(graphene.ObjectType):
    create_user = graphene.Field(User, name=graphene.String(required=True))
    
    def resolve_create_user(self, info, name):
        return User(name=name)

schema = graphene.Schema(query=Query, mutation=Mutation)

app = Flask(__name__)
app.add_url_rule("/graphql", view_func=GraphQLView.as_view("graphql", schema=schema))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 196 / 2000 |
| **XP** | 1960 |