# Bài 408 — Postorder Traversal (Easy)

## 1. Ôn tập

Từ bài 407, ta đã học Preorder Traversal. Hôm nay ta học **Postorder Traversal**!

## 2. Mục tiêu bài học

- Postorder: left → right → root
- Recursive và iterative
- Xóa tree, topological sort

## 3. Code chính (có comment)

```python
# Recursive
def postorder_recursive(root):
    result = []
    
    def postorder(node):
        if not node:
            return
        postorder(node.left)
        postorder(node.right)
        result.append(node.val)
    
    postorder(root)
    return result

# Iterative
def postorder_iterative(root):
    if not root:
        return []
    
    result = []
    stack = []
    current = root
    
    while stack or current:
        if current:
            stack.append(current)
            current = current.left
        else:
            peek = stack[-1]
            if peek.right and peek.right != current:
                current = peek.right
            else:
                result.append(peek.val)
                stack.pop()
                current = None
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 408 / 2000 |
| **Chapter** | Trees |
| **XP** | 4080 |