# Bài 199 — Performance Monitoring

## 1. Tools

- cProfile: Code profiling
- memory_profiler: Memory usage
- time: Timing
- sentry: Error tracking

## 2. Code

```python
import cProfile
import pstats
from io import StringIO

def profile_function(func):
    profiler = cProfile.Profile()
    profiler.enable()
    
    result = func()
    
    profiler.disable()
    
    s = StringIO()
    ps = pstats.Stats(profiler, stream=s).sort_stats('cumulative')
    ps.print_stats(10)  # Top 10
    print(s.getvalue())
    
    return result

# Usage
profile_function(heavy_function)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 199 / 2000 |
| **XP** | 1990 |