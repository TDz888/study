# Bài 178 — itertools Advanced

## 1. Ôn tập

Ta đã dùng itertools ở bài 129-131. Hôm nay ta học advanced functions!

## 2. Mục tiêu bài học

- islice, takewhile, dropwhile
- cycle, repeat
- compress, filterfalse

## 3. Code chính (có comment)

```python
from itertools import islice, takewhile, dropwhile, cycle, repeat, compress, filterfalse

# islice - cắt generator
print(list(islice(range(10), 3)))           # [0, 1, 2]
print(list(islice(range(10), 2, 5)))         # [2, 3, 4]
print(list(islice(range(10), 0, 10, 2)))     # [0, 2, 4, 6, 8] (step)

# takewhile - lấy cho đến khi False
print(list(takewhile(lambda x: x < 5, range(10))))  # [0, 1, 2, 3, 4]

# dropwhile - bỏ cho đến khi False
print(list(dropwhile(lambda x: x < 5, range(10))))  # [5, 6, 7, 8, 9]

# cycle - lặp lại vô hạn
print(list(islice(cycle([1, 2, 3]), 7)))  # [1, 2, 3, 1, 2, 3, 1]

# repeat - lặp lại một giá trị
print(list(islice(repeat(5), 3)))  # [5, 5, 5]

# compress - lọc theo selector
print(list(compress('ABC', [1, 0, 1])))  # ['A', 'C']

# filterfalse - ngược filter thường
print(list(filterfalse(lambda x: x % 2 == 0, range(5))))  # [1, 3]
```

## 4. Trace chạy code

```
[0, 1, 2]
[2, 3, 4]
[0, 2, 4, 6, 8]
[0, 1, 2, 3, 4]
[5, 6, 7, 8, 9]
[1, 2, 3, 1, 2, 3, 1]
[5, 5, 5]
['A', 'C']
[1, 3]
```

## 5. Ghi nhớ nhanh

| Function | Công dụng |
|----------|-----------|
| `islice(gen, start, stop, step)` | Cắt generator |
| `takewhile(pred, gen)` | Lấy khi True |
| `dropwhile(pred, gen)` | Bỏ khi True |
| `cycle(gen)` | Lặp lại |
| `repeat(val)` | Lặp giá trị |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 178 / 2000 |
| **XP** | 1780 |