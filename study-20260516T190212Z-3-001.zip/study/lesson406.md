# Bài 406 — Average of Levels (Easy)

## 1. Ôn tập

Từ bài 405, ta đã học Zigzag Level Order. Hôm nay ta học **Average of Levels**!

## 2. Mục tiêu bài học

- Tính average của mỗi level
- BFS với sum và count
- O(n)

## 3. Code chính (có comment)

```python
from collections import deque

def average_of_levels(root):
    """
    Average of Levels
    Input: Tree
    Output: [3.0, 14.5, 11.0]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_sum = 0
        level_size = len(queue)
        
        for _ in range(level_size):
            node = queue.popleft()
            level_sum += node.val
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level_sum / level_size)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 406 / 2000 |
| **Chapter** | Trees |
| **XP** | 4060 |