# Bài 344 — Best Time to Buy and Sell Stock II (Medium)

## 1. Ôn tập

Từ bài 343, ta đã học LIS. Hôm nay ta học **Best Time to Buy and Sell Stock II**!

## 2. Mục tiêu bài học

- Unlimited transactions
- Sum tất cả positive differences
- Greedy

## 3. Code chính (có comment)

```python
def max_profit(prices):
    """
    Max Profit II
    Input: [7,1,5,3,6,4]
    Output: 7 (buy at 1, sell at 5, buy at 3, sell at 6)
    """
    profit = 0
    
    for i in range(1, len(prices)):
        if prices[i] > prices[i-1]:
            profit += prices[i] - prices[i-1]
    
    return profit
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 344 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3440 |