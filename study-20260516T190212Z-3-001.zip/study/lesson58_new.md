# Lesson 58 — Virtual Environments

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 57 - Type Hints.

**Current Lesson:** Learning **Virtual Environments** — isolate Python projects.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Creating virtual environments
- Activating/deactivating
- Managing packages with pip

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Create and Activate

```bash
# Create virtual environment
python -m venv myenv

# Activate (Windows)
myenv\Scripts\activate

# Activate (Mac/Linux)
source myenv/bin/activate
```

### Package Management

```bash
# Install package
pip install requests

# Export requirements
pip freeze > requirements.txt

# Install from requirements
pip install -r requirements.txt
```

### Requirements File

```
requests==2.28.0
flask>=2.0.0
numpy
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What command creates a virtual environment?**

> **Answer:** python -m venv env_name

---

**Type 59 to continue**