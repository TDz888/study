# Bài 218 — LeetCode: First Unique Character (Easy)

## 1. Ôn tập

Bài 217 dùng Counter để so sánh. Hôm nay ta tìm **First Unique Character** - character xuất hiện 1 lần!

## 2. Mục tiêu bài học

- Tìm character đầu tiên không lặp
- Two-pass: đếm rồi tìm
- Return index, không phải character

## 3. Code chính (có comment)

```python
def first_uniq_char(s: str) -> int:
    """
    Tìm first unique character và return index
    Input: s = "leetcode"
    Output: 0 (character 'l')
    """
    from collections import Counter
    
    # Pass 1: đếm tất cả characters
    count = Counter(s)
    
    # Pass 2: tìm character đầu tiên có count=1
    for i, char in enumerate(s):
        if count[char] == 1:
            return i
    
    return -1

# Test
print(first_uniq_char("leetcode"))   # 0
print(first_uniq_char("loveleetcode"))  # 2
```

## 4. Ghi nhớ nhanh

| Pass | Purpose |
|------|---------|
| 1 | Đếm tất cả |
| 2 | Tìm unique |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 218 / 2000 |
| **XP** | 2180 |