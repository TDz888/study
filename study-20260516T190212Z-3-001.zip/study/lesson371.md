# Bài 371 — Generate Parentheses (Medium)

## 1. Ôn tập

Từ bài 370, ta đã học Valid Parentheses. Hôm nay ta học **Generate Parentheses**!

## 2. Mục tiêu bài học

- Generate tất cả valid parentheses combinations
- Backtracking
- Track open và close count

## 3. Code chính (có comment)

```python
def generate_parentheses(n):
    """
    Generate Parentheses
    Input: n=3
    Output: ["((()))","(()())","(())()","()(())","()()()"]
    """
    result = []
    
    def backtrack(s, open_count, close_count):
        if len(s) == 2 * n:
            result.append(s)
            return
        
        if open_count < n:
            backtrack(s + '(', open_count + 1, close_count)
        
        if close_count < open_count:
            backtrack(s + ')', open_count, close_count + 1)
    
    backtrack('', 0, 0)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 371 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3710 |