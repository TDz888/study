# Lesson 77 — Dynamic Programming (P2)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 76 - Dynamic Programming (P1).

**Current Lesson:** More DP problems.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Coin Change problem
- Longest Increasing Subsequence

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Coin Change

```python
def coin_change(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    
    for i in range(1, amount + 1):
        for coin in coins:
            if i - coin >= 0:
                dp[i] = min(dp[i], dp[i - coin] + 1)
    
    return dp[amount] if dp[amount] != float('inf') else -1

# Test
print(coin_change([1, 2, 5], 11))  # 3 (5+5+1)
```

### Longest Increasing Subsequence

```python
def lis(nums):
    if not nums:
        return 0
    
    dp = [1] * len(nums)
    
    for i in range(1, len(nums)):
        for j in range(i):
            if nums[j] < nums[i]:
                dp[i] = max(dp[i], dp[j] + 1)
    
    return max(dp)

# Test
print(lis([10, 9, 2, 5, 3, 7, 101, 18]))  # 4
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does coin_change return if no solution?**

> **Answer:** -1

---

**Type 78 to continue**