# Bài 465 — Remove Element (Easy)

## 1. Ôn tập

Từ bài 464, ta đã học Duplicate Zeros. Hôm nay ta học **Remove Element**!

## 2. Mục tiêu bài học

- Remove all instances của val
- In-place, return new length
- Two pointers

## 3. Code chính (có comment)

```python
def remove_element(nums, val):
    """
    Remove Element
    Input: nums=[3,2,2,3], val=3
    Output: 2 (nums=[2,2])
    """
    slow = 0
    
    for fast in range(len(nums)):
        if nums[fast] != val:
            nums[slow] = nums[fast]
            slow += 1
    
    return slow
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 465 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 4650 |