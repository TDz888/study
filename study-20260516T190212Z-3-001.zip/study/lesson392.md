# Bài 392 — Reverse Bits (Easy)

## 1. Ôn tập

Từ bài 391, ta đã học Number of 1 Bits. Hôm nay ta học **Reverse Bits**!

## 2. Mục tiêu bài học

- Đảo ngược bits của 32-bit integer
- Bit manipulation
- O(1)

## 3. Code chính (có comment)

```python
def reverse_bits(n):
    """
    Reverse Bits
    Input: n=43261596 (binary: 00000010100101000001111010011100)
    Output: 964176192
    """
    result = 0
    
    for i in range(32):
        result = (result << 1) | (n & 1)
        n >>= 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 392 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3920 |