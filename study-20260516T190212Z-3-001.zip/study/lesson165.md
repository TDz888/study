# Bài 165 — asyncio.run_in_executor

## 1. Ôn tập

Async code chạy trên một thread duy nhất. Nhưng nếu cần chạy code đồng bộ (như I/O thực, CPU-intensive) mà không block event loop?

## 2. Mục tiêu bài học

- Hiểu `run_in_executor` - chạy sync code trong thread pool
- Kết hợp async với sync code
- Tránh block event loop

## 3. Code chính (có comment)

```python
import asyncio
from concurrent.futures import ThreadPoolExecutor
import time

def blocking_function(n):
    """Hàm blocking - giả lập CPU intensive"""
    time.sleep(1)  # Blocking!
    return n * 2

async def async_task(n):
    """Hàm async - không block"""
    await asyncio.sleep(1)
    return n * 2

async def main():
    executor = ThreadPoolExecutor(max_workers=4)
    
    # Cách 1: Chạy hàm blocking trong executor
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        executor, 
        blocking_function, 
        10
    )
    print(f"Blocking result: {result}")
    
    # Cách 2: So sánh với async thuần
    start = time.time()
    results = await asyncio.gather(
        async_task(1),
        async_task(2),
        async_task(3)
    )
    print(f"Async took: {time.time() - start:.2f}s, results: {results}")
    
    # Cách 3: Blocking trong executor với gather
    start = time.time()
    blocking_tasks = [
        loop.run_in_executor(executor, blocking_function, i)
        for i in range(3)
    ]
    results = await asyncio.gather(*blocking_tasks)
    print(f"Blocking in executor took: {time.time() - start:.2f}s")
    
    executor.shutdown()

asyncio.run(main())
```

## 4. Trace chạy code

```
Blocking result: 20
Async took: 1.00s, results: [2, 4, 6]
Blocking in executor took: 1.00s
```

## 5. Debug tư duy

### Khi nào dùng executor?
```python
# Dùng: I/O blocking thực sự (file, network thư viện cũ)
await loop.run_in_executor(executor, old_library_call)

# Không dùng: async library có sẵn
data = await aiohttp.get(url)  # Không cần executor!
```

### Nhớ shutdown executor!
```python
executor = ThreadPoolExecutor()
# ... dùng ...
executor.shutdown()  # Tránh leak tài nguyên
```

## 6. Ghi nhớ nhanh

| Hàm | Công dụng |
|-----|-----------|
| `run_in_executor(executor, func, *args)` | Chạy func trong thread pool |
| `ThreadPoolExecutor` | Thread pool cho I/O bound |
| `ProcessPoolExecutor` | Process pool cho CPU bound |

## 7. Mini test (3 câu)

**Câu 1:** run_in_executor dùng để làm gì?
- A) Chạy async code trong thread
- B) Chạy sync code mà không block event loop
- C) Tạo thread mới
- D) Kết thúc event loop

**Câu 2:** ThreadPoolExecutor dùng cho loại công việc nào?
- A) CPU intensive
- B) I/O intensive
- C) Cả hai đều được
- D) Không dùng được

**Câu 3:** Phải làm gì sau khi dùng executor?
- A) Không cần làm gì
- B) Gọi shutdown()
- C) Xóa biến
- D) Gọi close()

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Image Processor"

```python
from PIL import Image  # Thư viện sync
import io

def process_image_sync(image_bytes):
    # Xử lý ảnh - blocking
    img = Image.open(io.BytesIO(image_bytes))
    img = img.resize((100, 100))
    return img

async def process_images(images):
    # Dùng executor để xử lý nhiều ảnh
    loop = asyncio.get_event_loop()
    executor = ThreadPoolExecutor()
    # Viết code...
```

## 9. Bonus

Tạo web scraper:
- Dùng requests (sync) với executor
- Scrape 10 trang web cùng lúc
- So sánh với aiohttp

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 165 / 2000 |
| **XP** | 1650 |