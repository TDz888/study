# Bài 312 — Decode Ways (Medium)

## 1. Ôn tập

Từ bài 311, ta đã học Perfect Squares. Hôm nay ta học **Decode Ways**!

## 2. Mục tiêu bài học

- Decode string thành letters
- "1"→A, "2"→B, ... "26"→Z
- Xử lý invalid sequences

## 3. Code chính (có comment)

```python
def num_decodings(s):
    """
    Decode Ways
    Input: s="12"
    Output: 2 ("AB" hoặc "L")
    """
    if not s or s[0] == '0':
        return 0
    
    n = len(s)
    # dp[i] = ways decode s[:i]
    dp = [0] * (n + 1)
    dp[0] = 1  # empty string
    dp[1] = 1  # single char
    
    for i in range(2, n + 1):
        # Single digit
        if s[i-1] != '0':
            dp[i] += dp[i-1]
        
        # Two digits
        if 10 <= int(s[i-2:i]) <= 26:
            dp[i] += dp[i-2]
    
    return dp[n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 312 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3120 |