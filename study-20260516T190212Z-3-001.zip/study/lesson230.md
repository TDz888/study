# Bài 230 — Surrounded Regions (Medium)

## 1. Ôn tập

Từ bài 229, ta đã học Pacific Atlantic. Hôm nay ta học **Surrounded Regions** - vùng bị bao quanh!

## 2. Mục tiêu bài học

- Flip "X" bao quanh bởi "O"
- Reverse: tìm "O" ở edge, flood fill
- Không flip các "O" connected với edge

## 3. Code chính (có comment)

```python
def solve(board: List[List[str]]) -> None:
    """
    Flip vùng O bị bao quanh bởi X
    Input: board=[["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]]
    Output: board được flip in-place
    """
    if not board:
        return
    
    rows, cols = len(board), len(board[0])
    
    # B1: Tìm O connected với edge -> đánh dấu
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return
        if board[r][c] != "O":
            return
        
        board[r][c] = "M"  # Mark
        dfs(r+1, c)
        dfs(r-1, c)
        dfs(r, c+1)
        dfs(r, c-1)
    
    # Từ các edge, flood fill
    for r in range(rows):
        dfs(r, 0)
        dfs(r, cols-1)
    for c in range(cols):
        dfs(0, c)
        dfs(rows-1, c)
    
    # B2: Flip và restore
    for r in range(rows):
        for c in range(cols):
            if board[r][c] == "O":
                board[r][c] = "X"  # Flip
            elif board[r][c] == "M":
                board[r][c] = "O"  # Restore
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 230 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2300 |