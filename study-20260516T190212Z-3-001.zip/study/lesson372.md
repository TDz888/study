# Bài 372 — Swap Nodes in Pairs (Medium)

## 1. Ôn tập

Từ bài 371, ta đã học Generate Parentheses. Hôm nay ta học **Swap Nodes in Pairs**!

## 2. Mục tiêu bài học

- Swap adjacent nodes
- In-place, không đổi values
- Pointer manipulation

## 3. Code chính (có comment)

```python
def swap_pairs(head):
    """
    Swap Pairs
    Input: 1→2→3→4
    Output: 2→1→4→3
    """
    dummy = ListNode(0)
    dummy.next = head
    current = dummy
    
    while current.next and current.next.next:
        first = current.next
        second = current.next.next
        
        first.next = second.next
        second.next = first
        current.next = second
        
        current = first
    
    return dummy.next
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 372 / 2000 |
| **Chapter** | Linked List |
| **XP** | 3720 |