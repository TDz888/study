# Bài 90 — Working with APIs

---

## 1. Ôn tập
Bài 89 đã học về Error Handling nâng cao. Giờ học cách làm việc với **REST API**.

---

## 2. Mục tiêu bài học
- Hiểu REST API là gì
- Biết các HTTP methods
- Biết cách gọi API với Python
- Xử lý response và error

---

## 3. Code chính (có comment)

### HTTP Methods
```python
# GET    → Lấy dữ liệu (đọc)
# POST   → Tạo mới dữ liệu
# PUT    → Cập nhật TOÀN BỘ dữ liệu
# PATCH  → Cập nhật MỘT PHẦN dữ liệu
# DELETE → Xóa dữ liệu
```

### Status Codes
```python
# 2xx - Thành công
200 - OK                  # Thành công
201 - Created            # Tạo mới thành công
204 - No Content         # Thành công, không có nội dung trả về

# 4xx - Lỗi Client
400 - Bad Request        # Request sai cú pháp
401 - Unauthorized        # Chưa đăng nhập
403 - Forbidden          # Không có quyền
404 - Not Found          # Không tìm thấy

# 5xx - Lỗi Server
500 - Internal Error     # Lỗi server
503 - Service Unavailable # Service không available
```

### Gọi API với Python
```python
import requests

# GET - Lấy dữ liệu
response = requests.get("https://jsonplaceholder.typicode.com/posts")
print(response.status_code)  # 200
print(response.json())       # List các posts

# GET với parameters
params = {"userId": 1}
response = requests.get("https://jsonplaceholder.typicode.com/posts", params=params)

# POST - Tạo mới
data = {"title": "foo", "body": "bar", "userId": 1}
response = requests.post("https://jsonplaceholder.typicode.com/posts", json=data)
print(response.status_code)  # 201
print(response.json())       # Response từ server

# PUT - Cập nhật toàn bộ
data = {"title": "foo", "body": "bar", "userId": 1}
response = requests.put("https://jsonplaceholder.typicode.com/posts/1", json=data)

# PATCH - Cập nhật một phần
data = {"title": "New Title"}
response = requests.patch("https://jsonplaceholder.typicode.com/posts/1", json=data)

# DELETE - Xóa
response = requests.delete("https://jsonplaceholder.typicode.com/posts/1")
print(response.status_code)  # 200
```

---

## 4. Trace chạy code

```
API Call Flow:

1. requests.get(url)
       ↓
   Gửi HTTP Request đến server
       ↓
2. Server xử lý request
       ↓
3. Nhận HTTP Response
       ↓
4. response.status_code
       ↓
   - 200 → Thành công → .json()
   - 404 → Not Found → Xử lý lỗi
   - 500 → Server Error → Xử lý lỗi
       ↓
5. Parse JSON hoặc xử lý error
```

---

## 5. Debug tư duy

### ❌ Lỗi 1 — Không xử lý lỗi network
```python
# LỖI! Server không available thì crash
response = requests.get(url)
data = response.json()

# ✅ Sửa: Try-except
try:
    response = requests.get(url, timeout=5)
    response.raise_for_status()  # Ném exception nếu status >= 400
    data = response.json()
except requests.exceptions.RequestException as e:
    print(f"Lỗi: {e}")
```

### ❌ Lỗi 2 — Nhầm POST và PUT
```python
# POST: Tạo mới (không cần ID)
response = requests.post(url, json=data)  # Tạo resource mới

# PUT: Cập nhật (CẦN ID)
response = requests.put(url + "/1", json=data)  # Cập nhật resource có ID=1
```

### ❌ Lỗi 3 — Quên Content-Type
```python
# Đôi khi server yêu cầu header
headers = {"Content-Type": "application/json"}
response = requests.post(url, json=data, headers=headers)
```

---

## 6. Ghi nhớ nhanh

| Method | Ý nghĩa | ID cần thiết? |
|--------|---------|---------------|
| GET | Lấy dữ liệu | Không (hoặc optional) |
| POST | Tạo mới | Không |
| PUT | Cập nhật toàn bộ | Có |
| PATCH | Cập nhật một phần | Có |
| DELETE | Xóa | Có |

**MẸO NHỚ:** GET = đọc, POST = tạo, PUT = thay thế, PATCH = sửa, DELETE = xóa

---

## 7. Mini test (3 câu)

**Câu 1:** Status code 201 có nghĩa gì?
> Đáp án: **Created** - Tạo mới thành công

**Câu 2:** Dùng method nào để cập nhật một phần dữ liệu?
> Đáp án: **PATCH**

**Câu 3:** 
```python
requests.get("url", timeout=5)
```
timeout=5 có ý nghĩa gì?
> Đáp án: **Chờ tối đa 5 giây, sau đó cancel request**

---

## 8. LeetCode Practice

### Bài tập: Gọi API và lọc dữ liệu
**Yêu cầu:** Gọi API lấy users, in ra tên user có id=1

**Input:** (không có - gọi API thật)

**Output:** `Leanne Graham`

**✅ Đáp án:**
```python
import requests

# Gọi API
response = requests.get("https://jsonplaceholder.typicode.com/users")
users = response.json()

# Tìm user có id=1
for user in users:
    if user['id'] == 1:
        print(user['name'])
        break
```

---

## 9. Bonus (nếu học tốt)

**Thử thách:** Tạo post mới và in ra ID của post đó

**Input:** (không có - gọi API thật)

**Output:** ID của post được tạo (thường là 101)

**✅ Đáp án:**
```python
import requests

# Tạo post mới
new_post = {
    "title": "Bai viet cua toi",
    "body": "Noi dung bai viet",
    "userId": 1
}

response = requests.post(
    "https://jsonplaceholder.typicode.com/posts",
    json=new_post
)

# In ra ID của post mới tạo
result = response.json()
print(result['id'])
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 90 / 2000 |
| **Chapter** | 6 (Advanced) |
| **XP** | 900 (+20 XP khi hoàn thành) |
| **Level** | Advanced |

---

**🎉 Bạn đã hoàn thành Bài 90!**

Gõ **91** để học tiếp Bài 91 (Async IO) →