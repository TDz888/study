# Bài 393 — Bitwise AND of Number Range (Medium)

## 1. Ôn tập

Từ bài 392, ta đã học Reverse Bits. Hôm nay ta học **Bitwise AND of Number Range**!

## 2. Mục tiêu bài học

- Tính bitwise AND từ m đến n
- Tìm common prefix bits
- O(1)

## 3. Code chính (có comment)

```python
def range_bitwise_and(m, n):
    """
    Bitwise AND Range
    Input: m=5, n=7
    Output: 4 (101 & 110 & 111 = 100)
    """
    shift = 0
    
    while m != n:
        m >>= 1
        n >>= 1
        shift += 1
    
    return m << shift
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 393 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3930 |