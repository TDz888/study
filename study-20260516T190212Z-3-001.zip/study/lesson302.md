# Bài 302 — Longest Palindromic Subsequence (Medium)

## 1. Ôn tập

Từ bài 301, ta đã học Coin Change. Hôm nay ta học **Longest Palindromic Subsequence**!

## 2. Mục tiêu bài học

- Tìm LPS của string
- DP: dp[i][j] = LPS length của substring i→j
- Reverse string và LCS

## 3. Code chính (có comment)

```python
def longest_palindromic_subseq(s):
    """
    LPS
    Input: "bbbab"
    Output: 4 ("bbbb")
    """
    n = len(s)
    # dp[i][j] = LPS length của s[i:j+1]
    dp = [[0] * n for _ in range(n)]
    
    # Base: single characters
    for i in range(n):
        dp[i][i] = 1
    
    # Fill dp for substrings
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            
            if s[i] == s[j]:
                dp[i][j] = dp[i + 1][j - 1] + 2
            else:
                dp[i][j] = max(dp[i + 1][j], dp[i][j - 1])
    
    return dp[0][n - 1]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 302 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3020 |