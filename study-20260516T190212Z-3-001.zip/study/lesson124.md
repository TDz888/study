# Bài 124 — Working with Paths (pathlib)

---

## 1. pathlib

```python
from pathlib import Path

# Current directory
p = Path('.')
print(p.absolute())

# Create path
p = Path('C:/Users/John/Documents/file.txt')

# Parts
print(p.parts)  # ('C:\\', 'Users', 'John', ...)

# Parent, name, stem, suffix
print(p.parent)  # C:\Users\John\Documents
print(p.name)   # file.txt
print(p.stem)   # file
print(p.suffix) # .txt

# Check existence
print(p.exists())
print(p.is_file())
print(p.is_dir())

# Create directories
Path('new_folder').mkdir(exist_ok=True)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 124 / 2000 |
| **XP** | 1240 |
| **Level** | Intermediate |