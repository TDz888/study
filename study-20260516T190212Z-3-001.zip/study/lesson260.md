# Bài 260 — Level Order Traversal (Medium)

## 1. Ôn tập

Từ bài 259, ta đã học Postorder. Hôm nay ta học **Level Order** - duyệt theo từng level!

## 2. Mục tiêu bài học

- Duyệt theo từng tầng (BFS - Breadth First Search)
- Dùng Queue để lưu nodes
- Mỗi level lưu vào một list riêng

## 3. Code chính (có comment)

```python
from collections import deque

def level_order(root: TreeNode) -> list:
    """
    Level Order: duyệt theo từng tầng
    Input: root = [3,9,20,None,None,15,7]
    Output: [[3],[9,20],[15,7]]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level)
    
    return result
```

## 4. Quy trình

```
       3          Level 1: [3]
      / \
     9   20       Level 2: [9, 20]
        /  \
       15   7     Level 3: [15, 7]

Result: [[3], [9, 20], [15, 7]]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 260 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2600 |