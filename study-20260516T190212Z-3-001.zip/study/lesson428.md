# Bài 428 — Odd Even Linked List (Medium)

## 1. Ôn tập

Từ bài 427, ta đã học Remove Linked List Elements. Hôm nay ta học **Odd Even Linked List**!

## 2. Mục tiêu bài học

- Reorder: odd indices first, then even
- Keep relative order
- Two pointers

## 3. Code chính (có comment)

```python
def odd_even_list(head):
    """
    Odd Even Linked List
    Input: 1→2→3→4→5
    Output: 1→3→5→2→4
    """
    if not head or not head.next:
        return head
    
    odd = head
    even = head.next
    even_head = even
    
    while even and even.next:
        odd.next = odd.next.next
        odd = odd.next
        even.next = even.next.next
        even = even.next
    
    odd.next = even_head
    
    return head
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 428 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4280 |