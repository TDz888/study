# Bài 131 — itertools (P3)

---

## 1. Combinatoric iterators

```python
import itertools

# permutations
print(list(itertools.permutations('AB', 2)))  # [('A','B'), ('B','A')]
print(list(itertools.permutations('ABC', 2)))

# combinations
print(list(itertools.combinations('ABC', 2)))  # [('A','B'), ('A','C'), ('B','C')]

# combinations_with_replacement
print(list(itertools.combinations_with_replacement('AB', 2)))
# [('A','A'), ('A','B'), ('B','B')]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 131 / 2000 |
| **XP** | 1310 |
| **Level** | Intermediate |