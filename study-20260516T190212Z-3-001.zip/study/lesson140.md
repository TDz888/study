# Bài 140 — ast (Abstract Syntax Tree)

---

## 1. ast module

```python
import ast

code = """
def greet(name):
    return f"Hello, {name}!"

result = greet("World")
"""

# Parse to AST
tree = ast.parse(code)
print(ast.dump(tree)[:200])

# Walk AST
for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        print(f"Function: {node.name}")
    if isinstance(node, ast.Call):
        print(f"Function call: {ast.unparse(node.func)}")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 140 / 2000 |
| **XP** | 1400 |
| **Level** | Advanced |