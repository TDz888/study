# Bài 459 — Flood Fill (Easy)

## 1. Ôn tập

Từ bài 458, ta đã học Network Delay Time. Hôm nay ta học **Flood Fill**!

## 2. Mục tiêu bài học

- Fill region với new color
- DFS/BFS với visited
- O(n)

## 3. Code chính (có comment)

```python
def flood_fill(image, sr, sc, new_color):
    """
    Flood Fill
    Input: [[1,1,1],[1,1,0],[1,0,1]], sr=1, sc=1, new=2
    Output: [[2,2,2],[2,2,0],[2,0,1]]
    """
    original = image[sr][sc]
    if original == new_color:
        return image
    
    rows, cols = len(image), len(image[0])
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return
        if image[r][c] != original:
            return
        
        image[r][c] = new_color
        dfs(r+1, c)
        dfs(r-1, c)
        dfs(r, c+1)
        dfs(r, c-1)
    
    dfs(sr, sc)
    return image
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 459 / 2000 |
| **Chapter** | DFS |
| **XP** | 4590 |