# Bài 214 — LeetCode: Contains Duplicate (Easy)

## 1. Ôn tập

Từ bài 201-213, ta đã học nhiều kỹ thuật. Hôm nay ta học **Set** và **HashSet** - cơ bản nhưng cực kỳ quan trọng!

## 2. Mục tiêu bài học

- Kiểm tra duplicate trong array
- Dùng Set cho O(1) lookup
- Nắm bản chất hashing

## 3. Code chính (có comment)

```python
from typing import List

def contains_duplicate(nums: List[int]) -> bool:
    """
    Kiểm tra có duplicate không
    Input: [1,2,3,1]
    Output: True
    """
    seen = set()
    
    for num in nums:
        if num in seen:
            return True
        seen.add(num)
    
    return False

def contains_duplicate_sort(nums: List[int]) -> bool:
    """
    Alternative: Sort rồi check adjacent
    Time: O(n log n), Space: O(1)
    """
    nums.sort()
    for i in range(1, len(nums)):
        if nums[i] == nums[i-1]:
            return True
    return False

# Test
print(contains_duplicate([1,2,3,1]))  # True
print(contains_duplicate([1,2,3,4]))  # False
```

## 4. Ghi nhớ nhanh

| Method | Time | Space |
|--------|------|-------|
| HashSet | O(n) | O(n) |
| Sort + Scan | O(n log n) | O(1) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 214 / 2000 |
| **XP** | 2140 |