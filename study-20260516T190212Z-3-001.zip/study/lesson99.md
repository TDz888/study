# Bài 99 — Threading

---

## 1. Threading Basics

```python
import threading
import time

def worker(num):
    print(f'Thread {num} starting')
    time.sleep(2)
    print(f'Thread {num} ending')

threads = []
for i in range(4):
    t = threading.Thread(target=worker, args=(i,))
    threads.append(t)
    t.start()

for t in threads:
    t.join()

print('All threads done')
```

---

## 2. Thread-safe Queue

```python
import threading
import queue

q = queue.Queue()

def producer():
    for i in range(5):
        q.put(i)
        print(f'Produced {i}')

def consumer():
    while True:
        item = q.get()
        print(f'Consumed {item}')
        q.task_done()

t1 = threading.Thread(target=producer)
t2 = threading.Thread(target=consumer)

t1.start()
t2.start()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 99 / 2000 |
| **XP** | 990 |
| **Level** | Advanced |