# Bài 148 — Property Decorators

---

## 1. @property

```python
class Circle:
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        return self._radius
    
    @radius.setter
    def radius(self, value):
        if value < 0:
            raise ValueError("Radius cannot be negative")
        self._radius = value
    
    @property
    def diameter(self):
        return self._radius * 2
    
    @property
    def area(self):
        import math
        return math.pi * self._radius ** 2

c = Circle(5)
print(c.radius)   # 5
print(c.diameter) # 10
print(c.area)     # 78.53...

c.radius = 10
print(c.radius)  # 10

# c.radius = -5  # Raises ValueError
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 148 / 2000 |
| **XP** | 1480 |
| **Level** | Intermediate |