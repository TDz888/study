# Bài 206 — LeetCode: Best Time to Buy and Sell Stock (Easy)

## 1. Ôn tập

Bài 205 dùng Kadane's Algorithm cho Maximum Subarray. Hôm nay ta áp dụng tư tưởng tương tự cho bài Stock Trading - tìm min và max!

## 2. Mục tiêu bài học

- Tìm max profit từ mua/bán cổ phiếu
- One-pass algorithm
- Tư tưởng: tìm min price và max profit

## 3. Code chính (có comment)

```python
from typing import List

def max_profit(prices: List[int]) -> int:
    """
    Tìm max profit với 1 lần mua và bán
    Input: [7,1,5,3,6,4]
    Output: 5 (mua 1, bán 6)
    
    Tư tưởng:
    - Tìm min price đến thời điểm hiện tại
    - Tính profit nếu bán tại điểm hiện tại
    """
    min_price = float('inf')
    max_profit_val = 0
    
    for price in prices:
        # Cập nhật min price
        if price < min_price:
            min_price = price
        
        # Tính profit nếu bán tại đây
        profit = price - min_price
        
        # Cập nhật max profit
        if profit > max_profit_val:
            max_profit_val = profit
    
    return max_profit_val

# Test
prices = [7, 1, 5, 3, 6, 4]
print(max_profit(prices))  # 5

prices2 = [7, 6, 4, 3, 1]
print(max_profit(prices2))  # 0 (không có profit)
```

## 4. Trace chạy code

```
prices = [7,1,5,3,6,4]

price=7: min=7, profit=0, max=0
price=1: min=1, profit=0, max=0  ← new min!
price=5: min=1, profit=4, max=4
price=3: min=1, profit=2, max=4
price=6: min=1, profit=5, max=5  ← MAX!
price=4: min=1, profit=3, max=5

Output: 5
```

## 5. Debug tư duy

### Cần bán SAU khi mua!
```python
# Sai: Tìm max - min không đúng thứ tự
max(prices) - min(prices)  # Wrong! Có thể min ở sau max

# Đúng: One-pass như trên
```

### Nếu không có profit?
```python
prices = [7, 6, 4, 3, 1]
# Giá giảm liên tục → max_profit = 0
# Return 0 (không mua/bán)
```

## 6. Ghi nhớ nhanh

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n²) | O(1) |
| One-pass | O(n) | O(1) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 206 / 2000 |
| **XP** | 2060 |