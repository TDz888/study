# Bài 246 — Average of Levels in Binary Tree (Easy)

## 1. Ôn tập

Từ bài 245, ta đã học right side view. Hôm nay ta học **Average of Levels**!

## 2. Mục tiêu bài học

- Tính trung bình mỗi level
- BFS với sum và count
- Easy level!

## 3. Code chính (có comment)

```python
def average_of_levels(root: TreeNode) -> List[float]:
    """
    Tính trung bình mỗi level
    Input: root = [3,9,20,null,null,15,7]
    Output: [3.0, 14.5, 11.0]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level_sum = 0
        
        for _ in range(level_size):
            node = queue.popleft()
            level_sum += node.val
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level_sum / level_size)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 246 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2460 |