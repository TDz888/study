# Bài 304 — Unique Paths (Medium)

## 1. Ôn tập

Từ bài 303, ta đã học Edit Distance. Hôm nay ta học **Unique Paths** - DP cổ điển!

## 2. Mục tiêu bài học

- Robot đi từ top-left đến bottom-right
- Chỉ đi right hoặc down
- dp[i][j] = ways để reach cell (i,j)

## 3. Code chính (có comment)

```python
def unique_paths(m, n):
    """
    Unique paths
    Input: m=3, n=7
    Output: 28 ways
    """
    # dp[i][j] = ways để reach (i,j)
    dp = [[1] * n for _ in range(m)]
    
    # Fill first row và column
    for i in range(1, m):
        for j in range(1, n):
            dp[i][j] = dp[i-1][j] + dp[i][j-1]
    
    return dp[m-1][n-1]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 304 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3040 |