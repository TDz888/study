# Bài 186 — Practice: Data Pipeline

## 1. Project

Build ETL pipeline: Extract → Transform → Load

## 2. Components

```python
class Pipeline:
    def __init__(self):
        self.extractors = []
        self.transformers = []
        self.loaders = []
    
    async def run(self, source):
        data = await self.extract(source)
        data = await self.transform(data)
        await self.load(data)
```

## 3. Tasks

- CSV/JSON extractors
- Data validation
- Batch loading

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 186 / 2000 |
| **XP** | 1860 |