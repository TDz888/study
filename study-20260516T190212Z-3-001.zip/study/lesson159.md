# Bài 159 — asyncio.create_task

---

## 1. Create tasks

```python
import asyncio

async def worker(id, duration):
    print(f"Worker {id} started")
    await asyncio.sleep(duration)
    print(f"Worker {id} done")
    return id

async def main():
    # Create tasks
    tasks = [
        asyncio.create_task(worker(1, 2)),
        asyncio.create_task(worker(2, 1)),
        asyncio.create_task(worker(3, 0.5))
    ]
    
    # Wait for all
    results = await asyncio.gather(*tasks)
    print(f"Results: {results}")

asyncio.run(main())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 159 / 2000 |
| **XP** | 1590 |