# Bài 172 — yield from

## 1. Ôn tập

Bài 171, ta đã học cách tạo generator đơn giản với `yield`. Hôm nay, ta học `yield from` - delegate generator!

## 2. Mục tiêu bài học

- Hiểu `yield from` - delegate cho generator khác
- Dùng để compose generators
- Tránh viết vòng lặp lồng nhau

## 3. Code chính (có comment)

```python
# Cách cũ: Dùng vòng for để yield từng giá trị
def chain_old(list1, list2):
    for item in list1:
        yield item
    for item in list2:
        yield item

# Cách mới: Dùng yield from
def chain_new(list1, list2):
    yield from list1
    yield from list2

# Test
print(list(chain_old([1, 2], [3, 4])))  # [1, 2, 3, 4]
print(list(chain_new([1, 2], [3, 4])))  # [1, 2, 3, 4]

# yield from với generator khác
def number_gen():
    yield 1
    yield 2
    yield 3

def wrapper_gen():
    # Delegate to number_gen
    yield from number_gen()
    yield 100

print(list(wrapper_gen()))  # [1, 2, 3, 100]
```

## 4. Trace chạy code

```
[1, 2, 3, 4]
[1, 2, 3, 4]
[1, 2, 3, 100]
```

## 5. Debug tư duy

### Ứng dụng: flatten nested structure
```python
def flatten(nested_list):
    for item in nested_list:
        if isinstance(item, list):
            yield from flatten(item)  # Recursive!
        else:
            yield item

# [[1, [2, 3]], [4, [5]]] → [1, 2, 3, 4, 5]
print(list(flatten([[1, [2, 3]], [4, [5]]])))
```

### yield from vs return
```python
# yield from: Tiếp tục được
def gen1():
    yield from range(3)
    yield 100

# return: Kết thúc luôn
def gen2():
    yield from range(3)
    return  # Không yield được gì sau đây!
    yield 100  # Never reached!
```

## 6. Ghi nhớ nhanh

| Cú pháp | Ý nghĩa |
|---------|---------|
| `yield from iterable` | Delegate tất cả values |
| `yield from generator` | Delegate từ generator khác |
| Cho phép recursion | Generator gọi chính nó |

## 7. Mini test (3 câu)

**Câu 1:** yield from dùng để làm gì?
- A) Return giá trị
- B) Delegate cho iterable/generator khác
- C) Tạo list
- D) Định nghĩa class

**Câu 2:** Có thể dùng yield from sau khi return không?
- A) Có
- B) Không
- C) Tùy trường hợp
- D) Lỗi

**Câu 3:** yield from hỗ trợ recursion không?
- A) Không
- B) Có
- C) Chỉ 1 level
- D) Tối đa 2 level

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Flatten Nested List"

```python
def flatten(nested):
    # Dùng yield from để flatten nested list
    # Input: [1, [2, [3, 4]], 5]
    # Output: [1, 2, 3, 4, 5]
    pass

# Test
print(list(flatten([1, [2, [3, 4]], 5])))
```

## 9. Bonus

Tạo:
- Generator pipeline: map → filter → map
- Nested dict flattener
- Tree traversal với yield from

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 172 / 2000 |
| **XP** | 1720 |