# Lesson 93 — SQLite with Python

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 92 - Flask Routes & Methods.

**Current Lesson:** Learning **SQLite with Python** — working with lightweight databases.

**Why This Matters:**
- SQLite is built into Python (no installation needed)
- Perfect for small projects, testing, learning
- Foundation for understanding any database
- Used by many applications (browsers, mobile apps, etc.)

**Connection:**
```
Flask API → Database → Data Persistence
     ↓          ↓           ↓
  Web app   SQLite      Store data
```

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- What SQLite is and when to use it
- Creating connections and tables
- CRUD operations (Create, Read, Update, Delete)
- Using parameterized queries for security
- Transaction management

**Real-world analogy:**
- Think of SQLite like a digital notebook:
  - Database = The entire notebook
  - Table = A specific page in the notebook
  - Row = One entry/record
  - Column = A specific piece of information (name, email, etc.)

-------------------------------------------------------------------------------
3. CONCEPT FOUNDATION
-------------------------------------------------------------------------------

### What is SQLite?

SQLite is a lightweight, serverless, zero-configuration database engine. It stores data in a single file on disk.

**Key characteristics:**
- **No server required** - Runs directly in your application
- **Single file** - Entire database is one .db file
- **Zero configuration** - Works out of the box
- **ACID compliant** - Reliable transactions
- **SQL-based** - Uses standard SQL syntax

**When to use:**
- ✓ Learning databases
- ✓ Small to medium applications
- ✓ Mobile apps
- ✓ Testing and development
- ✗ Not for high-concurrency web applications

### Database vs Table vs Row

```
SQLite File (mydb.db)
│
└──► Table: users
    │  ┌────┬─────────┬─────────────────────┐
    │  │ id │ name    │ email                │
    │  ├────┼─────────┼─────────────────────┤
    │  │ 1  │ Alice   │ alice@example.com   │ ← Row 1
    │  │ 2  │ Bob     │ bob@example.com     │ ← Row 2
    │  │ 3  │ Charlie │ charlie@example.com│ ← Row 3
    │  └────┴─────────┴─────────────────────┘
    │
    └──► Table: products
       (another table in same database)
```

-------------------------------------------------------------------------------
4. TERMINOLOGY EXPLANATION
-------------------------------------------------------------------------------

| Term | Simple Meaning |
|------|----------------|
| **Database** | Collection of tables stored in one file |
| **Table** | Structured data with rows and columns |
| **Row** | A single record/entry in a table |
| **Column** | A specific attribute (field) |
| **Cursor** | Object used to execute SQL commands |
| **Connection** | Link between Python and SQLite file |
| **Commit** | Save changes permanently |
| **SQL Injection** | Security vulnerability from unsanitized input |
| **Parameterized Query** | Safe way to include variables in SQL |

-------------------------------------------------------------------------------
5. MAIN CODE
-------------------------------------------------------------------------------

### 1. Creating a Database and Table

```python
import sqlite3

# Step 1: Create connection to database file
# If file doesn't exist, it will be created
conn = sqlite3.connect('mydatabase.db')

# Step 2: Create a cursor object
# Cursor is used to execute SQL commands
cursor = conn.cursor()

# Step 3: Create a table
# SQL command to create users table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        age INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
''')

# Step 4: Commit the changes
conn.commit()

print("Database and table created successfully!")

# Step 5: Close the connection when done
conn.close()

# File 'mydatabase.db' now exists in your folder
```

### 2. Inserting Data (CREATE)

```python
import sqlite3

conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

# Method 1: Single insert with parameterized query
# The ? is a placeholder - prevents SQL injection!
cursor.execute(
    "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
    ('Alice', 'alice@example.com', 25)
)

# Method 2: Multiple inserts at once
users_data = [
    ('Bob', 'bob@example.com', 30),
    ('Charlie', 'charlie@example.com', 28),
    ('Diana', 'diana@example.com', 22)
]

cursor.executemany(
    "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
    users_data
)

# Always commit after making changes
conn.commit()

print("Data inserted successfully!")
conn.close()
```

### 3. Reading Data (READ)

```python
import sqlite3

conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

# Method 1: Fetch all rows
cursor.execute("SELECT * FROM users")
all_users = cursor.fetchall()

print("All users:")
for user in all_users:
    print(user)
    # Output: (1, 'Alice', 'alice@example.com', 25, '2024-01-01 12:00:00')

# Method 2: Fetch one row
cursor.execute("SELECT * FROM users WHERE id = 1")
one_user = cursor.fetchone()
print(one_user)

# Method 3: Fetch with condition using parameter
name_to_find = 'Bob'
cursor.execute("SELECT * FROM users WHERE name = ?", (name_to_find,))
bob = cursor.fetchone()
print(bob)

# Method 4: Select specific columns
cursor.execute("SELECT name, email FROM users")
names_and_emails = cursor.fetchall()
for name, email in names_and_emails:
    print(f"{name}: {email}")

conn.close()
```

### 4. Updating Data (UPDATE)

```python
import sqlite3

conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

# Update single row
cursor.execute(
    "UPDATE users SET age = ? WHERE name = ?",
    (26, 'Alice')
)
print(f"Rows updated: {cursor.rowcount}")

# Update multiple rows
cursor.execute(
    "UPDATE users SET age = age + 1 WHERE age < 30"
)

# Always commit changes
conn.commit()

# Verify the update
cursor.execute("SELECT * FROM users WHERE name = 'Alice'")
print(cursor.fetchone())

conn.close()
```

### 5. Deleting Data (DELETE)

```python
import sqlite3

conn = sqlite3.connect('mydatabase.db')
cursor = conn.cursor()

# Delete specific row
cursor.execute("DELETE FROM users WHERE name = ?", ('Bob',))
print(f"Deleted: {cursor.rowcount} row(s)")

# Delete with condition
cursor.execute("DELETE FROM users WHERE age < 20")

# Delete all (be careful!)
# cursor.execute("DELETE FROM users")

conn.commit()
conn.close()
```

### 6. Complete CRUD Example

```python
import sqlite3

class UserDatabase:
    """A class to handle all user database operations"""
    
    def __init__(self, db_name='users.db'):
        self.db_name = db_name
        self.create_table()
    
    def create_table(self):
        """Create users table if not exists"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_user(self, name, email, age):
        """Add a new user"""
        try:
            conn = sqlite3.connect(self.db_name)
            cursor = conn.cursor()
            
            cursor.execute(
                "INSERT INTO users (name, email, age) VALUES (?, ?, ?)",
                (name, email, age)
            )
            
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            print(f"Error: Email {email} already exists!")
            return False
    
    def get_all_users(self):
        """Get all users"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM users")
        users = cursor.fetchall()
        
        conn.close()
        return users
    
    def get_user_by_id(self, user_id):
        """Get a specific user by ID"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        
        conn.close()
        return user
    
    def update_user(self, user_id, name=None, email=None, age=None):
        """Update user information"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        # Build update query dynamically
        updates = []
        values = []
        
        if name:
            updates.append("name = ?")
            values.append(name)
        if email:
            updates.append("email = ?")
            values.append(email)
        if age is not None:
            updates.append("age = ?")
            values.append(age)
        
        if updates:
            values.append(user_id)
            query = f"UPDATE users SET {', '.join(updates)} WHERE id = ?"
            cursor.execute(query, values)
            conn.commit()
        
        conn.close()
        return cursor.rowcount > 0
    
    def delete_user(self, user_id):
        """Delete a user"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        conn.commit()
        
        conn.close()
        return cursor.rowcount > 0


# Usage example
db = UserDatabase()

# Add users
db.add_user("Alice", "alice@example.com", 25)
db.add_user("Bob", "bob@example.com", 30)

# Get all users
print("All users:")
for user in db.get_all_users():
    print(user)

# Get specific user
user = db.get_user_by_id(1)
print(f"User 1: {user}")

# Update user
db.update_user(1, age=26)

# Delete user
db.delete_user(2)
```

-------------------------------------------------------------------------------
6. EXECUTION TRACE
-------------------------------------------------------------------------------

### Trace: Insert and Query Flow

```
Step 1: Connect to database
  conn = sqlite3.connect('mydb.db')
  Creates file if not exists

Step 2: Get cursor
  cursor = conn.cursor()

Step 3: Execute INSERT
  cursor.execute(
    "INSERT INTO users (name, email) VALUES (?, ?)",
    ('Alice', 'alice@email.com')
  )
  
  SQLite processes:
  1. Parse SQL statement
  2. Check table exists
  3. Validate data
  4. Generate next ID (AUTOINCREMENT)
  5. Insert row into table

Step 4: Commit
  conn.commit()
  Writes changes to disk

Step 5: Query
  cursor.execute("SELECT * FROM users")
  rows = cursor.fetchall()
  
  Returns: [(1, 'Alice', 'alice@email.com', None)]

Step 6: Close
  conn.close()
```

### Trace: Why Parameterized Queries?

```python
# ❌ DANGEROUS - SQL Injection!
name = "'; DELETE FROM users; --"
cursor.execute(f"INSERT INTO users (name) VALUES ('{name}')")
# This would delete ALL users!

# ✅ SAFE - Parameterized
name = "'; DELETE FROM users; --"
cursor.execute("INSERT INTO users (name) VALUES (?)", (name,))
# SQLite treats it as a literal string, not SQL!
```

-------------------------------------------------------------------------------
7. VISUAL THINKING MODE
-------------------------------------------------------------------------------

### Database Operations Visual

```
┌─────────────────────────────────────────────────────────────┐
│                    SQLite DATABASE                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   CREATE ──► INSERT ──► SELECT ──► UPDATE ──► DELETE        │
│      │          │            │           │          │      │
│      ▼          ▼            ▼           ▼          ▼      │
│   ┌─────┐   ┌─────┐      ┌─────┐    ┌─────┐    ┌─────┐     │
│   │CREATE│   │WRITE│      │READ │    │MODIFY│    │REMOVE│    │
│   │ TABLE│   │ DATA│      │ DATA│    │ DATA │    │ DATA │    │
│   └─────┘   └─────┘      └─────┘    └─────┘    └─────┘     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Connection Lifecycle

```
Python Program                    SQLite File
     │                                 │
     │──── connect() ────────────────►│ Opens/creates file
     │                                 │
     │──── execute() ─────────────────►│ SQL command
     │                                 │
     │◄───── fetchall() ──────────────│ Returns data
     │                                 │
     │──── commit() ──────────────────►│ Saves to disk
     │                                 │
     │──── close() ───────────────────►│ Closes connection
```

-------------------------------------------------------------------------------
8. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake 1: Forgetting to Commit

```python
# ❌ WRONG - Changes not saved!
cursor.execute("INSERT INTO users (name) VALUES ('Alice')")
# Forgot conn.commit()!
conn.close()
# Data is LOST!

# ✅ CORRECT - Commit after changes
cursor.execute("INSERT INTO users (name) VALUES ('Alice')")
conn.commit()  # Saves to disk
conn.close()
```

**Why it happens:** SQLite uses transactions; changes are held in memory until commit.

**Prevention:** Always call `conn.commit()` after INSERT, UPDATE, DELETE.

---

### Common Mistake 2: SQL Injection

```python
# ❌ WRONG - Vulnerable to SQL injection!
user_input = "'; DROP TABLE users; --"
cursor.execute("SELECT * FROM users WHERE name = '" + user_input + "'")

# ✅ CORRECT - Use parameterized queries
user_input = "'; DROP TABLE users; --"
cursor.execute("SELECT * FROM users WHERE name = ?", (user_input,))
# Treated as literal string, not SQL!
```

**Why it happens:** String concatenation passes user input directly to SQL.

**Prevention:** ALWAYS use parameterized queries with `?` placeholders.

---

### Common Mistake 3: Not Closing Connection

```python
# ❌ WRONG - Resource leak!
def get_data():
    conn = sqlite3.connect('db.db')
    cursor = conn.cursor()
    # ... do something
    # Forgot to close!
    # Multiple calls = multiple open connections

# ✅ CORRECT - Always close
def get_data():
    conn = sqlite3.connect('db.db')
    try:
        cursor = conn.cursor()
        # ... do something
    finally:
        conn.close()  # Always closes

# Or use context manager
with sqlite3.connect('db.db') as conn:
    cursor = conn.cursor()
    # ... do something
# Auto-closes!
```

**Why it happens:** Leaving connections open causes resource leaks.

**Prevention:** Use `try/finally` or `with` statement.

---

### Common Mistake 4: Wrong Data Type

```python
# ❌ WRONG - Integer stored as string?
cursor.execute("INSERT INTO users (name, age) VALUES ('Alice', '25')")
# age becomes TEXT, not INTEGER!

# ✅ CORRECT - Use correct types
cursor.execute("INSERT INTO users (name, age) VALUES (?, ?)", ('Alice', 25))
# age is properly stored as INTEGER
```

**Why it happens:** SQLite is flexible but stores what you give it.

**Prevention:** Pass correct Python types to parameterized queries.

-------------------------------------------------------------------------------
9. MEMORY REINFORCEMENT
-------------------------------------------------------------------------------

### Quick Reference

| Operation | SQL Command | Python Method |
|-----------|-------------|---------------|
| Create table | `CREATE TABLE...` | `cursor.execute()` |
| Insert | `INSERT INTO...` | `cursor.execute()` |
| Read | `SELECT...` | `cursor.fetchall()` / `fetchone()` |
| Update | `UPDATE...` | `cursor.execute()` |
| Delete | `DELETE FROM...` | `cursor.execute()` |
| Save | - | `conn.commit()` |
| Close | - | `conn.close()` |

### Code Template

```python
import sqlite3

# 1. Connect
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# 2. Execute
cursor.execute("SQL command", params)

# 3. For write operations
conn.commit()

# 4. For read operations
results = cursor.fetchall()

# 5. Close
conn.close()

# Or use context manager (recommended)
with sqlite3.connect('database.db') as conn:
    cursor = conn.cursor()
    # operations
# Auto-closes
```

### Mnemonic

**"C-R-U-D"**
- **C**reate table (CREATE)
- **R**ead data (SELECT)
- **U**pdate data (UPDATE)
- **D**elete data (DELETE)

**"C3" Rule:**
- Connect → Cursor → Commit/Close

-------------------------------------------------------------------------------
10. MINI TEST
-------------------------------------------------------------------------------

### Question 1: Concept Check

**What is the main advantage of SQLite over other databases?**

> **Answer:** SQLite is serverless and requires no installation - it works directly with a single file on disk.

---

### Question 2: Prediction

**What is the output?**
```python
conn = sqlite3.connect('test.db')
cursor = conn.cursor()
cursor.execute("INSERT INTO users (name) VALUES (?)", ('Alice',))
cursor.execute("SELECT * FROM users")
print(cursor.fetchall())
conn.close()
```

> **Answer:** `[(1, 'Alice', None, None)]`
> 
> - id=1 (auto-generated)
> - name='Alice' 
> - email=None (not provided)
> - age=None (not provided)

---

### Question 3: Problem Solving

**How do you safely insert user data to prevent SQL injection?**

> **Answer:** Use parameterized queries:
> ```python
> cursor.execute(
>     "INSERT INTO users (name, email) VALUES (?, ?)",
>     (name, email)
> )
> ```

-------------------------------------------------------------------------------
11. LEETCODE PRACTICE
-------------------------------------------------------------------------------

### Problem: SQLite Contact Manager

**Task:** Build a simple contact manager using SQLite with these operations:
- Add contact (name, phone)
- View all contacts
- Search by name
- Delete contact

**Solution:**
```python
import sqlite3

class ContactManager:
    def __init__(self):
        self.conn = sqlite3.connect('contacts.db')
        self.create_table()
    
    def create_table(self):
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                phone TEXT NOT NULL
            )
        ''')
        self.conn.commit()
    
    def add_contact(self, name, phone):
        self.conn.execute(
            "INSERT INTO contacts (name, phone) VALUES (?, ?)",
            (name, phone)
        )
        self.conn.commit()
        print(f"Added: {name}")
    
    def view_all(self):
        cursor = self.conn.execute("SELECT * FROM contacts")
        for row in cursor.fetchall():
            print(f"{row[0]}. {row[1]} - {row[2]}")
    
    def search(self, name):
        cursor = self.conn.execute(
            "SELECT * FROM contacts WHERE name LIKE ?",
            (f'%{name}%',)
        )
        for row in cursor.fetchall():
            print(f"{row[0]}. {row[1]} - {row[2]}")
    
    def delete(self, contact_id):
        self.conn.execute("DELETE FROM contacts WHERE id = ?", (contact_id,))
        self.conn.commit()
        print(f"Deleted contact {contact_id}")
    
    def close(self):
        self.conn.close()


# Test
cm = ContactManager()
cm.add_contact("Alice", "123-456-7890")
cm.add_contact("Bob", "987-654-3210")
print("All contacts:")
cm.view_all()
print("\nSearching 'Ali':")
cm.search("Ali")
cm.close()
```

-------------------------------------------------------------------------------
12. BONUS CHALLENGE
-------------------------------------------------------------------------------

### Challenge: Add Update Functionality

Add a method to update a contact's phone number:

```python
def update_contact(self, contact_id, new_phone):
    # Update phone number for given contact_id
    pass

# Test:
# cm.update_contact(1, "000-000-0000")
```

**Solution:**
```python
def update_contact(self, contact_id, new_phone):
    self.conn.execute(
        "UPDATE contacts SET phone = ? WHERE id = ?",
        (new_phone, contact_id)
    )
    self.conn.commit()
    print(f"Updated contact {contact_id} to {new_phone}")
```

-------------------------------------------------------------------------------
13. LESSON REFLECTION
-------------------------------------------------------------------------------

### What You Learned Today

1. **SQLite Basics** - What it is and when to use it
2. **Database Creation** - Creating databases and tables
3. **CRUD Operations** - Create, Read, Update, Delete
4. **Parameterized Queries** - Safe SQL with ?
5. **Connection Management** - Commit and close properly
6. **Complete Example** - Building a database class

### Key Takeaways

- SQLite is perfect for learning and small projects
- Always use parameterized queries to prevent SQL injection
- Remember to commit after changes and close connections
- Use context manager (`with`) for automatic cleanup

### Common Patterns

| Pattern | Code |
|---------|------|
| Connect | `sqlite3.connect('file.db')` |
| Execute | `cursor.execute("SQL", params)` |
| Fetch | `fetchall()` / `fetchone()` |
| Commit | `conn.commit()` |
| Close | `conn.close()` |
| Safe input | `?` placeholders |

### Weak Points to Watch

- Forgetting to commit after INSERT/UPDATE/DELETE
- Using string concatenation instead of parameterized queries
- Not closing connections (resource leak)
- Not handling database errors

### Next Lesson Preview

**Lesson 94:** SQL Basics — Query language for databases

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 93 / 2000 |
| **Chapter** | 10 (Database) |
| **XP** | 930 |
| **Rank** | Intermediate |
| **Mastery** | SQLite Database |
| **Weaknesses** | Remembering to commit |
| **Recommended Focus** | Practice CRUD operations |
| **Suggested Review** | Lesson 92 (Flask Routes) |
| **Next Lesson Readiness** | ✓ Ready for SQL Basics |

---

**Type 94 to continue**