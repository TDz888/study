# Bài 378 — Perfect Squares (Medium)

## 1. Ôn tập

Từ bài 377, ta đã học First Bad Version. Hôm nay ta học **Perfect Squares**!

## 2. Mục tiêu bài học

- Tìm min perfect squares sum = n
- Binary search approach
- Lagrange's theorem

## 3. Code chính (có comment)

```python
def num_squares(n):
    """
    Perfect Squares (Binary Search)
    Input: n=12
    Output: 3 (4+4+4)
    """
    def is_dss(m, n):
        """Check if m perfect squares can sum to n"""
        if m == 1:
            return int(n**0.5) ** 2 == n
        
        import math
        limit = int(math.sqrt(n))
        for i in range(1, limit + 1):
            remaining = n - i*i
            if m - 1 == 1:
                root = int(remaining**0.5)
                if root*root == remaining:
                    return True
            else:
                if num_squares_recur(m - 1, remaining):
                    return True
        return False
    
    for m in range(1, 5):
        if is_dss(m, n):
            return m
    return 4
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 378 / 2000 |
| **Chapter** | Math |
| **XP** | 3780 |