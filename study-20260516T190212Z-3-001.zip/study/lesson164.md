# Bài 164 — asyncio.Queue nâng cao

## 1. Ôn tập

Ta đã dùng `Condition` để tự viết queue an toàn. Nhưng Python đã có `asyncio.Queue` sẵn, mạnh hơn nhiều!

## 2. Mục tiêu bài học

- Nắm vững `asyncio.Queue` đầy đủ tính năng
- Hiểu các phương thức: put, get, join, task_done
- Xây dựng hệ thống producer-consumer hoàn chỉnh

## 3. Code chính (có comment)

```python
import asyncio

async def producer(queue, n):
    """Producer - đẩy dữ liệu vào queue"""
    for i in range(n):
        await queue.put(i)
        print(f"Produced: {i}")
    # Báo hiệu producer hoàn thành
    await queue.put(None)  # Poison pill - signal end

async def consumer(queue, name):
    """Consumer - lấy dữ liệu từ queue"""
    while True:
        item = await queue.get()  # Block nếu queue rỗng
        if item is None:  # Poison pill
            queue.task_done()
            break
        print(f"{name} consumed: {item}")
        await asyncio.sleep(0.5)  # Xử lý công việc
        queue.task_done()  # Báo đã xử lý xong

async def main():
    queue = asyncio.Queue()
    
    # 1 producer, 2 consumer
    await asyncio.gather(
        producer(queue, 5),
        consumer(queue, "Consumer-1"),
        consumer(queue, "Consumer-2"),
    )
    
    # Chờ tất cả task hoàn thành
    # queue.join() sẽ block cho đến khi task_done() được gọi đủ số lần

asyncio.run(main())
```

## 4. Trace chạy code

```
Produced: 0
Produced: 1
Consumer-1 consumed: 0
Produced: 2
Consumer-2 consumed: 1
Produced: 3
Consumer-1 consumed: 2
Produced: 4
Consumer-2 consumed: 3
Consumer-1 consumed: 4
```

## 5. Debug tư duy

### Queue với maxsize
```python
# Queue giới hạn - producer sẽ block nếu đầy
queue = asyncio.Queue(maxsize=3)
await queue.put(item)  # Block nếu có 3 phần tử
```

### Timeout cho queue
```python
# Không chờ vô hạn, chờ tối đa 1 giây
try:
    item = await asyncio.wait_for(queue.get(), timeout=1.0)
except asyncio.TimeoutError:
    print("Hết thời gian chờ!")
```

## 6. Ghi nhớ nhanh

| Phương thức | Công dụng |
|-------------|-----------|
| `queue.get()` | Lấy item (block nếu rỗng) |
| `queue.put(item)` | Đẩy item (block nếu đầy) |
| `queue.join()` | Chờ cho đến khi tất cả task_done() |
| `queue.task_done()` | Báo một item đã xử lý xong |
| `queue.qsize()` | Lấy số phần tử trong queue |

## 7. Mini test (3 câu)

**Câu 1:** queue.join() block cho đến khi nào?
- A) Queue rỗng
- B) Tất cả put() được gọi
- C) task_done() được gọi đủ số lần put()
- D) Không bao giờ block

**Câu 2:** Poison pill trong queue là gì?
- A) Một special item báo hiệu kết thúc
- B) Lỗi trong queue
- C) Item cuối cùng
- D) Item lớn nhất

**Câu 3:** maxsize=0 trong Queue có nghĩa gì?
- A) Không giới hạn
- B) Lỗi
- C) Chỉ 1 phần tử
- D) 0 phần tử

**Đáp án:** 1-C, 2-A, 3-A

## 8. LeetCode practice

**Bài:** "Hệ thống in ấn"

```python
class PrintQueue:
    def __init__(self, printers):
        self.queue = asyncio.Queue()
        self.printers = printers
    
    async def add_job(self, job):
        # Thêm vào queue, chờ có printer
        pass
    
    async def printer_worker(self, printer_id):
        # Lấy job từ queue và in
        pass

# 3 printers, 10 jobs
```

## 9. Bonus

Tạo hệ thống:
- 2 loại producer: ưu tiên cao và thấp
- Consumer ưu tiên xử lý cao trước
- Dùng nhiều Queue hoặc PriorityQueue

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 164 / 2000 |
| **XP** | 1640 |