# Bài 319 — Find Minimum in Rotated Sorted Array (Medium)

## 1. Ôn tập

Từ bài 318, ta đã học Word Search. Hôm nay ta học **Find Minimum in Rotated Array**!

## 2. Mục tiêu bài học

- Tìm min trong rotated sorted array
- Dùng binary search
- O(log n)

## 3. Code chính (có comment)

```python
def find_min(nums):
    """
    Find Minimum
    Input: [3,4,5,1,2]
    Output: 1
    """
    left, right = 0, len(nums) - 1
    
    while left < right:
        mid = (left + right) // 2
        
        # Nếu mid > right, min ở bên phải
        if nums[mid] > nums[right]:
            left = mid + 1
        else:
            # Min ở left hoặc mid
            right = mid
    
    return nums[left]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 319 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3190 |