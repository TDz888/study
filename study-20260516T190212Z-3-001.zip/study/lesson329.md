# Bài 329 — Permutations (Medium)

## 1. Ôn tập

Từ bài 328, ta đã học Letter Combinations. Hôm nay ta học **Permutations**!

## 2. Mục tiêu bài học

- Generate tất cả permutations của array
- Backtracking
- Track visited elements

## 3. Code chính (có comment)

```python
def permute(nums):
    """
    Permutations
    Input: [1,2,3]
    Output: [[1,2,3],[1,3,2],[2,1,3],[2,3,1],[3,1,2],[3,2,1]]
    """
    result = []
    used = [False] * len(nums)
    
    def backtrack(path):
        if len(path) == len(nums):
            result.append(path[:])
            return
        
        for i in range(len(nums)):
            if not used[i]:
                used[i] = True
                path.append(nums[i])
                backtrack(path)
                path.pop()
                used[i] = False
    
    backtrack([])
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 329 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3290 |