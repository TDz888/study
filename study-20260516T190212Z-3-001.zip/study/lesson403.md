# Bài 403 — Min Stack (Easy)

## 1. Ôn tập

Từ bài 402, ta đã học Stack using Queues. Hôm nay ta học **Min Stack**!

## 2. Mục tiêu bài học

- Stack với getMin() trong O(1)
- Dùng auxiliary stack
- Space换取 time

## 3. Code chính (có comment)

```python
class MinStack:
    def __init__(self):
        self.stack = []
        self.min_stack = []
    
    def push(self, val):
        self.stack.append(val)
        if not self.min_stack or val <= self.min_stack[-1]:
            self.min_stack.append(val)
    
    def pop(self):
        val = self.stack.pop()
        if self.min_stack and val == self.min_stack[-1]:
            self.min_stack.pop()
    
    def top(self):
        return self.stack[-1] if self.stack else None
    
    def get_min(self):
        return self.min_stack[-1] if self.min_stack else None
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 403 / 2000 |
| **Chapter** | Stack |
| **XP** | 4030 |