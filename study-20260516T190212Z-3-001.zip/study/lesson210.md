# Bài 210 — LeetCode: Reverse Linked List (Easy)

## 1. Ôn tập

Từ bài 201-209, ta đã học nhiều kỹ thuật: hash, two pointers, stack, DP. Hôm nay ta học **Linked List cơ bản** - reverse!

## 2. Mục tiêu bài học

- Đảo ngược linked list
- Dùng 3 pointers (prev, curr, next)
- Hiểu cách reassign pointers

## 3. Code chính (có comment)

```python
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def reverse_list(head: ListNode) -> ListNode:
    """
    Đảo ngược linked list
    Input: 1→2→3→4→5
    Output: 5→4→3→2→1
    """
    prev = None
    curr = head
    
    while curr:
        next_temp = curr.next  # Lưu next trước
        curr.next = prev        # Đảo pointer
        prev = curr             # Move prev
        curr = next_temp        # Move curr
    
    return prev

# Test
def create_list(arr):
    dummy = ListNode()
    curr = dummy
    for val in arr:
        curr.next = ListNode(val)
        curr = curr.next
    return dummy.next

def to_list(node):
    result = []
    while node:
        result.append(node.val)
        node = node.next
    return result

# Run
head = create_list([1, 2, 3, 4, 5])
reversed_head = reverse_list(head)
print(to_list(reversed_head))  # [5, 4, 3, 2, 1]
```

## 4. Trace chạy code

```
1 → 2 → 3 → 4 → 5 → None

Step 1: prev=None, curr=1
        next_temp=2, curr.next=None
        prev=1, curr=2
        
Step 2: prev=1, curr=2  
        next_temp=3, curr.next=1
        prev=2, curr=3

Step 3: prev=2, curr=3
        next_temp=4, curr.next=2
        prev=3, curr=4
...continues...

Result: None←1←2←3←4←5
```

## 5. Debug tư duy

### Cần save next_temp TRƯỚC khi đảo!
```python
# Sai: Mất reference
curr.next = prev
next_temp = curr.next  # None now!

# Đúng: Save trước
next_temp = curr.next  # Save first!
curr.next = prev       # Then reverse
```

### Return prev, không phải curr!
```python
# Sai: Return current
return curr  # None!

# Đúng: Return previous node
return prev  # New head!
```

## 6. Ghi nhớ nhanh

| Pattern | Use Case |
|---------|----------|
| 3 pointers | Reverse, detect cycle |
| Dummy node | Merge, add to head |
| Fast-slow | Find middle, cycle |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 210 / 2000 |
| **XP** | 2100 |