# Bài 422 — Two Sum IV (Easy)

## 1. Ôn tập

Từ bài 421, ta đã học All Elements in Two BSTs. Hôm nay ta học **Two Sum IV**!

## 2. Mục tiêu bài học

- Tìm 2 nodes sum = k trong BST
- Hash set approach
- O(n)

## 3. Code chính (có comment)

```python
def find_target(root, k):
    """
    Two Sum IV
    Input: root, k
    Output: True nếu tìm được
    """
    seen = set()
    
    def dfs(node):
        if not node:
            return False
        
        complement = k - node.val
        if complement in seen:
            return True
        
        seen.add(node.val)
        
        return dfs(node.left) or dfs(node.right)
    
    return dfs(root)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 422 / 2000 |
| **Chapter** | Trees |
| **XP** | 4220 |