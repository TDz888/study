# Bài 390 — Single Number (Easy)

## 1. Ôn tập

Từ bài 389, ta đã học Missing Number. Hôm nay ta học **Single Number**!

## 2. Mục tiêu bài học

- Tìm element xuất hiện 1 lần
- XOR all elements
- O(n), O(1) space

## 3. Code chính (có comment)

```python
def single_number(nums):
    """
    Single Number
    Input: [2,2,1]
    Output: 1
    """
    result = 0
    
    for num in nums:
        result ^= num
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 390 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3900 |