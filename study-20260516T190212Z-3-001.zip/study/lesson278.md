# Bài 278 — Clone Graph (Medium)

## 1. Ôn tập

Từ bài 277, ta đã học Number of Islands. Hôm nay ta học **clone một graph**!

## 2. Mục tiêu bài học

- Deep copy một graph
- Dùng BFS/DFS với dictionary để map old→new
- Xử lý neighbor chưa được clone

## 3. Code chính (có comment)

```python
class Node:
    def __init__(self, val=0, neighbors=None):
        self.val = val
        self.neighbors = neighbors if neighbors else []

def clone_graph(node):
    """
    Clone graph
    Input: node với val=1, neighbors=[2,3]
    Output: node mới với cùng cấu trúc
    """
    if not node:
        return None
    
    # Dictionary: old_node -> new_node
    visited = {}
    
    # DFS để clone
    def clone(original):
        if original in visited:
            return visited[original]
        
        # Tạo node mới
        new_node = Node(original.val)
        visited[original] = new_node
        
        # Clone neighbors
        for neighbor in original.neighbors:
            new_node.neighbors.append(clone(neighbor))
        
        return new_node
    
    return clone(node)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 278 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2780 |