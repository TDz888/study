# Lesson 80 — Trees (P2) - Binary Search Tree

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 79 - Trees (P1).

**Current Lesson:** Learning **Binary Search Tree (BST)**.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- BST structure
- Insert and search in BST
- BST vs regular tree

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### BST Implementation

```python
class BST:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
    
    def insert(self, val):
        """Insert value into BST"""
        if val < self.val:
            if self.left:
                self.left.insert(val)
            else:
                self.left = BST(val)
        else:
            if self.right:
                self.right.insert(val)
            else:
                self.right = BST(val)
    
    def search(self, val):
        """Search for value in BST"""
        if val == self.val:
            return True
        if val < self.val:
            return self.left.search(val) if self.left else False
        else:
            return self.right.search(val) if self.right else False

# Usage
bst = BST(10)
bst.insert(5)
bst.insert(15)
bst.insert(3)
print(bst.search(5))  # True
print(bst.search(20))  # False
```

### BST Properties

- Left subtree: all values < current node
- Right subtree: all values >= current node
- Search: O(log n) average, O(n) worst case
- Insert: O(log n) average

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is BST property?**

> **Answer:** Left < node < Right

---

**Type 81 to continue**