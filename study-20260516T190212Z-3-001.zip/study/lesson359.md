# Bài 359 — Ransom Note (Easy)

## 1. Ôn tập

Từ bài 358, ta đã học Meeting Rooms. Hôm nay ta học **Ransom Note**!

## 2. Mục tiêu bài học

- Kiểm tra có build được note từ magazine không
- Dùng Counter
- Character frequency check

## 3. Code chính (có comment)

```python
def can_construct(ransom_note, magazine):
    """
    Ransom Note
    Input: ransom_note="a", magazine="b"
    Output: False
    """
    from collections import Counter
    
    ransom_count = Counter(ransom_note)
    magazine_count = Counter(magazine)
    
    for char, count in ransom_count.items():
        if magazine_count[char] < count:
            return False
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 359 / 2000 |
| **Chapter** | String |
| **XP** | 3590 |