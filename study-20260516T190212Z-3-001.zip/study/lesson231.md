# Bài 231 — Longest Consecutive Sequence (Medium)

## 1. Ôn tập

Từ bài 230, ta đã học graph algorithms. Hôm nay ta học **Longest Consecutive Sequence**!

## 2. Mục tiêu bài học

- Tìm dãy số dài nhất liên tiếp
- Không cần sorted array
- Dùng Set + O(n)

## 3. Code chính (có comment)

```python
def longest_consecutive(nums: List[int]) -> int:
    """
    Tìm độ dài dãy liên tiếp dài nhất
    Input: nums=[100,4,200,1,3,2]
    Output: 4 (dãy: 1,2,3,4)
    """
    if not nums:
        return 0
    
    num_set = set(nums)
    max_length = 0
    
    for num in num_set:
        # Chỉ start từ smallest của dãy
        if num - 1 not in num_set:
            current = num
            length = 1
            
            while current + 1 in num_set:
                current += 1
                length += 1
            
            max_length = max(max_length, length)
    
    return max_length
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 231 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2310 |