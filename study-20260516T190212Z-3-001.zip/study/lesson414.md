# Bài 414 — Diameter of Binary Tree (Easy)

## 1. Ôn tập

Từ bài 413, ta đã học Cousins. Hôm nay ta học **Diameter of Binary Tree**!

## 2. Mục tiêu bài học

- Tìm độ dài diameter (longest path)
- Path không nhất thiết qua root
- DFS

## 3. Code chính (có comment)

```python
def diameter_of_tree(root):
    """
    Diameter of Binary Tree
    Input: Tree
    Output: Diameter length
    """
    diameter = 0
    
    def depth(node):
        nonlocal diameter
        if not node:
            return 0
        
        left = depth(node.left)
        right = depth(node.right)
        
        # Diameter có thể đi qua node
        diameter = max(diameter, left + right)
        
        return max(left, right) + 1
    
    depth(root)
    return diameter
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 414 / 2000 |
| **Chapter** | Trees |
| **XP** | 4140 |