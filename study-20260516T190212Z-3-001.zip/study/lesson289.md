# Bài 289 — Subtree of Another Tree (Easy)

## 1. Ôn tập

Từ bài 288, ta đã học Flatten Binary Tree. Hôm nay ta học **kiểm tra subtree**!

## 2. Mục tiêu bài học

- Kiểm tra tree T có phải subtree của S không
- So sánh cấu trúc và values
- Same tree + recursive check

## 3. Code chính (có comment)

def is_subtree(s, t):
    """
    Kiểm tra T có phải subtree của S
    Input: s Tree, t Tree
    Output: True/False
    """
    if not s:
        return False
    if same_tree(s, t):
        return True
    
    # Check left hoặc right subtree
    return is_subtree(s.left, t) or is_subtree(s.right, t)

def same_tree(s, t):
    """
    So sánh 2 tree có identical không
    """
    if not s and not t:
        return True
    if not s or not t:
        return False
    
    return (s.val == t.val and 
            same_tree(s.left, t.left) and 
            same_tree(s.right, t.right))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 289 / 2000 |
| **Chapter** | Trees |
| **XP** | 2890 |