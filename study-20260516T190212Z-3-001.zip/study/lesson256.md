# Bài 256 — Validate BST (Medium)

## 1. Ôn tập

Từ bài 255, ta đã học xóa node trong BST. Hôm nay ta học **kiểm tra xem cây có phải BST không**!

## 2. Mục tiêu bài học

- Kiểm tra BST property: left < root < right
- Dùng bounded range để validation
- Xử lý trường hợp cây con vượt quá giới hạn

## 3. Code chính (có comment)

```python
def is_valid_bst(root: TreeNode) -> bool:
    """
    Kiểm tra cây có phải BST không
    Input: root = [2,1,3]
    Output: True
    """
    def validate(node, min_val, max_val):
        # Base case: node None là valid
        if not node:
            return True
        
        # Node phải nằm trong khoảng (min_val, max_val)
        if node.val <= min_val or node.val >= max_val:
            return False
        
        # Đệ quy kiểm tra cả 2 cây con
        # Bên trái: max = node.val
        # Bên phải: min = node.val
        return (validate(node.left, min_val, node.val) and
                validate(node.right, node.val, max_val))
    
    return validate(root, float('-inf'), float('inf'))
```

## 4. Giải thích ý tưởng

| Khái niệm | Giải thích |
|-----------|------------|
| **min_val, max_val** | Giới hạn của node hiện tại |
| **Left subtree** | Tất cả node phải nhỏ hơn root |
| **Right subtree** | Tất cả node phải lớn hơn root |
| **float('-inf')** | Vô cực âm, không giới hạn dưới |

## 5. Ví dụ

```
Cây này có phải BST không?

       5
      / \
     1   6
        / \
       3   7

Node 6: bên trái có 3
3 < 6 ✓ và 3 > 5 ✗ → KHÔNG phải BST!
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 256 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2560 |