# Lesson 90 — Working with APIs

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 89 - Design Patterns (Behavioral).

**Current Lesson:** Learning **REST API** — working with web services.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- REST API basics
- HTTP methods
- Status codes

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### HTTP Methods

```python
# GET    → Retrieve data (read)
# POST   → Create new data
# PUT    → Update entire data
# PATCH  → Partial update
# DELETE → Remove data
```

### Status Codes

```python
# 2xx - Success
200 - OK
201 - Created
204 - No Content

# 4xx - Client Errors
400 - Bad Request
401 - Unauthorized
403 - Forbidden
404 - Not Found

# 5xx - Server Errors
500 - Internal Server Error
503 - Service Unavailable
```

### API Request Example

```python
import requests

# GET
response = requests.get("https://api.example.com/users")
print(response.json())

# POST
data = {"name": "Alice", "email": "alice@example.com"}
response = requests.post("https://api.example.com/users", json=data)
print(response.status_code)

# PUT
data = {"name": "Alice Updated"}
response = requests.put("https://api.example.com/users/1", json=data)

# DELETE
response = requests.delete("https://api.example.com/users/1")
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does 201 status code mean?**

> **Answer:** Resource created successfully

---

**Type 91 to continue**