# Bài 315 — Count of Range Sum (Hard)

## 1. Ôn tập

Từ bài 314, ta đã học Longest Increasing Path. Hôm nay ta học **Count of Range Sum**!

## 2. Mục tiêu bài học

- Đếm số subarrays với sum trong range [lower, upper]
- Prefix sums + BST/Segment tree
- Merge sort approach

## 3. Code chính (có comment)

```python
def count_range_sum(nums, lower, upper):
    """
    Count Range Sum
    Input: nums=[-2,5,-1], lower=-2, upper=2
    Output: 3 ([-2], [-2,5,-1], [5,-1])
    """
    def merge_sort(arr):
        if len(arr) <= 1:
            return 0
        
        mid = len(arr) // 2
        count = merge_sort(arr[:mid]) + merge_sort(arr[mid:])
        
        # Two pointers cho range
        left = right = mid
        for num in arr[:mid]:
            while right < len(arr) and arr[right] - num < lower:
                right += 1
            while left < len(arr) and arr[left] - num <= upper:
                left += 1
            count += left - right
        
        # Merge sorted
        arr[:mid] = sorted(arr[:mid])
        return count
    
    # Prefix sums
    prefix = [0]
    for num in nums:
        prefix.append(prefix[-1] + num)
    
    return merge_sort(prefix)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 315 / 2000 |
| **Chapter** | Binary Indexed Tree |
| **XP** | 3150 |