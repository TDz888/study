# Bài 291 — Kth Smallest in BST (Medium)

## 1. Ôn tập

Từ bài 290, ta đã học Validate Binary Search Tree. Hôm nay ta học **tìm kth smallest** trong BST!

## 2. Mục tiêu bài học

- Tìm phần tử nhỏ thứ k trong BST
- Inorder traversal gives sorted order
- Optimize: early stop

## 3. Code chính (có comment)

```python
def kth_smallest(root, k):
    """
    Tìm kth smallest
    Input: root, k
    Output: giá trị của kth smallest
    """
    result = None
    count = 0
    
    def inorder(node):
        nonlocal result, count
        if not node or count >= k:
            return
        
        # Left first
        inorder(node.left)
        
        # Visit current
        count += 1
        if count == k:
            result = node.val
            return
        
        # Then right
        inorder(node.right)
    
    inorder(root)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 291 / 2000 |
| **Chapter** | Trees |
| **XP** | 2910 |