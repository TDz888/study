# Lesson 67 — Unit Testing (P1)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 66 - Debugging.

**Current Lesson:** Learning **Unit Testing** — automated testing.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- unittest framework
- Test cases and assertions

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
import unittest

class TestMathFunctions(unittest.TestCase):
    def test_add(self):
        self.assertEqual(1 + 1, 2)
    
    def test_multiply(self):
        self.assertEqual(2 * 3, 6)
    
    def test_divide(self):
        self.assertEqual(10 / 2, 5)

if __name__ == '__main__':
    unittest.main()
```

### Common Assertions

```python
self.assertEqual(a, b)      # a == b
self.assertNotEqual(a, b)   # a != b
self.assertTrue(x)          # x is True
self.assertFalse(x)         # x is False
self.assertIsNone(x)        # x is None
self.assertIn(item, list)   # item in list
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does assertEqual do?**

> **Answer:** Checks if two values are equal

---

**Type 68 to continue**