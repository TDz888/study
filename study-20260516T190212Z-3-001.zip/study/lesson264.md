# Bài 264 — Symmetric Tree (Easy)

## 1. Ôn tập

Từ bài 263, ta đã học Same Tree. Hôm nay ta học **kiểm tra cây đối xứng**!

## 2. Mục tiêu bài học

- Kiểm tra cây có đối xứng qua trục giữa không
- So sánh cây con trái với cây con phải (đảo ngược)
- Dùng helper function

## 3. Code chính (có comment)

```python
def is_symmetric(root: TreeNode) -> bool:
    """
    Kiểm tra cây có đối xứng không
    Input: root = [1,2,2,3,4,4,3]
    Output: True
    """
    if not root:
        return True
    
    # So sánh cây con trái và phải
    return is_mirror(root.left, root.right)

def is_mirror(left, right):
    """So sánh 2 cây có phải là ảnh gương"""
    # Base case: cả 2 đều None
    if not left and not right:
        return True
    
    # Một trong 2 là None
    if not left or not right:
        return False
    
    # Kiểm tra: giống nhau nhưng đảo ngược
    return (left.val == right.val and
            is_mirror(left.left, right.right) and
            is_mirror(left.right, right.left))
```

## 4. Minh họa

```
Cây đối xứng:        Cây không đối xứng:
      1                    1
     / \                  / \
    2   2                2   2
   / \ / \              /   /
  3  4 4  3            3   3

→ Symmetric: True      → Symmetric: False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 264 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2640 |