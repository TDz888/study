# Bài 184 — Practice: Web Scraper Project

## 1. Project Overview

Xây dựng web scraper hoàn chỉnh với:
- Async requests
- Rate limiting
- Error handling
- Caching

## 2. Code chính

```python
import asyncio
import aiohttp
from functools import lru_cache

class AsyncScraper:
    def __init__(self, max_concurrent=5):
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.cache = {}
    
    async def fetch(self, url):
        async with self.semaphore:
            if url in self.cache:
                return self.cache[url]
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    data = await response.text()
                    self.cache[url] = data
                    return data
```

## 3. Tasks

1. Thêm retry logic
2. Thêm logging
3. Thêm data extraction (BeautifulSoup)
4. Unit tests

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 184 / 2000 |
| **XP** | 1840 |