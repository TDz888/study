# Bài 384 — Subarray Sum Equals K (Medium)

## 1. Ôn tập

Từ bài 383, ta đã học Minimum Window Substring. Hôm nay ta học **Subarray Sum Equals K**!

## 2. Mục tiêu bài học

- Đếm subarrays với sum = k
- Prefix sum + hashmap
- O(n)

## 3. Code chính (có comment)

```python
def subarray_sum(nums, k):
    """
    Subarray Sum Equals K
    Input: nums=[1,1,1], k=2
    Output: 2 ([1,1] và [1,1])
    """
    count = 0
    cumulative_sum = 0
    prefix_sum = {0: 1}
    
    for num in nums:
        cumulative_sum += num
        
        if cumulative_sum - k in prefix_sum:
            count += prefix_sum[cumulative_sum - k]
        
        prefix_sum[cumulative_sum] = prefix_sum.get(cumulative_sum, 0) + 1
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 384 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3840 |