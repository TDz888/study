# Bài 429 — Palindrome Linked List (Easy)

## 1. Ôn tập

Từ bài 428, ta đã học Odd Even Linked List. Hôm nay ta học **Palindrome Linked List**!

## 2. Mục tiêu bài học

- Kiểm tra palindrome
- Find middle, reverse second half
- O(n), O(1)

## 3. Code chính (có comment)

```python
def is_palindrome(head):
    """
    Palindrome Linked List
    Input: 1→2→2→1
    Output: True
    """
    if not head or not head.next:
        return True
    
    # Find middle
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    
    # Reverse second half
    prev = None
    current = slow
    while current:
        next_temp = current.next
        current.next = prev
        prev = current
        current = next_temp
    
    # Compare
    left, right = head, prev
    while right:
        if left.val != right.val:
            return False
        left = left.next
        right = right.next
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 429 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4290 |