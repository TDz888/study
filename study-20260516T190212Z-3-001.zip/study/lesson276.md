# Bài 276 — Graph DFS (Depth First Search)

## 1. Ôn tập

Từ bài 275, ta đã học BFS. Hôm nay ta học **DFS** - tìm kiếm theo chiều sâu!

## 2. Mục tiêu bài học

- Duyệt graph đi sâu nhất có thể trước
- Dùng Stack hoặc đệ quy
- Dùng detect cycle, topological sort

## 3. Code chính (có comment)

```python
# Cách 1: Đệ quy
def dfs_recursive(graph, start, visited=None):
    if visited is None:
        visited = set()
    
    visited.add(start)
    print(start, end=" ")
    
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs_recursive(graph, neighbor, visited)

# Cách 2: Iterative (dùng Stack)
def dfs_iterative(graph, start):
    visited = set()
    stack = [start]
    result = []
    
    while stack:
        node = stack.pop()
        if node not in visited:
            visited.add(node)
            result.append(node)
            
            # Thêm neighbors theo thức tự ngược để duyệt đúng
            for neighbor in reversed(graph[node]):
                if neighbor not in visited:
                    stack.append(neighbor)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 276 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2760 |