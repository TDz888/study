# Bài 455 — Surrounded Regions (Medium)

## 1. Ôn tập

Từ bài 454, ta đã học Walls and Gates. Hôm nay ta học **Surrounded Regions**!

## 2. Mục tiêu bài học

- Flip surrounded X to O
- Boundary approach: find O's, mark, flip rest
- BFS from boundaries

## 3. Code chính (có comment)

```python
def solve(board):
    """
    Surrounded Regions
    Input: board
    Output: board với surrounded flipped
    """
    if not board:
        return
    
    rows, cols = len(board), len(board[0])
    
    # BFS from boundary O's
    queue = deque()
    
    # Add boundary cells
    for r in range(rows):
        for c in range(cols):
            if (r == 0 or r == rows-1 or c == 0 or c == cols-1) and board[r][c] == 'O':
                queue.append((r, c))
                board[r][c] = 'D'  # Mark as safe
    
    directions = [(0,1),(0,-1),(1,0),(-1,0)]
    
    while queue:
        r, c = queue.popleft()
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and board[nr][nc] == 'O':
                board[nr][nc] = 'D'
                queue.append((nr, nc))
    
    # Flip
    for r in range(rows):
        for c in range(cols):
            if board[r][c] == 'O':
                board[r][c] = 'X'
            elif board[r][c] == 'D':
                board[r][c] = 'O'
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 455 / 2000 |
| **Chapter** | DFS/BFS |
| **XP** | 4550 |