# Lesson 66 — Debugging

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 65 - Logging.

**Current Lesson:** Learning **Debugging** techniques.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Print debugging
- pdb debugger
- breakpoint()

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Print Debugging

```python
def buggy_function(x):
    print(f"Debug: x = {x}")
    result = x + 1
    print(f"Debug: result = {result}")
    return result

buggy_function(5)
```

### PDB Debugger

```python
import pdb

def calculate(a, b):
    pdb.set_trace()  # Breakpoint
    return a + b

result = calculate(10, 5)

# Commands:
# n - next line
# s - step into function
# p <var> - print variable
# c - continue
# l - list code
```

### Python 3.7+ breakpoint()

```python
def buggy_code(x):
    breakpoint()  # Modern way to set trace
    return x * 2
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does `n` do in pdb?**

> **Answer:** Run next line (don't step into function)

---

**Type 67 to continue**