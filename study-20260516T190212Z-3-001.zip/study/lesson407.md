# Bài 407 — Preorder Traversal (Easy)

## 1. Ôn tập

Từ bài 406, ta đã học Average of Levels. Hôm nay ta học **Preorder Traversal**!

## 2. Mục tiêu bài học

- Preorder: root → left → right
- Recursive và iterative
- DFS pattern

## 3. Code chính (có comment)

```python
# Recursive
def preorder_recursive(root):
    result = []
    
    def preorder(node):
        if not node:
            return
        result.append(node.val)
        preorder(node.left)
        preorder(node.right)
    
    preorder(root)
    return result

# Iterative với stack
def preorder_iterative(root):
    if not root:
        return []
    
    result = []
    stack = [root]
    
    while stack:
        node = stack.pop()
        result.append(node.val)
        
        if node.right:
            stack.append(node.right)
        if node.left:
            stack.append(node.left)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 407 / 2000 |
| **Chapter** | Trees |
| **XP** | 4070 |