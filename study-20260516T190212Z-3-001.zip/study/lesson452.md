# Bài 452 — Max Area of Island (Medium)

## 1. Ôn tập

Từ bài 451, ta đã học LRU Cache. Hôm nay ta học **Max Area of Island**!

## 2. Mục tiêu bài học

- Tìm largest island trong grid
- DFS/BFS exploration
- O(m*n)

## 3. Code chính (có comment)

```python
def max_area_of_island(grid):
    """
    Max Area of Island
    Input: [[0,1],[1,1]]
    Output: 4
    """
    def dfs(r, c):
        if r < 0 or r >= len(grid) or c < 0 or c >= len(grid[0]):
            return 0
        if grid[r][c] == 0:
            return 0
        
        grid[r][c] = 0
        return 1 + dfs(r+1,c) + dfs(r-1,c) + dfs(r,c+1) + dfs(r,c-1)
    
    max_area = 0
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            if grid[r][c] == 1:
                max_area = max(max_area, dfs(r, c))
    
    return max_area
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 452 / 2000 |
| **Chapter** | DFS/BFS |
| **XP** | 4520 |