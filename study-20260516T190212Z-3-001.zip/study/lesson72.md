# Bài 72 — Data Classes

---

## 1. Ôn tập
Học về **Data Classes**.

---

## 2. Mục tiêu
- @dataclass decorator
- Fields
- Methods

---

## 3. Data Classes

```python
from dataclasses import dataclass, field

@dataclass
class Person:
    name: str
    age: int
    email: str = "unknown"  # default
    
    def greet(self):
        return f"Hello, I am {self.name}"

p = Person("Alice", 25)
print(p)  # Person(name='Alice', age=25, email='unknown')
print(p.greet())  # Hello, I am Alice
```

---

## 4. Advanced Fields

```python
from dataclasses import dataclass, field
from typing import List

@dataclass
class Company:
    name: str
    employees: List[str] = field(default_factory=list)
    id: int = field(default=0, compare=False)
    
    def add_employee(self, name):
        self.employees.append(name)

c = Company("Tech Corp")
c.add_employee("Alice")
c.add_employee("Bob")
print(c.employees)  # ['Alice', 'Bob']
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 72 / 2000 |
| **XP** | 720 |
| **Level** | Intermediate |