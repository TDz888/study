# Bài 245 — Binary Tree Right Side View (Medium)

## 1. Ôn tập

Từ bài 244, ta đã học build tree. Hôm nay ta học **Right Side View**!

## 2. Mục tiêu bài học

- Lấy các node nhìn từ phía phải
- Mỗi level lấy node cuối cùng
- BFS hoặc DFS

## 3. Code chính (có comment)

```python
def right_side_view(root: TreeNode) -> List[int]:
    """
    Lấy các node nhìn từ phía phải
    Input: root = [1,2,3,null,5,null,4]
    Output: [1,3,4]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        
        for i in range(level_size):
            node = queue.popleft()
            
            # Lấy node cuối của mỗi level
            if i == level_size - 1:
                result.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 245 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2450 |