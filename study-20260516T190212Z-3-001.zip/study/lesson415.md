# Bài 415 — Invert Binary Tree (Easy)

## 1. Ôn tập

Từ bài 414, ta đã học Diameter. Hôm nay ta học **Invert Binary Tree**!

## 2. Mục tiêu bài học

- Swap left và right của mỗi node
- BFS hoặc DFS
- In-place

## 3. Code chính (có comment)

```python
def invert_tree(root):
    """
    Invert Binary Tree
    Input: [4,2,7,1,3,6,9]
    Output: [4,7,2,9,6,3,1]
    """
    if not root:
        return root
    
    # Swap left và right
    root.left, root.right = root.right, root.left
    
    # Recurse
    invert_tree(root.left)
    invert_tree(root.right)
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 415 / 2000 |
| **Chapter** | Trees |
| **XP** | 4150 |