# Bài 247 — Populating Next Right Pointers (Medium)

## 1. Ôn tập

Từ bài 246, ta đã học average of levels. Hôm nay ta học **Populating Next Right**!

## 2. Mục tiêu bài học

- Kết nối nodes cùng level
- Dùng next pointer
- Constant space

## 3. Code chính (có comment)

```python
def connect(root: 'Node') -> 'Node':
    """
    Kết nối nodes cùng level
    Input: root = [1,2,3,4,5,null,7]
    Output: kết nối next pointers
    """
    if not root:
        return root
    
    leftmost = root
    
    while leftmost:
        curr = leftmost
        dummy = Node(0)  # Dummy để bắt đầu
        prev = dummy
        
        while curr:
            if curr.left:
                prev.next = curr.left
                prev = prev.next
            if curr.right:
                prev.next = curr.right
                prev = prev.next
            
            curr = curr.next
        
        leftmost = dummy.next
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 247 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2470 |