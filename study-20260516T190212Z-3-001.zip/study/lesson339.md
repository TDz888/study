# Bài 339 — Reverse Integer (Easy)

## 1. Ôn tập

Từ bài 338, ta đã học Counting Bits. Hôm nay ta học **Reverse Integer**!

## 2. Mục tiêu bài học

- Đảo ngược digits của integer
- Kiểm tra overflow
- Math-based

## 3. Code chính (có comment)

```python
def reverse(x):
    """
    Reverse Integer
    Input: x=123
    Output: 321
    Input: x=-123
    Output: -321
    """
    sign = -1 if x < 0 else 1
    x = abs(x)
    
    reversed = 0
    while x > 0:
        digit = x % 10
        x //= 10
        
        # Check overflow
        if reversed > (2**31 - 1 - digit) // 10:
            return 0
        
        reversed = reversed * 10 + digit
    
    return sign * reversed
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 339 / 2000 |
| **Chapter** | Math |
| **XP** | 3390 |