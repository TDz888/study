# Lesson 84 — Segment Tree

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 83 - Union-Find.

**Current Lesson:** Learning **Segment Tree** — range query data structure.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Segment tree basics
- Range queries

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
class SegmentTree:
    def __init__(self, arr):
        self.n = len(arr)
        self.tree = [0] * (4 * self.n)
        self.build(arr, 0, 0, self.n - 1)
    
    def build(self, arr, node, start, end):
        if start == end:
            self.tree[node] = arr[start]
        else:
            mid = (start + end) // 2
            self.build(arr, 2*node+1, start, mid)
            self.build(arr, 2*node+2, mid+1, end)
            self.tree[node] = self.tree[2*node+1] + self.tree[2*node+2]
    
    def query(self, node, start, end, l, r):
        if r < start or end < l:
            return 0
        if l <= start and end <= r:
            return self.tree[node]
        
        mid = (start + end) // 2
        return self.query(2*node+1, start, mid, l, r) + \
               self.query(2*node+2, mid+1, end, l, r)

# Usage
arr = [1, 3, 5, 7, 9, 11]
st = SegmentTree(arr)
print(st.query(0, 0, 5, 1, 3))  # Sum of indices 1-3 = 15
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is segment tree used for?**

> **Answer:** Range queries and updates

---

**Type 85 to continue**