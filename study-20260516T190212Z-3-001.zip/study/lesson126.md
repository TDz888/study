# Bài 126 — shutil (Shell Utilities)

---

## 1. shutil module

```python
import shutil

# Copy file
shutil.copy('src.txt', 'dst.txt')

# Copy with metadata
shutil.copy2('src.txt', 'dst.txt')

# Move file
shutil.move('src.txt', 'dst.txt')

# Remove file
shutil.remove('file.txt')

# Remove directory
shutil.rmtree('folder')

# Create archive
shutil.make_archive('backup', 'zip', 'folder_to_backup')
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 126 / 2000 |
| **XP** | 1260 |
| **Level** | Intermediate |