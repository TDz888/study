# Bài 240 — Kth Smallest in BST (Medium)

## 1. Ôn tập

Từ bài 239, ta đã học validate BST. Hôm nay ta học **Kth Smallest**!

## 2. Mục tiêu bài học

- Tìm phần tử thứ K nhỏ nhất
- In-order traversal gives sorted order
- Early termination

## 3. Code chính (có comment)

```python
def kth_smallest(root: TreeNode, k: int) -> int:
    """
    Tìm phần tử thứ K trong BST
    Input: root = [3,1,4,null,2], k = 1
    Output: 1
    """
    result = None
    
    def inorder(node):
        nonlocal result, k
        if not node or k <= 0:
            return
        
        inorder(node.left)
        
        k -= 1
        if k == 0:
            result = node.val
            return
        
        inorder(node.right)
    
    inorder(root)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 240 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2400 |