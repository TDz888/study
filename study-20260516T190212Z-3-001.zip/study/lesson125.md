# Bài 125 — Time Module

---

## 1. time module

```python
import time

# Current timestamp
print(time.time())  # Unix timestamp

# Sleep
print("Start")
time.sleep(1)  # 1 second
print("End")

# Format time
now = time.localtime()
print(time.strftime("%Y-%m-%d %H:%M:%S", now))

# Parse time
parsed = time.strptime("2024-01-15", "%Y-%m-%d")
print(parsed)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 125 / 2000 |
| **XP** | 1250 |
| **Level** | Intermediate |