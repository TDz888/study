# Lesson 70 — Mini Projects

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 69 - Pytest.

**Current Lesson:** **Mini Projects** — applying all knowledge.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Building complete projects
- Combining multiple concepts

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Project 1: Calculator

```python
def calculator(a, b, op):
    """Simple calculator"""
    operations = {
        '+': lambda x, y: x + y,
        '-': lambda x, y: x - y,
        '*': lambda x, y: x * y,
        '/': lambda x, y: x / y if y != 0 else "Error"
    }
    return operations.get(op, lambda x, y: "Invalid")(a, b)

# Test
print(calculator(10, 5, '+'))  # 15
print(calculator(10, 5, '/'))  # 2.0
```

### Project 2: Todo List

```python
class TodoList:
    def __init__(self):
        self.tasks = []
    
    def add(self, task):
        self.tasks.append({"task": task, "done": False})
    
    def complete(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index]["done"] = True
    
    def list_tasks(self):
        return self.tasks
```

### Project 3: Simple Web Scraper

```python
import requests
from bs4 import BeautifulSoup

def scrape_title(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    return soup.title.string if soup.title else "No title"
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What project combines the most concepts?**

> **Answer:** All projects combine multiple skills

---

**Type 71 to continue**