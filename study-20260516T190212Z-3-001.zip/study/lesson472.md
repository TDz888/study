# Lesson 472 — Find All Numbers Disappeared

---

## 1. KNOWLEDGE CONNECTION

Từ bài 471, bạn đã học **Missing Number** với XOR. Bài hôm nay mở rộng: tìm TẤT CẢ các số thiếu trong array 1→n. Sử dụng kỹ thuật đánh dấu trực tiếp trên array.

## 2. TODAY'S MISSION

- Tìm tất cả số không xuất hiện
- In-place với O(1) extra space
- Dùng index làm marker

## 3. CONCEPT FOUNDATION

**Find Disappeared:**
```
Input: [4,3,2,7,8,2,3,1]
Output: [5,6]

Các số từ 1-8: 1,2,3,4,5,6,7,8
Có trong array: 1,2,3,4,7,8
Thiếu: 5,6
```

## 4. MAIN CODE

```python
def find_disappeared(nums):
    """
    Tìm tất cả số thiếu
    
    Input: [4,3,2,7,8,2,3,1]
    Output: [5,6]
    """
    # Mark: negate giá trị tại index-1
    for num in nums:
        idx = abs(num) - 1
        if nums[idx] > 0:
            nums[idx] = -nums[idx]
    
    # Tìm các index chưa bị mark
    result = []
    for i in range(len(nums)):
        if nums[i] > 0:
            result.append(i + 1)
    
    return result
```

## 5. EXECUTION TRACE

```
nums = [4,3,2,7,8,2,3,1]

num=4: idx=3 → nums[3] = -7 (mark 4 đã thấy)
num=3: idx=2 → nums[2] = -2
num=2: idx=1 → nums[1] = -3
num=7: idx=6 → nums[6] = -3
num=8: idx=7 → nums[7] = -1
num=2: idx=1 → đã âm, bỏ qua
num=3: idx=2 → đã âm, bỏ qua  
num=1: idx=0 → nums[0] = -4

nums = [-4,-3,-2,-7, -3,-1,-1]

Positive indices: 4,5 → values: 5,6
Output: [5,6]
```

## 6-13. Memory & Practice

Key: Dùng chính array để mark đã thấy.

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 472 / 2000 |
| **XP** | +25 |