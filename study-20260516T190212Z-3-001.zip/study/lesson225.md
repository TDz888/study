# Bài 225 — Clone Graph (Medium)

## 1. Ôn tập

Từ bài 224, ta đã học DFS trên grid. Hôm nay ta học **Clone Graph** - sao chép một graph!

## 2. Mục tiêu bài học

- Deep copy một graph
- Dùng BFS/DFS với visited dict
- Map old node -> new node

## 3. Code chính (có comment)

```python
class Node:
    def __init__(self, val=0, neighbors=None):
        self.val = val
        self.neighbors = neighbors if neighbors else []

def clone_graph(node: 'Node') -> 'Node':
    """
    Clone graph từ node cho trước
    Input: node với neighbors
    Output: Deep copy của graph
    """
    if not node:
        return None
    
    visited = {}
    
    def dfs(original):
        if original in visited:
            return visited[original]
        
        # Tạo node mới
        clone = Node(original.val)
        visited[original] = clone
        
        # Copy neighbors
        for neighbor in original.neighbors:
            clone.neighbors.append(dfs(neighbor))
        
        return clone
    
    return dfs(node)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 225 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2250 |