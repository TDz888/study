# Bài 374 — Binary Search (Easy)

## 1. Ôn tập

Từ bài 373, ta đã học Reverse Linked List. Hôm nay ta học **Binary Search**!

## 2. Mục tiêu bài học

- Tìm target trong sorted array
- Binary search cơ bản
- O(log n)

## 3. Code chính (có comment)

```python
def binary_search(nums, target):
    """
    Binary Search
    Input: nums=[1,2,3,4,5], target=3
    Output: 2 (index)
    """
    left, right = 0, len(nums) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if nums[mid] == target:
            return mid
        elif nums[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 374 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3740 |