# Lesson 64 — HTTP Requests

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 63 - Regular Expressions (P2).

**Current Lesson:** Learning **HTTP Requests** — making API calls.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- requests library
- GET and POST requests
- Headers and parameters

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
import requests

# GET request
response = requests.get("https://api.github.com")
print(response.status_code)
print(response.json())

# GET with params
params = {"key": "value", "page": 1}
response = requests.get("https://api.example.com", params=params)

# POST request
data = {"username": "admin", "password": "123"}
response = requests.post("https://api.example.com/login", json=data)

# Headers
headers = {"Authorization": "Bearer token"}
response = requests.get("https://api.example.com", headers=headers)
```

### Error Handling

```python
try:
    response = requests.get("https://api.example.com", timeout=5)
    response.raise_for_status()
    print(response.json())
except requests.exceptions.Timeout:
    print("Request timed out")
except requests.exceptions.HTTPError:
    print("HTTP error")
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does response.raise_for_status() do?**

> **Answer:** Raises an exception for bad status codes (4xx, 5xx)

---

**Type 65 to continue**