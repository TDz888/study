# Bài 208 — LeetCode: 3Sum (Medium)

## 1. Ôn tập

Bài 207 dùng Stack cho parentheses. Hôm nay ta kết hợp: **Two Pointers + Duplicate Skip** để giải 3Sum!

## 2. Mục tiêu bài học

- Tìm tất cả bộ 3 số có tổng = 0
- Xử lý duplicates
- Kết hợp multiple techniques

## 3. Code chính (có comment)

```python
from typing import List

def three_sum(nums: List[int]) -> List[List[int]]:
    """
    Tìm tất cả bộ 3 số có tổng = 0
    Input: [-1,0,1,2,-1,-4]
    Output: [[-1,-1,2],[-1,0,1]]
    
    Approach: Sort + Two Pointers
    """
    n = len(nums)
    if n < 3:
        return []
    
    nums.sort()
    result = []
    
    for i in range(n - 2):
        # Skip duplicates cho first number
        if i > 0 and nums[i] == nums[i - 1]:
            continue
        
        # Two pointers cho remaining 2 số
        left = i + 1
        right = n - 1
        
        while left < right:
            total = nums[i] + nums[left] + nums[right]
            
            if total == 0:
                result.append([nums[i], nums[left], nums[right]])
                
                # Skip duplicates cho left và right
                while left < right and nums[left] == nums[left + 1]:
                    left += 1
                while left < right and nums[right] == nums[right - 1]:
                    right -= 1
                
                left += 1
                right -= 1
            
            elif total < 0:
                left += 1  # Cần số lớn hơn
            else:
                right -= 1  # Cần số nhỏ hơn
    
    return result

# Test
nums = [-1, 0, 1, 2, -1, -4]
print(three_sum(nums))
# [[-1, -1, 2], [-1, 0, 1]]
```

## 4. Trace chạy code

```
nums = [-4,-1,-1,0,1,2] (sorted)

i=0: nums[i]=-4
  left=1, right=5: -4-1+2=-3 < 0 → left=2
  left=2, right=5: -4-1+2=-3 < 0 → left=3
  left=3, right=5: -4+0+2=-2 < 0 → left=4
  left=4, right=5: -4+1+2=-1 < 0 → left=5 → exit

i=1: nums[i]=-1, skip duplicate với i=0? No
  left=4, right=5: -1+1+2=2 > 0 → right=4 → exit

i=2: nums[i]=-1 (duplicate, skip!)

...tiếp tục...
```

## 5. Debug tư duy

### Tại sao cần skip duplicates 3 lần?
```python
# 1. Skip first number
if i > 0 and nums[i] == nums[i-1]: continue

# 2. Skip duplicate left sau khi find solution
while left < right and nums[left] == nums[left+1]:
    left += 1

# 3. Skip duplicate right sau khi find solution  
while left < right and nums[right] == nums[right-1]:
    right -= 1
```

### Time complexity?
```python
# O(n²) - n cho loop i, n cho two pointers
# Sort: O(n log n)
# Total: O(n²)
```

## 6. Ghi nhớ nhanh

| Step | Technique |
|------|-----------|
| Sort | Để skip duplicates |
| Loop i | Fix first element |
| Two pointers | Tìm 2 element còn lại |
| Skip duplicates | 3 lần |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 208 / 2000 |
| **XP** | 2080 |