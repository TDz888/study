# Bài 55 — Decorators

---

## 1. Ôn tập
Bài 54 đã học về Modules và Packages. Giờ học **Decorator** — cách modify behavior của hàm.

---

## 2. Mục tiêu bài học
- Hiểu decorator là gì
- Biết cách viết decorator đơn giản
- Nắm vững @decorator syntax
- Xử lý decorator với arguments

---

## 3. Code chính (có comment)

### Decorator cơ bản
```python
# Bước 1: Tạo decorator function
def my_decorator(func):
    """Decorator đơn giản"""
    def wrapper():
        print("=== Before ===")  # Code chạy trước
        func()                   # Gọi hàm gốc
        print("=== After ===")   # Code chạy sau
    return wrapper

# Bước 2: Áp dụng decorator với @
@my_decorator
def say_hello():
    print("Hello!")

# Bước 3: Gọi hàm
say_hello()

# Output:
# === Before ===
# Hello!
# === After ===
```

### Decorator với Arguments
```python
def repeat(times):
    """Decorator có tham số"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(times):
                func(*args, **kwargs)
        return wrapper
    return decorator

@repeat(3)  # Gọi hàm repeat(3) trả về decorator
def greet(name):
    print(f"Hello {name}!")

greet("World")
# Hello World!
# Hello World!
# Hello World!
```

### Giữ nguyên metadata với functools
```python
import functools

def my_decorator(func):
    @functools.wraps(func)  # QUAN TRỌNG! Giữ metadata của hàm gốc
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def example():
    """Example docstring"""
    pass

print(example.__name__)  # "example" (không phải "wrapper")
print(example.__doc__)   # "Example docstring"
```

---

## 4. Trace chạy code

```
@my_decorator
def say_hello():
    print("Hello!")

Flow:
1. Python thấy @my_decorator
2. Gọi my_decorator(say_hello)
3. Nhận lại function wrapper
4. Gán wrapper cho say_hello

Khi gọi say_hello():
→ Gọi wrapper()
→ print("=== Before ===")
→ Gọi say_hello() gốc
→ print("Hello!")
→ print("=== After ===")
```

---

## 5. Debug tư duy

### ❌ Lỗi 1 — Quên return wrapper
```python
# LỖI! Không return wrapper
def my_decorator(func):
    def wrapper():
        print("Before")
        func()

# Khi gọi hàm → None
@my_decorator
def test():
    print("Hi")

result = test()  # Lỗi! test là None

# ✅ Sửa
def my_decorator(func):
    def wrapper():
        print("Before")
        func()
    return wrapper  # PHẢI RETURN
```

### ❌ Lỗi 2 — Quên @functools.wraps
```python
# LỖI! Mất metadata
def decorator(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@decorator
def my_func():
    """My docstring"""
    pass

print(my_func.__name__)  # "wrapper" - SAI!

# ✅ Sửa
import functools
def decorator(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper
```

### ❌ Lỗi 3 — Nhầm @decorator và @decorator()
```python
# Decorator KHÔNG có tham số
@my_decorator
def func(): ...

# Decorator CÓ tham số
@decorator(arg)
def func(): ...

# Nhầm → LỖI!
```

---

## 6. Ghi nhớ nhanh

| Khái niệm | Ý nghĩa |
|-----------|---------|
| Decorator | Hàm nhận vào hàm, trả về hàm mới |
| @decorator | Syntax để áp dụng decorator |
| @functools.wraps | Giữ nguyên metadata |
| *args, **kwargs | Nhận mọi tham số |

**MẸO NHỚ:** Decorator = "bọc" thêm code xung quanh hàm gốc.

---

## 7. Mini test (3 câu)

**Câu 1:** Output là gì?
```python
def decor(func):
    def wrapper():
        print("A")
        func()
        print("B")
    return wrapper

@decor
def test():
    print("C")

test()
```
> Đáp án: **A C B**

**Câu 2:** Decorator nào giữ nguyên metadata?
> Đáp án: **`@functools.wraps(func)`**

**Câu 3:** 
```python
@repeat(2)
def say(): ...
```
Có mấy lớp wrapper?
> Đáp án: **2 lớp** (repeat → decorator → wrapper)

---

## 8. LeetCode Practice

### Bài tập: Timer Decorator
**Yêu cầu:** Viết decorator đo thời gian chạy hàm

**Input:** (không có)

**Output:**
```
Function took X.XX seconds
```

**✅ Đáp án:**
```python
import functools
import time

def timer(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"Function took {end - start:.2f} seconds")
        return result
    return wrapper

@timer
def slow_function():
    time.sleep(1)
    print("Done")

slow_function()
```

---

## 9. Bonus (nếu học tốt)

**Thử thách:** Viết decorator kiểm tra arguments

**Yêu cầu:** Hàm chia phải có số chia != 0

**Input:**
```
divide(10, 2)
divide(10, 0)
```

**Output:**
```
5
Error: Số chia không được là 0
```

**✅ Đáp án:**
```python
import functools

def validate_divide(func):
    @functools.wraps(func)
    def wrapper(a, b):
        if b == 0:
            return "Error: Số chia không được là 0"
        return func(a, b)
    return wrapper

@validate_divide
def divide(a, b):
    return a / b

print(divide(10, 2))  # 5.0
print(divide(10, 0))  # Error: Số chia không được là 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 55 / 2000 |
| **Chapter** | 3 (Functions) |
| **XP** | 550 (+20 XP khi hoàn thành) |
| **Level** | Advanced |

---

**🎉 Bạn đã hoàn thành Bài 55!**

Gõ **56** để học tiếp Bài 56 (Generators) →