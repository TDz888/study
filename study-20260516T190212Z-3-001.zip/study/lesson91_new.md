# Lesson 91 — Flask Basics

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 90 - Working with APIs.

**Current Lesson:** Learning **Flask** — lightweight web framework.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Flask basics
- Creating routes
- Handling requests

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Setup and Hello World

```python
# Install: pip install flask

from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return 'Hello, World!'

@app.route('/api/users')
def users():
    return {'users': ['Alice', 'Bob']}

if __name__ == '__main__':
    app.run(debug=True)
```

### Request Handling

```python
from flask import request, jsonify

@app.route('/greet', methods=['GET'])
def greet():
    name = request.args.get('name', 'Guest')
    return f'Hello, {name}!'

@app.route('/api/data', methods=['POST'])
def create():
    data = request.json
    return jsonify({'created': data}), 201
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**How do you run Flask app in debug mode?**

> **Answer:** app.run(debug=True)

---

**Type 92 to continue**