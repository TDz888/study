# Bài 321 — Longest Consecutive Sequence (Medium)

## 1. Ôn tập

Từ bài 320, ta đã học Median of Two Sorted Arrays. Hôm nay ta học **Longest Consecutive Sequence**!

## 2. Mục tiêu bài học

- Tìm longest consecutive sequence trong unsorted array
- Không dùng sorting - dùng hash set
- O(n)

## 3. Code chính (có comment)

```python
def longest_consecutive(nums):
    """
    Longest Consecutive
    Input: [100,4,200,1,3,2]
    Output: 4 ([1,2,3,4])
    """
    if not nums:
        return 0
    
    num_set = set(nums)
    longest = 0
    
    for num in num_set:
        # Chỉ start nếu là begin của sequence
        if num - 1 not in num_set:
            current = num
            streak = 1
            
            while current + 1 in num_set:
                current += 1
                streak += 1
            
            longest = max(longest, streak)
    
    return longest
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 321 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3210 |