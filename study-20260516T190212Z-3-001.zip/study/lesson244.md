# Bài 244 — Construct Binary Tree from Inorder Postorder (Medium)

## 1. Ôn tập

Từ bài 243, ta đã học preorder+inorder. Hôm nay ta học **Inorder + Postorder**!

## 2. Mục tiêu bài học

- Build tree từ inorder và postorder
- Postorder: left, right, root
- Tương tự preorder nhưng reverse

## 3. Code chính (có comment)

```python
def build_tree_in_post(inorder: List[int], postorder: List[int]) -> TreeNode:
    """
    Build tree từ inorder và postorder
    Input: in=[9,3,15,20,7], post=[9,15,7,20,3]
    Output: [3,9,20,null,null,15,7]
    """
    if not inorder or not postorder:
        return None
    
    index_map = {val: i for i, val in enumerate(inorder)}
    
    def build(in_start, in_end, post_start, post_end):
        if in_start > in_end:
            return None
        
        root_val = postorder[post_end]
        root = TreeNode(root_val)
        
        in_root_idx = index_map[root_val]
        right_size = in_end - in_root_idx
        
        root.left = build(in_start, in_root_idx-1, post_start, post_end-right_size-1)
        root.right = build(in_root_idx+1, in_end, post_end-right_size, post_end-1)
        
        return root
    
    return build(0, len(inorder)-1, 0, len(postorder)-1)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 244 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2440 |