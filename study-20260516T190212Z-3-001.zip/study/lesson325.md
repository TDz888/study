# Bài 325 — Regular Expression Matching (Hard)

## 1. Ôn tập

Từ bài 324, ta đã học Largest Rectangle in Histogram. Hôm nay ta học **Regular Expression Matching**!

## 2. Mục tiêu bài học

- Match string với pattern (`.` và `*`)
- Dynamic Programming
- Complex pattern matching

## 3. Code chính (có comment)

```python
def is_match(s, p):
    """
    Regular Expression Matching
    Input: s="aa", p="a*"
    Output: True
    """
    m, n = len(s), len(p)
    # dp[i][j] = s[:i] matches p[:j]
    dp = [[False] * (n + 1) for _ in range(m + 1)]
    dp[0][0] = True
    
    # Patterns like a* can match empty
    for j in range(2, n + 1):
        if p[j-1] == '*':
            dp[0][j] = dp[0][j-2]
    
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if p[j-1] == '*':
                dp[i][j] = dp[i][j-2]  # 0 occurrences
                if p[j-2] == '.' or p[j-2] == s[i-1]:
                    dp[i][j] = dp[i][j] or dp[i-1][j]  # 1+ occurrences
            elif p[j-1] == '.' or p[j-1] == s[i-1]:
                dp[i][j] = dp[i-1][j-1]
    
    return dp[m][n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 325 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3250 |