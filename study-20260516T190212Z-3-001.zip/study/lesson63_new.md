# Lesson 63 — Regular Expressions (P2)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 62 - Regular Expressions (P1).

**Current Lesson:** Advanced regex techniques.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Character classes
- Quantifiers
- Groups and alternation

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Character Classes

```python
# [abc] - any of a, b, or c
re.search(r"[aeiou]", "hello")  # 'e'

# [a-z] - range
re.search(r"[a-z]+", "Hello123")  # 'ello'

# [^abc] - not a, b, or c
re.search(r"[^0-9]", "123abc")  # 'a'
```

### Quantifiers

```python
# * - 0 or more
re.search(r"ab*c", "ac")  # 'ac'

# + - 1 or more
re.search(r"ab+c", "abbbc")  # 'abbbc'

# ? - 0 or 1
re.search(r"colou?r", "color")  # 'color'

# {n} - exactly n
re.search(r"\d{4}", "123456")  # '1234'

# {n,} - n or more
re.search(r"\d{2,}", "123456")  # '123456'
```

### Groups

```python
# Capture groups
match = re.search(r"(\d{3})-(\d{4})", "123-4567")
print(match.group(1))  # 123
print(match.group(2))  # 4567
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does + mean in regex?**

> **Answer:** One or more of the preceding element

---

**Type 64 to continue**