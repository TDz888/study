# Bài 288 — Flatten Binary Tree to Linked List (Medium)

## 1. Ôn tập

Từ bài 287, ta đã học Populating Next Right Pointers. Hôm nay ta học **flatten tree** thành linked list!

## 2. Mục tiêu bài học

- Convert tree thành linked list (right là next)
- Không dùng extra space (in-place)
- Right preorder traversal

## 3. Code chính (có comment)

```python
def flatten(root):
    """
    Flatten to linked list
    Input: Tree
    Output: Linked list (right là next)
    """
    if not root:
        return
    
    # Find rightmost của left subtree
    def helper(node):
        if not node:
            return None
        
        # Nếu left tồn tại, flatten trước
        if node.left:
            # Recursively flatten left
            helper(node.left)
            
            # Move left subtree to right
            left_tail = node.left
            while left_tail.right:
                left_tail = left_tail.right
            
            left_tail.right = node.right
            node.right = node.left
            node.left = None
        
        # Continue với right
        helper(node.right)
    
    helper(root)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 288 / 2000 |
| **Chapter** | Trees |
| **XP** | 2880 |