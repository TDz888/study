# Bài 157 — asyncio

---

## 1. Basic asyncio

```python
import asyncio

async def task1():
    await asyncio.sleep(1)
    return "Task 1 done"

async def task2():
    await asyncio.sleep(0.5)
    return "Task 2 done"

async def main():
    # Sequential
    r1 = await task1()
    r2 = await task2()
    print(r1, r2)
    
    # Parallel (gather)
    results = await asyncio.gather(task1(), task2())
    print(results)

asyncio.run(main())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 157 / 2000 |
| **XP** | 1570 |