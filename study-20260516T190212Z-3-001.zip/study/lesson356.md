# Bài 356 — Assign Cookies (Easy)

## 1. Ôn tập

Từ bài 355, ta đã học Array Partition. Hôm nay ta học **Assign Cookies**!

## 2. Mục tiêu bài học

- Satisfy maximum children
- Greedy: give smallest cookie that satisfies
- Sort both arrays

## 3. Code chính (có comment)

```python
def find_content_children(s, g):
    """
    Assign Cookies
    Input: s=[1,2], g=[1,2,3]
    Output: 2
    """
    s.sort()
    g.sort()
    
    i = j = 0
    while i < len(s) and j < len(g):
        if s[i] >= g[j]:
            i += 1
            j += 1
        else:
            i += 1
    
    return j
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 356 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3560 |