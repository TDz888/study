# Bài 298 — Symmetric Tree (Easy)

## 1. Ôn tập

Từ bài 297, ta đã học Same Tree. Hôm nay ta học **kiểm tra symmetric tree**!

## 2. Mục tiêu bài học

- Kiểm tra tree có mirror symmetry không
- So sánh left subtree với right reversed
- Dùng helper function

## 3. Code chính (có comment)

```python
def is_symmetric(root):
    """
    Kiểm tra symmetric
    Input: Tree
    Output: True nếu symmetric
    """
    if not root:
        return True
    
    def is_mirror(left, right):
        if not left and not right:
            return True
        if not left or not right:
            return False
        
        return (left.val == right.val and
                is_mirror(left.left, right.right) and
                is_mirror(left.right, right.left))
    
    return is_mirror(root.left, root.right)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 298 / 2000 |
| **Chapter** | Trees |
| **XP** | 2980 |