# Bài 59 — JSON Handling

---

## 1. Ôn tập
Học xử lý **JSON** trong Python.

---

## 2. Mục tiêu
- Load JSON
- Dump JSON
- Nested JSON
- Validation

---

## 3. JSON Operations

```python
import json

# Load JSON từ string
data = json.loads('{"name": "Alice", "age": 25}')
print(data)  # {'name': 'Alice', 'age': 25}

# Load JSON từ file
with open("data.json", "r") as f:
    data = json.load(f)

# Dump to string
json_str = json.dumps(data, indent=2)

# Dump to file
with open("output.json", "w") as f:
    json.dump(data, f, indent=2)
```

---

## 4. Custom Encoder

```python
class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

json.dumps(data, cls=MyEncoder)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 59 / 2000 |
| **XP** | 590 |
| **Level** | Intermediate |