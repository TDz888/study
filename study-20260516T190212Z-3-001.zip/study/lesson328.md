# Bài 328 — Letter Combinations of Phone Number (Medium)

## 1. Ôn tập

Từ bài 327, ta đã học 3Sum Closest. Hôm nay ta học **Letter Combinations**!

## 2. Mục tiêu bài học

- Convert số phone thành letters
- Backtracking
- Recursive generation

## 3. Code chính (có comment)

```python
def letter_combinations(digits):
    """
    Letter Combinations
    Input: "23"
    Output: ["ad","ae","af","bd","be","bf","cd","ce","cf"]
    """
    if not digits:
        return []
    
    phone = {
        '2': 'abc', '3': 'def', '4': 'ghi',
        '5': 'jkl', '6': 'mno', '7': 'pqrs',
        '8': 'tuv', '9': 'wxyz'
    }
    
    result = []
    
    def backtrack(index, path):
        if index == len(digits):
            result.append(''.join(path))
            return
        
        for char in phone[digits[index]]:
            path.append(char)
            backtrack(index + 1, path)
            path.pop()
    
    backtrack(0, [])
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 328 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3280 |