# Bài 297 — Same Tree (Easy)

## 1. Ôn tập

Từ bài 296, ta đã học Balanced Binary Tree. Hôm nay ta học **so sánh 2 trees**!

## 2. Mục tiêu bài học

- Kiểm tra 2 trees có identical không
- So sánh structure và values
- Recursive approach

## 3. Code chính (có comment)

```python
def is_same_tree(p, q):
    """
    So sánh 2 trees
    Input: p, q Trees
    Output: True nếu identical
    """
    # Base case: both null
    if not p and not q:
        return True
    
    # One is null, one is not
    if not p or not q:
        return False
    
    # Check current + children
    return (p.val == q.val and
            is_same_tree(p.left, q.left) and
            is_same_tree(p.right, q.right))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 297 / 2000 |
| **Chapter** | Trees |
| **XP** | 2970 |