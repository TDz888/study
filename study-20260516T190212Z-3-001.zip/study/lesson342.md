# Bài 342 — Median of Two Sorted Arrays (Hard)

## 1. Ôn tập

Từ bài 341, ta đã học Longest Palindromic Substring. Hôm nay ta học **Median of Two Sorted Arrays**!

## 2. Mục tiêu bài học

- Tìm median của 2 sorted arrays
- Binary search để partition
- O(log (m+n))

## 3. Code chính (có comment)

```python
def find_median(nums1, nums2):
    """
    Median of Two Sorted Arrays
    Input: [1,3], [2]
    Output: 2.0
    """
    if len(nums1) > len(nums2):
        nums1, nums2 = nums2, nums1
    
    m, n = len(nums1), len(nums2)
    left, right = 0, m
    
    while left <= right:
        i = (left + right) // 2
        j = (m + n + 1) // 2 - i
        
        max_left1 = float('-inf') if i == 0 else nums1[i-1]
        min_right1 = float('inf') if i == m else nums1[i]
        max_left2 = float('-inf') if j == 0 else nums2[j-1]
        min_right2 = float('inf') if j == n else nums2[j]
        
        if max_left1 <= min_right2 and max_left2 <= min_right1:
            if (m + n) % 2 == 0:
                return (max(max_left1, max_left2) + min(min_right1, min_right2)) / 2
            return max(max_left1, max_left2)
        elif max_left1 > min_right2:
            right = i - 1
        else:
            left = i + 1
    
    return 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 342 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3420 |