# Bài 175 — Generator Expressions

## 1. Ôn tập

List comprehension: `[x for x in items]`
Generator expression: `(x for x in items)` - khác ở đâu?

## 2. Mục tiêu bài học

- Phân biệt list comprehension và generator expression
- Khi nào dùng cái nào
- Memory efficiency

## 3. Code chính (có comment)

```python
# List comprehension - TẠO NGAY list đầy đủ
square_list = [x**2 for x in range(1000000)]  # ~8MB RAM

# Generator expression - LAZY, chỉ tạo khi cần
square_gen = (x**2 for x in range(1000000))  # ~few bytes RAM!

# So sánh:
print(type([1, 2, 3]))        # <class 'list'>
print(type((x for x in [1,2,3])))  # <class 'generator'>

# Cách dùng generator expression
result = sum(x**2 for x in range(10))
print(result)  # 285

# Với function có tham số
max_val = max(x for x in [3, 1, 4, 1, 5])
print(max_val)  # 5

# Khi nào dùng Generator Expression:
# 1. Không cần list đầy đủ
# 2. Data lớn
# 3. Pass làm tham số cho function
```

## 4. Trace chạy code

```
285
5
```

## 5. Debug tư duy

### Generator expression = Iterator
```python
gen = (x for x in range(3))
print(list(gen))  # [0, 1, 2]
print(list(gen))  # [] - đã exhausted!

# Phải tạo lại
gen = (x for x in range(3))
```

### KHÔNG dùng trong:
```python
# List làm gì thì generator không làm được!
print([1, 2, 3][0])  # OK
print((x for x in range(3))[0])  # Error!
```

## 6. Ghi nhớ nhanh

| Loại | Cú pháp | Memory |
|------|---------|--------|
| List | `[...]` | Nhiều |
| Generator | `(...)` | Ít |
| Dict | `{k: v ...}` | Nhiều |
| Gen dict | `(k: v for ...)` | Ít |

## 7. Mini test (3 câu)

**Câu 1:** `(x for x in range(5))` là gì?
- A) List comprehension
- B) Generator expression
- C) Dict comprehension
- D) Set

**Câu 2:** Generator expression dùng memory như thế nào?
- A) Nhiều như list
- B) Ít hơn nhiều
- C) Bằng nhau
- D) Không dùng

**Câu 3:** max(sum(x for x in range(n))) có được không?
- A) Có - syntax đúng
- B) Không - syntax sai
- C) Chỉ trong Python 4
- D) None

**Đáp án:** 1-B, 2-B, 3-A

## 8. LeetCode practice

**Bài:** "Memory Efficient Sum"

```python
# Tính tổng bình phương 1 tỷ số mà KHÔNG dùng nhiều memory
def efficient_sum(n):
    return sum(x**2 for x in range(n))

# Test với số nhỏ
print(efficient_sum(1000000))
```

## 9. Bonus

So sánh:
- Time của `sum([x**2 for x in range(100000)])` vs `sum(x**2 for x in range(100000))`
- Memory sử dụng

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 175 / 2000 |
| **XP** | 1750 |