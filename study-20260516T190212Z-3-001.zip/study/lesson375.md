# Bài 375 — Search in Rotated Array (Medium)

## 1. Ôn tập

Từ bài 374, ta đã học Binary Search. Hôm nay ta học **Search in Rotated Array**!

## 2. Mục tiêu bài học

- Tìm target trong rotated sorted array
- Modified binary search
- O(log n)

## 3. Code chính (có comment)

```python
def search(nums, target):
    """
    Search Rotated Array
    Input: nums=[4,5,6,7,0,1,2], target=0
    Output: 4
    """
    left, right = 0, len(nums) - 1
    
    while left <= right:
        mid = (left + right) // 2
        
        if nums[mid] == target:
            return mid
        
        if nums[left] <= nums[mid]:
            if nums[left] <= target < nums[mid]:
                right = mid - 1
            else:
                left = mid + 1
        else:
            if nums[mid] < target <= nums[right]:
                left = mid + 1
            else:
                right = mid - 1
    
    return -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 375 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3750 |