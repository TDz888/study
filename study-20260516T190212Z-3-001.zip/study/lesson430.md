# Bài 430 — Copy List with Random Pointer (Medium)

## 1. Ôn tập

Từ bài 429, ta đã học Palindrome Linked List. Hôm nay ta học **Copy List with Random Pointer**!

## 2. Mục tiêu bài học

- Deep copy list với random pointer
- Hash map approach hoặc interweaving
- O(n)

## 3. Code chính (có comment)

```python
def copy_random_list(head):
    """
    Copy List with Random Pointer
    Input: head với random pointers
    Output: Deep copy
    """
    if not head:
        return None
    
    # Hash map: old -> new
    map = {}
    
    # First pass: create nodes
    current = head
    while current:
        map[current] = Node(current.val)
        current = current.next
    
    # Second pass: link pointers
    current = head
    while current:
        map[current].next = map.get(current.next)
        map[current].random = map.get(current.random)
        current = current.next
    
    return map[head]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 430 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4300 |