# Lesson 59 — JSON Handling

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 58 - Virtual Environments.

**Current Lesson:** Learning **JSON** — data interchange format.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Load JSON (from string/file)
- Dump JSON (to string/file)
- Nested JSON handling

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
import json

# Load from string
data = json.loads('{"name": "Alice", "age": 25}')
print(data)  # {'name': 'Alice', 'age': 25}

# Load from file
with open("data.json", "r") as f:
    data = json.load(f)

# Dump to string
json_str = json.dumps(data, indent=2)

# Dump to file
with open("output.json", "w") as f:
    json.dump(data, f, indent=2)
```

### Custom Encoder

```python
class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

json.dumps(data, cls=MyEncoder)
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is the difference between json.load() and json.loads()?**

> **Answer:** load() reads from file, loads() reads from string

---

**Type 60 to continue**