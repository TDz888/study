# Bài 139 — inspect module

---

## 1. inspect module

```python
import inspect

def my_function(a, b, c=10):
    """Docstring for my function"""
    pass

# Get signature
sig = inspect.signature(my_function)
print(sig)  # (a, b, c=10)

# Get parameters
for name, param in sig.parameters.items():
    print(name, param.default, param.kind)

# Get source code
print(inspect.getsource(my_function))

# Get docstring
print(inspect.getdoc(my_function))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 139 / 2000 |
| **XP** | 1390 |
| **Level** | Advanced |