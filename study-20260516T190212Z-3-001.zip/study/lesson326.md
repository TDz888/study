# Bài 326 — Container With Most Water (Medium)

## 1. Ôn tập

Từ bài 325, ta đã học Regular Expression Matching. Hôm nay ta học **Container With Most Water**!

## 2. Mục tiêu bài học

- Tìm container chứa nhiều nước nhất
- Two pointers từ 2 đầu
- Move pointer nhỏ hơn

## 3. Code chính (có comment)

```python
def max_area(height):
    """
    Max Area
    Input: [1,8,6,2,5,4,8,3,7]
    Output: 49 (8*7)
    """
    left, right = 0, len(height) - 1
    max_water = 0
    
    while left < right:
        # Tính area
        h = min(height[left], height[right])
        w = right - left
        max_water = max(max_water, h * w)
        
        # Move pointer nhỏ hơn
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    
    return max_water
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 326 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3260 |