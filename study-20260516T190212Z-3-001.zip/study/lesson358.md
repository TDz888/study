# Bài 358 — Meeting Rooms (Easy)

## 1. Ôn tập

Từ bài 357, ta đã học Non-overlapping Intervals. Hôm nay ta học **Meeting Rooms**!

## 2. Mục tiêu bài học

- Kiểm tra có conflict không
- Sort by start time
- Compare adjacent intervals

## 3. Code chính (có comment)

```python
def can_attend_meetings(intervals):
    """
    Meeting Rooms
    Input: [[0,30],[5,10],[15,20]]
    Output: False (0,30 và 5,10 overlap)
    """
    if not intervals:
        return True
    
    intervals.sort(key=lambda x: x[0])
    
    for i in range(1, len(intervals)):
        if intervals[i][0] < intervals[i-1][1]:
            return False
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 358 / 2000 |
| **Chapter** | Interval |
| **XP** | 3580 |