# Bài 141 — pydoc and help

---

## 1. Using help

```python
# help() function
help(print)
help(list.append)

# Without printing
info = help(print, return=True)
print(info)

# Using pydoc
# python -m pydoc open
# python -m pydoc -w mymodule  # Generate HTML
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 141 / 2000 |
| **XP** | 1410 |
| **Level** | Beginner |