# Lesson 60 — CSV Handling

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 59 - JSON Handling.

**Current Lesson:** Learning **CSV** — comma-separated values.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Reading CSV files
- Writing CSV files
- DictReader and DictWriter

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Reading CSV

```python
import csv

# Basic reading
with open("data.csv", "r", encoding="utf-8") as f:
    reader = csv.reader(f)
    for row in reader:
        print(row)

# With header (DictReader)
with open("data.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["name"])
```

### Writing CSV

```python
# Simple writing
with open("output.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Age"])
    writer.writerow(["Alice", 25])

# DictWriter
with open("output.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["Name", "Age"])
    writer.writeheader()
    writer.writerow({"Name": "Alice", "Age": 25})
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does newline="" do in csv.writer?**

> **Answer:** Prevents extra blank rows on Windows

---

**Type 61 to continue**