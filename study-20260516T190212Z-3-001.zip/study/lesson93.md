# Bài 93 — SQLite with Python

---

## 1. SQLite Basics

```python
import sqlite3

# Tạo connection
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Tạo bảng
cursor.execute('''CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT
)''')

# Insert
cursor.execute("INSERT INTO users (name, email) VALUES (?, ?)", ('Alice', 'alice@email.com'))
conn.commit()

# Select
cursor.execute("SELECT * FROM users")
rows = cursor.fetchall()
for row in rows:
    print(row)

conn.close()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 93 / 2000 |
| **XP** | 930 |
| **Level** | Intermediate |