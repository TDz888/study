# Bài 162 — asyncio.Event

## 1. Ôn tập

Bài trước, ta đã học `Lock` - dùng để bảo vệ tài nguyên chia sẻ, chỉ cho phép 1 task truy cập tại một thời điểm. Nhưng nếu ta cần thông báo cho các task khác biết khi có sự kiện xảy ra thì sao?

## 2. Mục tiêu bài học

- Hiểu `asyncio.Event` - cơ chế thông báo giữa các task
- Học cách dùng Event để đồng bộ hóa
- Phân biệt Event với Lock và Condition

## 3. Code chính (có comment)

```python
import asyncio

async def wait_for_event(event, name):
    """Task chờ cho đến khi event được set"""
    print(f"{name}: Đang chờ event...")
    await event.wait()  # Chờ cho đến khi event.set() được gọi
    print(f"{name}: Event đã được set! Tiếp tục làm việc")

async def trigger_event(event, name):
    """Task thông báo event đã sẵn sàng"""
    await asyncio.sleep(2)  # Làm gì đó trước
    print(f"{name}: Setting event...")
    event.set()  # Báo cho tất cả task đang chờ

async def main():
    event = asyncio.Event()
    
    # Tạo nhiều task chờ event
    tasks = [
        wait_for_event(event, "Task-A"),
        wait_for_event(event, "Task-B"),
        wait_for_event(event, "Task-C"),
    ]
    
    # Task trigger event
    trigger = trigger_event(event, "Trigger")
    
    await asyncio.gather(trigger, *tasks)
    print("Hoàn thành!")

asyncio.run(main())
```

## 4. Trace chạy code

```
Task-A: Đang chờ event...
Task-B: Đang chờ event...
Task-C: Đang chờ event...
Trigger: Setting event...
Task-A: Event đã được set! Tiếp tục làm việc
Task-B: Event đã được set! Tiếp tục làm việc
Task-C: Event đã được set! Tiếp tục làm việc
Hoàn thành!
```

## 5. Debug tư duy

### Sai lầm thường gặp
**Sai:** Dùng Event như Lock

```python
# Sai - Event không block như Lock
async with event:  # Error!
    do_something()
```

**Đúng:** Event chỉ dùng để thông báo

```python
# Correct
await event.wait()  # Chờ
event.set()         # Báo
event.clear()       # Reset cho lần sau
```

## 6. Ghi nhớ nhanh

| Phương thức | Công dụng |
|-------------|-----------|
| `event.wait()` | Chờ cho đến khi event được set |
| `event.set()` | Set event, báo cho tất cả đang chờ |
| `event.clear()` | Reset event về trạng thái ban đầu |
| `event.is_set()` | Kiểm tra event đã set chưa |

## 7. Mini test (3 câu)

**Câu 1:** Event.set() sẽ làm gì?
- A) Block tất cả task
- B) Báo cho tất cả task đang chờ event.wait()
- C) Xóa tất cả dữ liệu
- D) Tạo thread mới

**Câu 2:** Sau khi event.set(), làm sao dùng lại?
- A) Không thể dùng lại
- B) event.reset()
- C) event.clear()
- D) event.restart()

**Câu 3:** Event khác Lock ở điểm nào?
- A) Event không block
- B) Lock nhanh hơn
- C) Không khác gì
- D) Event chỉ dùng trong thread

**Đáp án:** 1-B, 2-C, 3-A

## 8. LeetCode practice

**Bài:** "Server khởi động"

```python
class Server:
    def __init__(self):
        self.started = asyncio.Event()
    
    async def start(self):
        # Giả lập khởi động
        await asyncio.sleep(1)
        self.started.set()
    
    async def handle_request(self, request):
        # Chỉ xử lý khi server đã start
        await self.started.wait()
        return f"Processed: {request}"

# Test
server = Server()
async def client():
    tasks = [server.handle_request(f"req-{i}") for i in range(3)]
    asyncio.create_task(server.start())
    return await asyncio.gather(*tasks)
```

## 9. Bonus

Tạo hệ thống:
- 1 worker chờ tín hiệu từ 3 producer
- Khi có tín hiệu, worker xử lý
- Dùng Event và Lock kết hợp

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 162 / 2000 |
| **XP** | 1620 |