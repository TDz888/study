# Bài 271 — Serialize and Deserialize BST (Medium)

## 1. Ôn tập

Từ bài 270, ta đã học LCA. Hôm nay ta học **lưu và khôi phục BST**!

## 2. Mục tiêu bài học

- Serialize: chuyển cây thành chuỗi
- Deserialize: chuyển chuỗi thành cây
- Dùng preorder cho BST

## 3. Code chính (có comment)

class Codec:
    def serialize(self, root: TreeNode) -> str:
        """Lưu cây thành chuỗi"""
        if not root:
            return ""
        
        result = []
        
        def preorder(node):
            if not node:
                return
            result.append(str(node.val))
            preorder(node.left)
            preorder(node.right)
        
        preorder(root)
        return ",".join(result)
    
    def deserialize(self, data: str) -> TreeNode:
        """Khôi phục cây từ chuỗi"""
        if not data:
            return None
        
        values = iter(data.split(","))
        
        def build(min_val, max_val):
            val = next(values)
            if not val:
                return None
            
            num = int(val)
            if num < min_val or num > max_val:
                return None
            
            node = TreeNode(num)
            node.left = build(min_val, num - 1)
            node.right = build(num + 1, max_val)
            return node
        
        return build(float("-inf"), float("inf"))

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 271 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2710 |