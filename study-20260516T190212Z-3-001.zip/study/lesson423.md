# Bài 423 — Convert Sorted List to BST (Medium)

## 1. Ôn tập

Từ bài 422, ta đã học Two Sum IV. Hôm nay ta học **Convert Sorted List to BST**!

## 2. Mục tiêu bài học

- Convert sorted linked list → balanced BST
- Find middle as root (slow/fast pointers)
- Recursive build

## 3. Code chính (có comment)

```python
def sorted_list_to_bst(head):
    """
    Sorted List to BST
    Input: sorted linked list
    Output: balanced BST
    """
    if not head:
        return None
    
    # Find middle
    slow = fast = head
    prev = None
    
    while fast and fast.next:
        prev = slow
        slow = slow.next
        fast = fast.next.next
    
    # slow is middle
    root = TreeNode(slow.val)
    
    if prev:
        prev.next = None
        root.left = sorted_list_to_bst(head)
    
    root.right = sorted_list_to_bst(slow.next)
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 423 / 2000 |
| **Chapter** | Trees |
| **XP** | 4230 |