# Bài 58 — Virtual Environments

---

## 1. Ôn tập
Học về **Virtual Environment** trong Python.

---

## 2. Mục tiêu
- Tạo virtual environment
- Activate/deactivate
- Quản lý packages với pip

---

## 3. Commands

```python
# Tạo virtual environment
python -m venv myenv

# Activate (Windows)
myenv\Scripts\activate

# Activate (Mac/Linux)
source myenv/bin/activate

# Cài package
pip install requests

# Xuất requirements
pip freeze > requirements.txt

# Cài từ requirements
pip install -r requirements.txt
```

---

## 4. Requirements file

```
requests==2.28.0
flask>=2.0.0
numpy
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 58 / 2000 |
| **XP** | 580 |
| **Level** | Tools |