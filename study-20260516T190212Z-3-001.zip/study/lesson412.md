# Bài 412 — Merge Two BSTs (Medium)

## 1. Ôn tập

Từ bài 411, ta đã học Insert into BST. Hôm nay ta học **Merge Two BSTs**!

## 2. Mục tiêu bài học

- Merge 2 BSTs thành 1
- Convert sang sorted array, merge
- Inorder + merge sort

## 3. Code chính (có comment)

```python
def merge_bsts(root1, root2):
    """
    Merge Two BSTs
    Input: 2 BSTs
    Output: Merged BST
    """
    # Collect sorted values
    def inorder(node, arr):
        if not node:
            return
        inorder(node.left, arr)
        arr.append(node.val)
        inorder(node.right, arr)
    
    vals1, vals2 = [], []
    inorder(root1, vals1)
    inorder(root2, vals2)
    
    # Merge sorted arrays
    merged = []
    i = j = 0
    while i < len(vals1) and j < len(vals2):
        if vals1[i] < vals2[j]:
            merged.append(vals1[i])
            i += 1
        else:
            merged.append(vals2[j])
            j += 1
    merged.extend(vals1[i:])
    merged.extend(vals2[j:])
    
    # Build BST from sorted array
    def build(arr, left, right):
        if left > right:
            return None
        mid = (left + right) // 2
        node = TreeNode(arr[mid])
        node.left = build(arr, left, mid - 1)
        node.right = build(arr, mid + 1, right)
        return node
    
    return build(merged, 0, len(merged) - 1)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 412 / 2000 |
| **Chapter** | Trees |
| **XP** | 4120 |