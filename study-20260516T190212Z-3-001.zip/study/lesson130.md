# Bài 130 — itertools (P2)

---

## 1. itertools - Finite Iterators

```python
import itertools

# accumulate
result = list(itertools.accumulate([1, 2, 3, 4, 5]))
print(result)  # [1, 3, 6, 10, 15]

# chain
result = list(itertools.chain([1, 2], [3, 4]))
print(result)  # [1, 2, 3, 4]

# compress
result = list(itertools.compress([1, 2, 3, 4], [1, 0, 1, 0]))
print(result)  # [1, 3]

# dropwhile / takewhile
result = list(itertools.dropwhile(lambda x: x < 3, [1, 2, 3, 4, 5]))
print(result)  # [3, 4, 5]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 130 / 2000 |
| **XP** | 1300 |
| **Level** | Intermediate |