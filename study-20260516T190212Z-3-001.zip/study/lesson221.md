# Bài 221 — LeetCode: Max Area of Island (Medium)

## 1. Ôn tập

Bài 220 dùng DFS để đếm islands. Hôm nay ta tìm **LỚN NHẤT** - max area!

## 2. Mục tiêu bài học

- Tính area của mỗi island
- Return max area
- Kết hợp DFS + tracking

## 3. Code chính (có comment)

```python
def max_area_of_island(grid: List[List[int]]) -> int:
    """
    Tìm island có diện tích lớn nhất
    Input: grid = [[0,0,1,0,0],[0,0,1,0,0],[0,0,0,1,1]]
    Output: 6
    """
    if not grid:
        return 0
    
    rows, cols = len(grid), len(grid[0])
    max_area = 0
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols or grid[r][c] == 0:
            return 0
        
        # Mark visited
        grid[r][c] = 0
        
        # Area = 1 + 4 directions
        return 1 + dfs(r+1, c) + dfs(r-1, c) + dfs(r, c+1) + dfs(r, c-1)
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 1:
                area = dfs(r, c)
                max_area = max(max_area, area)
    
    return max_area

# Test
grid = [[0,0,1,0,0],[0,0,1,0,0],[0,0,0,1,1]]
print(max_area_of_island(grid))  # 6
```

## 4. Ghi nhớ nhanh

```python
# Return 0 cho base case (water/out of bounds)
# Return 1 + 4 directions cho land
# Track max với max()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 221 / 2000 |
| **XP** | 2210 |