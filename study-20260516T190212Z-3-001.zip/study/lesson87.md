# Bài 87 — Design Patterns (Creational)

---

## 1. Giới thiệu
Học về **Creational Design Patterns**.

---

## 2. Singleton

```python
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

s1 = Singleton()
s2 = Singleton()
print(s1 is s2)  # True
```

---

## 3. Factory

```python
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "Woof"

class Cat(Animal):
    def speak(self):
        return "Meow"

class AnimalFactory:
    @staticmethod
    def create(animal_type):
        return {
            'dog': Dog,
            'cat': Cat
        }.get(animal_type)()

dog = AnimalFactory.create('dog')
print(dog.speak())  # Woof
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 87 / 2000 |
| **XP** | 870 |
| **Level** | Advanced |