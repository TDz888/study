# Lesson 74 — Functional Programming

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 73 - Named Tuples.

**Current Lesson:** Learning **Functional Programming** — programming with functions.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- First-class functions
- Higher-order functions
- Partial functions

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Higher-Order Functions

```python
# Function as parameter
def apply(func, value):
    return func(value)

def double(x):
    return x * 2

print(apply(double, 5))  # 10

# Function returning function
def make_multiplier(n):
    def multiplier(x):
        return x * n
    return multiplier

times3 = make_multiplier(3)
print(times3(5))  # 15
```

### Partial Functions

```python
from functools import partial

def power(base, exponent):
    return base ** exponent

# Create partial function
square = partial(power, exponent=2)
print(square(5))  # 25

cube = partial(power, exponent=3)
print(cube(2))  # 8
```

### Currying

```python
def curried_power(exponent):
    def power(base):
        return base ** exponent
    return power

square = curried_power(2)
print(square(5))  # 25
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is a higher-order function?**

> **Answer:** A function that takes a function as parameter or returns a function

---

**Type 75 to continue**