# Bài 242 — Serialize Deserialize Binary Tree (Hard)

## 1. Ôn tập

Từ bài 241, ta đã học LCA. Hôm nay ta học **Serialize/Deserialize Binary Tree**!

## 2. Mục tiêu bài học

- Convert tree thành string
- Convert string thành tree
- Pre-order traversal với marker

## 3. Code chính (có comment)

```python
class Codec:
    def serialize(self, root):
        """Tree -> String"""
        result = []
        
        def dfs(node):
            if not node:
                result.append("null")
                return
            result.append(str(node.val))
            dfs(node.left)
            dfs(node.right)
        
        dfs(root)
        return ",".join(result)
    
    def deserialize(self, data):
        """String -> Tree"""
        values = iter(data.split(","))
        
        def dfs():
            val = next(values)
            if val == "null":
                return None
            node = TreeNode(int(val))
            node.left = dfs()
            node.right = dfs()
            return node
        
        return dfs()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 242 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2420 |