# Bài 333 — Word Break II (Hard)

## 1. Ôn tập

Từ bài 332, ta đã học N-Queens. Hôm nay ta học **Word Break II**!

## 2. Mục tiêu bài học

- Tìm tất cả ways break sentence
- Dùng DP + backtracking
- Memoization

## 3. Code chính (có comment)

```python
def word_break(s, word_dict):
    """
    Word Break II
    Input: s="catsanddog", dict=["cat","cats","and","dog"]
    Output: ["cats and dog","cat sand dog"]
    """
    word_set = set(word_dict)
    memo = {}
    
    def backtrack(start):
        if start in memo:
            return memo[start]
        
        result = []
        if start == len(s):
            result.append("")
            return result
        
        for end in range(start + 1, len(s) + 1):
            word = s[start:end]
            if word in word_set:
                sub_results = backtrack(end)
                for sub in sub_results:
                    result.append(word + ("" if not sub else " " + sub))
        
        memo[start] = result
        return result
    
    return backtrack(0)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 333 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3330 |