# Bài 348 — Binary Tree Inorder Traversal (Easy)

## 1. Ôn tập

Từ bài 347, ta đã học Word Frequency. Hôm nay ta học **Binary Tree Inorder Traversal**!

## 2. Mục tiêu bài học

- Inorder: left → root → right
- Recursive và iterative
- BST: sorted order

## 3. Code chính (có comment)

```python
# Cách 1: Recursive
def inorder_recursive(root):
    result = []
    
    def inorder(node):
        if not node:
            return
        inorder(node.left)
        result.append(node.val)
        inorder(node.right)
    
    inorder(root)
    return result

# Cách 2: Iterative với stack
def inorder_iterative(root):
    result = []
    stack = []
    current = root
    
    while current or stack:
        while current:
            stack.append(current)
            current = current.left
        
        current = stack.pop()
        result.append(current.val)
        current = current.right
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 348 / 2000 |
| **Chapter** | Trees |
| **XP** | 3480 |