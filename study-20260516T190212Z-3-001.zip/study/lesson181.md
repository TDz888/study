# Bài 181 — Async Best Practices

## 1. Ôn tập

Qua 160-180 bài async, ta đã học rất nhiều. Hôm nay tổng hợp best practices!

## 2. Mục tiêu bài học

- Những điều nên làm
- Những điều nên tránh
- Common patterns

## 3. Code chính (có comment)

```python
import asyncio

# ✅ NÊN LÀM:

# 1. Use gather for concurrent tasks
async def fetch_all(urls):
    return await asyncio.gather(*[fetch(u) for u in urls])

# 2. Use timeout to avoid hanging
async def fetch_with_timeout(url):
    try:
        return await asyncio.wait_for(fetch(url), timeout=5)
    except asyncio.TimeoutError:
        return None

# 3. Use Semaphore for rate limiting
async def limited_request(url, sem):
    async with sem:
        return await fetch(url)

# 4. Use proper exception handling
async def safe_operation():
    try:
        await risky_operation()
    except Exception as e:
        logger.error(f"Failed: {e}")

# ❌ KHÔNG NÊN:

# 1. Don't block in async functions
async def bad():
    time.sleep(1)  # BAD - blocks!
    # Use: await asyncio.sleep(1)

# 2. Don't create too many tasks
async def bad_many():
    tasks = [create_task(i) for i in range(10000)]  # Too many!
    # Use: Semaphore(100)

# 3. Don't forget to close resources
# Use: async with for cleanup
```

## 4. Best Practices Summary

| Nên | Không nên |
|-----|-----------|
| `asyncio.gather` | Vòng lặp sequential |
| `async with` | Quên cleanup |
| Timeout | Không có timeout |
| Semaphore | Tạo quá nhiều tasks |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 181 / 2000 |
| **XP** | 1810 |