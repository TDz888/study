# Bài 213 — LeetCode: Longest Common Prefix (Easy)

## 1. Ôn tập

Bài 212 dùng DP với Fibonacci pattern. Hôm ta học **String matching** - tìm longest common prefix!

## 2. Mục tiêu bài học

- Tìm prefix chung của nhiều strings
- So sánh character theo vị trí
- Handle edge case

## 3. Code chính (có comment)

```python
def longest_common_prefix(strs: List[str]) -> str:
    """
    Tìm longest common prefix
    Input: ["flower","flow","flight"]
    Output: "fl"
    """
    if not strs:
        return ""
    
    # Lấy first string làm baseline
    first = strs[0]
    
    # So sánh từng character
    for i, char in enumerate(first):
        for s in strs[1:]:
            # Check bounds và match
            if i >= len(s) or s[i] != char:
                return first[:i]
    
    return first

# Test
print(longest_common_prefix(["flower","flow","flight"]))  # "fl"
print(longest_common_prefix(["dog","racecar","car"]))      # ""
```

## 4. Ghi nhớ nhanh

| Approach | Time | Space |
|----------|------|-------|
| Character by character | O(S) | O(1) |
| Sort + compare ends | O(n log n) | O(1) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 213 / 2000 |
| **XP** | 2130 |