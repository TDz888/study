# Bài 280 — Number of Connected Components (Medium)

## 1. Ôn tập

Từ bài 279, ta đã học Course Schedule (Topological Sort). Hôm nay ta học **đếm số connected components** trong graph!

## 2. Mục tiêu bài học

- Đếm số connected components trong undirected graph
- Dùng Union-Find hoặc DFS/BFS
- Xử lý disconnected nodes

## 3. Code chính (có comment)

```python
def count_components(n, edges):
    """
    Đếm số connected components
    Input: n=5, edges=[[0,1],[1,2],[3,4]]
    Output: 2 (components: {0,1,2} và {3,4})
    """
    # Build adjacency list
    graph = {i: [] for i in range(n)}
    for a, b in edges:
        graph[a].append(b)
        graph[b].append(a)
    
    visited = set()
    count = 0
    
    for i in range(n):
        if i not in visited:
            count += 1
            # DFS from node i
            stack = [i]
            while stack:
                node = stack.pop()
                if node in visited:
                    continue
                visited.add(node)
                for neighbor in graph[node]:
                    if neighbor not in visited:
                        stack.append(neighbor)
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 280 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2800 |