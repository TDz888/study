# Bài 268 — Construct Binary Tree from Preorder and Inorder (Medium)

## 1. Ôn tập

Từ bài 267, ta đã học Right Side View. Hôm nay ta học **xây dựng cây từ 2 traversal**!

## 2. Mục tiêu bài học

- Dùng preorder (Root-Left-Right) và inorder (Left-Root-Right)
- Preorder đầu tiên luôn là root
- Tìm root trong inorder để chia left/right subtree
- Độ phức tạp O(n)

## 3. Code chính (có comment)

```python
def build_tree(preorder: list, inorder: list) -> TreeNode:
    """
    Xây cây từ preorder và inorder
    Input: preorder = [3,9,20,15,7], inorder = [9,3,15,20,7]
    Output: cây gốc 3
    """
    # Dùng dictionary để tìm nhanh vị trí trong inorder
    inorder_index = {val: i for i, val in enumerate(inorder)}
    
    def build(pre_start, pre_end, in_start, in_end):
        # Base case
        if pre_start > pre_end:
            return None
        
        # Root là phần tử đầu của preorder
        root_val = preorder[pre_start]
        root = TreeNode(root_val)
        
        # Tìm vị trí root trong inorder
        in_root_index = inorder_index[root_val]
        
        # Số phần tử bên trái
        left_size = in_root_index - in_start
        
        # Xây cây con trái: preorder[pre_start+1 ... pre_start+left_size]
        root.left = build(pre_start + 1, 
                         pre_start + left_size,
                         in_start, 
                         in_root_index - 1)
        
        # Xây cây con phải
        root.right = build(pre_start + left_size + 1,
                          pre_end,
                          in_root_index + 1,
                          in_end)
        
        return root
    
    return build(0, len(preorder) - 1, 0, len(inorder) - 1)
```

## 4. Ví dụ

```
Preorder: [3, 9, 20, 15, 7]  → Root → Left → Right
Inorder:  [9, 3, 15, 20, 7] → Left → Root → Right

1. Root = 3 (preorder[0])
2. Trong inorder, 3 ở vị trí 1
3. Left subtree: [9] (trước 3)
4. Right subtree: [20, 15, 7] (sau 3)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 268 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2680 |