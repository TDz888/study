# Lesson 72 — Data Classes

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 71 - Enum.

**Current Lesson:** Learning **Data Classes** — simpler classes for data.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- @dataclass decorator
- Fields and defaults
- Methods in data classes

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
from dataclasses import dataclass, field

@dataclass
class Person:
    name: str
    age: int
    email: str = "unknown"  # default value
    
    def greet(self):
        return f"Hello, I am {self.name}"

p = Person("Alice", 25)
print(p)  # Person(name='Alice', age=25, email='unknown')
print(p.greet())  # Hello, I am Alice
```

### Advanced Fields

```python
from dataclasses import dataclass, field

@dataclass
class Product:
    name: str
    price: float
    quantity: int = 0
    tags: list[str] = field(default_factory=list)

# Using
p = Product("Laptop", 999.99)
p.tags.append("electronics")
print(p)
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does @dataclass do?**

> **Answer:** Auto-generates __init__, __repr__, __eq__ methods

---

**Type 73 to continue**