# Bài 197 — Docker Basics

## 1. Concepts

Containerization - đóng gói app với dependencies

## 2. Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "main.py"]
```

## 3. Commands

```bash
docker build -t myapp .
docker run -p 8000:8000 myapp
docker-compose up
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 197 / 2000 |
| **XP** | 1970 |