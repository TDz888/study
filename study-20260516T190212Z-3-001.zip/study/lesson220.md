# Bài 220 — LeetCode: Number of Islands (Medium)

## 1. Ôn tập

Từ bài 201-219, ta đã học nhiều techniques. Hôm nay ta học **DFS/BFS trên Grid** - Number of Islands!

## 2. Mục tiêu bài học

- Đếm số islands trong 2D grid
- Dùng DFS hoặc BFS để explore
- Mark visited để tránh infinite loop

## 3. Code chính (có comment)

```python
def num_islands(grid: List[List[str]]) -> int:
    """
    Đếm số islands (connected '1's)
    Input: grid = [
      ["1","1","0","0","0"],
      ["1","1","0","0","0"],
      ["0","0","1","0","0"],
      ["0","0","0","1","1"]
    ]
    Output: 3
    """
    if not grid:
        return 0
    
    rows, cols = len(grid), len(grid[0])
    count = 0
    
    def dfs(r, c):
        # Base cases: out of bounds hoặc water
        if r < 0 or r >= rows or c < 0 or c >= cols or grid[r][c] == '0':
            return
        
        # Mark as visited
        grid[r][c] = '0'
        
        # Explore 4 directions
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)
    
    # Scan entire grid
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1':
                count += 1
                dfs(r, c)  # Mark entire island
    
    return count

# Test
grid = [
  ["1","1","1"],
  ["0","1","0"],
  ["1","1","1"]
]
print(num_islands(grid))  # 1
```

## 4. Trace chạy code

```
grid = [["1","1"],["0","1"]]

r=0,c=0: grid[0][0]='1' → count=1 → dfs(0,0)
  dfs: mark 0,0='0', explore → mark 0,1='0', 1,1='0'

r=0,c=1: already '0' → skip
r=1,c=0: '0' → skip
r=1,c=1: '0' → skip

Result: 1
```

## 5. Debug tư duy

### Phải mark visited!
```python
# Sai: Infinite loop!
dfs(r, c):
    if grid[r][c] == '1':  # Không mark!
        dfs(r+1, c)  # Vòng vô tận

# Đúng: Mark '0' after visit
grid[r][c] = '0'  # Water now!
```

### 4 directions: up, down, left, right
```python
directions = [(1,0), (-1,0), (0,1), (0,-1)]
# Hoặc gọi trực tiếp như trên
```

## 6. Ghi nhớ nhanh

| Method | Time | Space |
|--------|------|-------|
| DFS | O(rows*cols) | O(rows*cols) |
| BFS | O(rows*cols) | O(rows*cols) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 220 / 2000 |
| **XP** | 2200 |