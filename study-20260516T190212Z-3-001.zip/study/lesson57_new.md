# Lesson 57 — Type Hints

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 56 - Context Managers.

**Current Lesson:** Learning **Type Hints** — declare data types.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Basic type hints
- Optional and Union types
- Type checking

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Basic Type Hints

```python
def greet(name: str) -> str:
    return f"Hello {name}"

def process(items: list[int]) -> int:
    return sum(items)

def get_info(person: dict[str, int]) -> str:
    return f"Age: {person.get('age', 0)}"
```

### Optional and Union

```python
from typing import Optional, Union

def find(items: list[int], target: int) -> Optional[int]:
    for i, v in enumerate(items):
        if v == target:
            return i
    return None

def process(value: Union[int, str]) -> str:
    return str(value)
```

### Advanced Types

```python
from typing import TypeVar, Generic

T = TypeVar('T')

def first(items: list[T]) -> Optional[T]:
    return items[0] if items else None
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does `Optional[int]` mean?**

> **Answer:** int or None

---

**Type 58 to continue**