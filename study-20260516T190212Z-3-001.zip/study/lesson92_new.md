# Lesson 92 — Flask Routes & HTTP Methods

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 91 - Flask Basics.

**Current Lesson:** Learning **Flask Routes and HTTP Methods** — how to handle different types of web requests.

**Why This Matters:**
- Every web application needs to handle multiple types of requests
- GET for reading, POST for creating, PUT for updating, DELETE for removing
- Understanding routing is fundamental to building web APIs

**Connection:**
```
Flask Basics → Routes & Methods → Full API Development
     ↓              ↓                  ↓
  App setup    Handle requests    Build REST APIs
```

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- Defining routes with multiple HTTP methods
- Handling GET, POST, PUT, PATCH, DELETE requests
- Working with query parameters
- Returning JSON responses

**Real-world analogy:**
- Think of a restaurant:
  - GET = Reading the menu (browse)
  - POST = Ordering new food (create)
  - PUT = Replacing your entire order (update all)
  - PATCH = Modifying part of your order (update partial)
  - DELETE = Canceling an item (remove)

-------------------------------------------------------------------------------
3. CONCEPT FOUNDATION
-------------------------------------------------------------------------------

### What are HTTP Methods?

HTTP defines a set of request methods (also called "verbs") that indicate the desired action to be performed on a resource:

| Method | Meaning | Idempotent |
|--------|---------|------------|
| **GET** | Retrieve data | Yes |
| **POST** | Create new resource | No |
| **PUT** | Replace entire resource | Yes |
| **PATCH** | Partial update | No |
| **DELETE** | Remove resource | Yes |

**Important concept:** "Idempotent" means making the same request multiple times produces the same result.

### What is a Route?

A route is a URL pattern that maps to a function. In Flask:
```
/home        → Shows homepage
/api/users   → Returns user data  
/api/users/1 → Returns user with ID 1
```

-------------------------------------------------------------------------------
4. TERMINOLOGY EXPLANATION
-------------------------------------------------------------------------------

| Term | Simple Meaning |
|------|----------------|
| **Route** | URL pattern that triggers a function |
| **Endpoint** | A specific URL path |
| **View Function** | Python function that handles the request |
| **Request Object** | Contains data from the client |
| **Response Object** | Data sent back to client |
| **Query Parameters** | Data in URL after ? (e.g., ?name=value) |
| **Request Body** | Data sent in POST/PUT requests |

-------------------------------------------------------------------------------
5. MAIN CODE
-------------------------------------------------------------------------------

### 1. Basic Route with Multiple Methods

```python
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api', methods=['GET', 'POST'])
def handle_api():
    """
    Handle both GET and POST requests to /api endpoint
    
    - GET: Returns a message
    - POST: Receives JSON data and returns it
    """
    if request.method == 'POST':
        # Get JSON data from request body
        data = request.get_json()
        
        # Return JSON response with status code 201 (Created)
        return jsonify({
            'message': 'Data received',
            'received': data
        }), 201
    
    # GET request handling
    return jsonify({
        'message': 'GET request received',
        'status': 'success'
    })

# Test with:
# GET /api → {"message": "GET request received", "status": "success"}
# POST /api with {"name": "Alice"} → {"message": "Data received", "received": {"name": "Alice"}}
```

### 2. Handling Query Parameters

```python
@app.route('/query')
def handle_query():
    """
    Handle URL query parameters
    
    URL: /query?name=Alice&age=25
    Query string: ?name=Alice&age=25
    """
    # request.args is a dictionary-like object
    name = request.args.get('name', 'Guest')  # Default 'Guest' if not provided
    age = request.args.get('age', '0')
    
    return f'Hello {name}, you are {age} years old!'

# Test:
# /query?name=Bob → "Hello Bob, you are 0 years old!"
# /query?name=Carol&age=30 → "Hello Carol, you are 30 years old!"
```

### 3. Handling Path Parameters (Dynamic Routes)

```python
@app.route('/user/<int:user_id>')
def get_user(user_id):
    """
    Dynamic route with type conversion
    
    <int:user_id> - integer parameter
    <str:name>    - string parameter
    <float:price> - float parameter
    """
    # Simulate database lookup
    users = {
        1: {'name': 'Alice', 'email': 'alice@example.com'},
        2: {'name': 'Bob', 'email': 'bob@example.com'}
    }
    
    if user_id in users:
        return jsonify(users[user_id])
    else:
        return jsonify({'error': 'User not found'}), 404

# Test:
# /user/1 → {"name": "Alice", "email": "alice@example.com"}
# /user/999 → {"error": "User not found"}
```

### 4. Complete RESTful API Example

```python
# In-memory data storage (simulating database)
users = [
    {'id': 1, 'name': 'Alice', 'email': 'alice@example.com'},
    {'id': 2, 'name': 'Bob', 'email': 'bob@example.com'}
]
next_id = 3

# GET all users
@app.route('/api/users', methods=['GET'])
def get_users():
    """Retrieve all users"""
    return jsonify({'users': users, 'count': len(users)})

# GET single user
@app.route('/api/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Retrieve specific user by ID"""
    user = next((u for u in users if u['id'] == user_id), None)
    if user:
        return jsonify(user)
    return jsonify({'error': 'User not found'}), 404

# POST - Create new user
@app.route('/api/users', methods=['POST'])
def create_user():
    """Create a new user"""
    global next_id
    
    data = request.get_json()
    
    # Validation
    if not data or 'name' not in data:
        return jsonify({'error': 'Name is required'}), 400
    
    new_user = {
        'id': next_id,
        'name': data['name'],
        'email': data.get('email', '')
    }
    users.append(new_user)
    next_id += 1
    
    return jsonify(new_user), 201

# PUT - Update entire user
@app.route('/api/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """Replace entire user"""
    data = request.get_json()
    
    for user in users:
        if user['id'] == user_id:
            user['name'] = data.get('name', user['name'])
            user['email'] = data.get('email', user['email'])
            return jsonify(user)
    
    return jsonify({'error': 'User not found'}), 404

# PATCH - Partial update
@app.route('/api/users/<int:user_id>', methods=['PATCH'])
def patch_user(user_id):
    """Update specific fields"""
    data = request.get_json()
    
    for user in users:
        if user['id'] == user_id:
            if 'name' in data:
                user['name'] = data['name']
            if 'email' in data:
                user['email'] = data['email']
            return jsonify(user)
    
    return jsonify({'error': 'User not found'}), 404

# DELETE - Remove user
@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """Delete a user"""
    global users
    
    for i, user in enumerate(users):
        if user['id'] == user_id:
            users.pop(i)
            return jsonify({'message': 'User deleted'})
    
    return jsonify({'error': 'User not found'}), 404
```

-------------------------------------------------------------------------------
6. EXECUTION TRACE
-------------------------------------------------------------------------------

### Trace: POST Request Flow

```
Client sends: POST /api/users with {"name": "Charlie"}

1. Flask matches route: @app.route('/api/users', methods=['POST'])
2. Flask calls: create_user() function
3. request.get_json() parses {"name": "Charlie"}
4. Global next_id = 3
5. Creates new_user = {'id': 3, 'name': 'Charlie', 'email': ''}
6. Appends to users list
7. next_id becomes 4
8. Returns JSON with status 201

Response:
{
    "id": 3,
    "name": "Charlie",
    "email": ""
}
```

### Trace: GET with Query Parameters

```
URL: /query?name=Alice&age=25

1. Flask parses URL
2. Matches route: @app.route('/query')
3. Calls: handle_query()
4. request.args.get('name', 'Guest') → 'Alice'
5. request.args.get('age', '0') → '25'
6. Returns: "Hello Alice, you are 25 years old!"

Response: Plain text string
```

-------------------------------------------------------------------------------
7. VISUAL THINKING MODE
-------------------------------------------------------------------------------

### HTTP Methods Visual

```
Client                          Server
   │                               │
   │  GET /users                  │
   │─────────────────────────────►│
   │                              │
   │◄─────────────────────────────│
   │  [{"id":1,"name":"Alice"}]   │
   │                               │
   │  POST /users {"name":"New"} │
   │─────────────────────────────►│
   │                              │
   │◄─────────────────────────────│
   │  {"id":3,"name":"New"} 201   │
```

### Route Matching Flow

```
Request: GET /user/5

Step 1: Flask looks for matching route
Step 2: Matches '/user/<int:user_id>'
Step 3: Converts '5' to integer 5
Step 4: Calls get_user(5)
Step 5: Returns JSON response
```

-------------------------------------------------------------------------------
8. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake 1: Forgetting methods Parameter

```python
# ❌ WRONG - Only GET works, POST will fail
@app.route('/create')
def create():
    return "Created"

# ✅ CORRECT - Specify all methods needed
@app.route('/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        return "Data created"
    return "Form page"
```

**Why it happens:** Default is only GET, so POST requests return "Method Not Allowed".

**Prevention:** Always specify methods=['POST'] when accepting form data.

---

### Common Mistake 2: Wrong Status Code

```python
# ❌ WRONG - Returning 200 for created resource
return jsonify(new_user)  # Should be 201

# ✅ CORRECT - Use proper status codes
return jsonify(new_user), 201  # Created
return jsonify(error), 404     # Not Found
return jsonify(error), 400     # Bad Request
```

**Why it matters:** Proper status codes help clients understand the response.

**Prevention:** Remember:
- 200 = OK
- 201 = Created
- 404 = Not Found
- 400 = Bad Request

---

### Common Mistake 3: Not Validating Input

```python
# ❌ WRONG - No validation can cause errors
@app.route('/add', methods=['POST'])
def add():
    data = request.get_json()
    result = data['name'].upper()  # Crashes if no 'name'!

# ✅ CORRECT - Always validate input
@app.route('/add', methods=['POST'])
def add():
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'error': 'name required'}), 400
    result = data['name'].upper()
    return jsonify({'result': result})
```

**Why it happens:** Clients can send incomplete data.

**Prevention:** Always validate before processing.

-------------------------------------------------------------------------------
9. MEMORY REINFORCEMENT
-------------------------------------------------------------------------------

### Quick Reference

| Method | Purpose | Status Codes |
|--------|---------|--------------|
| GET | Read | 200 |
| POST | Create | 201 |
| PUT | Replace | 200 |
| PATCH | Update | 200 |
| DELETE | Remove | 204 |

### URL Patterns

| Pattern | Meaning |
|---------|---------|
| `/users` | All users |
| `/users/1` | Specific user |
| `/users?page=1` | With query params |
| `/users/<int:id>` | Dynamic with type |

### Code Checklist

- [ ] Specify methods=['POST', 'PUT', etc.] when needed
- [ ] Use request.get_json() for JSON body
- [ ] Use request.args.get() for query parameters
- [ ] Return proper status codes (201, 404, 400)
- [ ] Validate input before processing

### Mnemonic

**"G-P-U-P-D"**
- **G**et = **G**ather (read)
- **P**ost = **P**ost (create)
- **U**t = Replace (all)
- **P**atch = **P**artial update
- **D**elete = **D**iscard (remove)

-------------------------------------------------------------------------------
10. MINI TEST
-------------------------------------------------------------------------------

### Question 1: Concept Check

**What is the difference between PUT and PATCH?**

> **Answer:** PUT replaces the entire resource with new data. PATCH updates only specific fields while keeping others unchanged.

---

### Question 2: Prediction

**What does this code return?**
```python
@app.route('/search')
def search():
    return request.args.get('q', 'no query')
```

For URL: `/search?q=python`

> **Answer:** "python"
> 
> Because `request.args.get('q', 'no query')` retrieves the value of `q` parameter, which is "python".

---

### Question 3: Problem Solving

**You want to accept both GET and POST on the same route. How do you do it?**

> **Answer:**
> ```python
> @app.route('/endpoint', methods=['GET', 'POST'])
> def handler():
>     if request.method == 'POST':
>         # Handle POST
>     else:
>         # Handle GET
> ```

-------------------------------------------------------------------------------
11. LEETCODE PRACTICE
-------------------------------------------------------------------------------

### Problem: Build a Simple REST API

**Task:** Create a simple in-memory todo API with:

- GET /todos - List all todos
- POST /todos - Create new todo
- GET /todos/{id} - Get specific todo
- DELETE /todos/{id} - Delete todo

**Solution:**
```python
from flask import Flask, request, jsonify

app = Flask(__name__)

todos = []
next_id = 1

@app.route('/todos', methods=['GET'])
def get_todos():
    return jsonify({'todos': todos})

@app.route('/todos', methods=['POST'])
def create_todo():
    global next_id
    data = request.get_json()
    if not data or 'title' not in data:
        return jsonify({'error': 'Title required'}), 400
    
    todo = {'id': next_id, 'title': data['title'], 'completed': False}
    todos.append(todo)
    next_id += 1
    return jsonify(todo), 201

@app.route('/todos/<int:todo_id>', methods=['GET'])
def get_todo(todo_id):
    todo = next((t for t in todos if t['id'] == todo_id), None)
    if todo:
        return jsonify(todo)
    return jsonify({'error': 'Not found'}), 404

@app.route('/todos/<int:todo_id>', methods=['DELETE'])
def delete_todo(todo_id):
    global todos
    for i, todo in enumerate(todos):
        if todo['id'] == todo_id:
            todos.pop(i)
            return jsonify({'message': 'Deleted'}), 204
    return jsonify({'error': 'Not found'}), 404

# Test with:
# curl http://localhost:5000/todos
# curl -X POST -H "Content-Type: application/json" -d '{"title":"Learn Flask"}' http://localhost:5000/todos
```

-------------------------------------------------------------------------------
12. BONUS CHALLENGE
-------------------------------------------------------------------------------

### Challenge: Add Update Functionality

Add PATCH endpoint to update todo completion status:

**Expected:**
```python
@app.route('/todos/<int:todo_id>', methods=['PATCH'])
def update_todo(todo_id):
    # Update only 'completed' field
    pass

# Test: PATCH /todos/1 with {"completed": true}
# Should update todo with id=1 to completed=true
```

**Solution:**
```python
@app.route('/todos/<int:todo_id>', methods=['PATCH'])
def update_todo(todo_id):
    data = request.get_json()
    
    for todo in todos:
        if todo['id'] == todo_id:
            if 'title' in data:
                todo['title'] = data['title']
            if 'completed' in data:
                todo['completed'] = data['completed']
            return jsonify(todo)
    
    return jsonify({'error': 'Not found'}), 404
```

-------------------------------------------------------------------------------
13. LESSON REFLECTION
-------------------------------------------------------------------------------

### What You Learned Today

1. **Route Definition** - Creating URL patterns with `@app.route()`
2. **HTTP Methods** - GET, POST, PUT, PATCH, DELETE
3. **Query Parameters** - Handling URL parameters with `request.args`
4. **Path Parameters** - Dynamic routes with `<type:var>`
5. **JSON Handling** - Working with request/response JSON
6. **Status Codes** - Returning appropriate HTTP status codes

### Key Takeaways

- Routes map URLs to Python functions
- HTTP method determines action (create, read, update, delete)
- Always validate input before processing
- Return proper status codes for API responses

### Common Patterns

| Pattern | Code |
|---------|------|
| Query param | `request.args.get('key', default)` |
| JSON body | `request.get_json()` |
| Dynamic route | `@app.route('/user/<int:id>')` |
| JSON response | `return jsonify(data), status_code` |

### Weak Points to Watch

- Forgetting to specify methods in route
- Not validating input data
- Using wrong status codes

### Next Lesson Preview

**Lesson 93:** Flask Templates & Jinja2 — Dynamic HTML rendering

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 92 / 2000 |
| **Chapter** | 9 (Web Development) |
| **XP** | 920 |
| **Rank** | Intermediate |
| **Mastery** | Flask Routes & Methods |
| **Weaknesses** | Remembering all HTTP methods |
| **Recommended Focus** | Practice building REST APIs |
| **Suggested Review** | Lesson 91 (Flask Basics) |
| **Next Lesson Readiness** | ✓ Ready for Flask Templates |

---

**Type 93 to continue**