# Bài 426 — Remove Nth Node from End (Medium)

## 1. Ôn tập

Từ bài 425, ta đã học Linked List Cycle II. Hôm nay ta học **Remove Nth Node from End**!

## 2. Mục tiêu bài học

- Xóa nth node từ cuối
- One pass, two pointers
- Dummy node để handle edge case

## 3. Code chính (có comment)

```python
def remove_nth_from_end(head, n):
    """
    Remove Nth Node from End
    Input: 1→2→3→4→5, n=2
    Output: 1→2→3→5
    """
    dummy = ListNode(0)
    dummy.next = head
    
    slow = fast = dummy
    
    for _ in range(n + 1):
        fast = fast.next
    
    while fast:
        slow = slow.next
        fast = fast.next
    
    slow.next = slow.next.next
    
    return dummy.next
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 426 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4260 |