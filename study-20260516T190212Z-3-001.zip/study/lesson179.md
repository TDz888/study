# Bài 179 — functools partial

## 1. Ôn tập

Ta đã học functools ở bài 132. Hôm nay học `partial` - tạo function với pre-filled arguments!

## 2. Mục tiêu bài học

- Hiểu partial function
- Dùng để specialize functions
- Kết hợp với map/filter

## 3. Code chính (có comment)

```python
from functools import partial

def power(base, exponent):
    return base ** exponent

# Tạo function mới với exponent cố định
square = partial(power, exponent=2)
cube = partial(power, exponent=3)

print(square(5))  # 25 (5^2)
print(cube(5))   # 125 (5^3)

# Dùng với map
nums = [1, 2, 3, 4, 5]
squared_nums = list(map(square, nums))
print(squared_nums)  # [1, 4, 9, 16, 25]

# Dùng với filter
def is_divisible_by(divisor, n):
    return n % divisor == 0

is_even = partial(is_divisible_by, 2)
is_odd = partial(is_divisible_by, 3)

print(list(filter(is_even, nums)))   # [2, 4]
print(list(filter(is_odd, nums)))    # [3]
```

## 4. Trace chạy code

```
25
125
[1, 4, 9, 16, 25]
[2, 4]
[3]
```

## 5. Ghi nhớ nhanh

| Code | Ý nghĩa |
|------|---------|
| `partial(func, arg=value)` | Tạo func mới với arg đã fill |
| `partial(power, exponent=2)` | power(x) = x^2 |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 179 / 2000 |
| **XP** | 1790 |