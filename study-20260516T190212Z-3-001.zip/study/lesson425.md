# Bài 425 — Linked List Cycle II (Medium)

## 1. Ôn tập

Từ bài 424, ta đã học Linked List Cycle. Hôm nay ta học **Linked List Cycle II**!

## 2. Mục tiêu bài học

- Tìm start node của cycle
- Floyd's + math proof
- O(n)

## 3. Code chính (có comment)

```python
def detect_cycle(head):
    """
    Linked List Cycle II
    Input: linked list
    Output: cycle start node
    """
    if not head or not head.next:
        return None
    
    # Floyd's detection
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            break
    
    if not fast or not fast.next:
        return None
    
    # Find start
    slow = head
    while slow != fast:
        slow = slow.next
        fast = fast.next
    
    return slow
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 425 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4250 |