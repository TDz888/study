# Lesson 62 — Regular Expressions (P1)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 61 - Datetime Handling.

**Current Lesson:** Learning **Regular Expressions (Regex)** — pattern matching in text.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Basic regex functions (search, findall, split, sub)
- Metacharacters
- Pattern matching

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
import re

# search() - find first match
pattern = r"hello"
text = "hello world"
match = re.search(pattern, text)
print(match.group())  # hello

# findall() - find all matches
text = "apple banana apple"
matches = re.findall("apple", text)
print(matches)  # ['apple', 'apple']

# split() - split by pattern
text = "a,b,c"
print(re.split(",", text))  # ['a', 'b', 'c']

# sub() - replace pattern
text = "hello world"
new_text = re.sub("world", "python", text)
print(new_text)  # hello python
```

### Metacharacters

```python
# . - Any character (except newline)
re.search(r".", "abc")  # 'a'

# \d - Digit (0-9)
re.findall(r"\d+", "abc123xyz")  # ['123']

# \w - Word character (alphanumeric + underscore)
re.findall(r"\w+", "hello_world")  # ['hello_world']
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does re.findall() return?**

> **Answer:** List of all non-overlapping matches

---

**Type 63 to continue**