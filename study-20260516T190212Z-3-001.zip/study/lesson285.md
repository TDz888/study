# Bài 285 — Serialize and Deserialize Binary Tree (Hard)

## 1. Ôn tập

Từ bài 284, ta đã học Clone Binary Tree. Hôm nay ta học **serialize/deserialize** binary tree!

## 2. Mục tiêu bài học

- Convert tree → string (serialize)
- Convert string → tree (deserialize)
- Dùng BFS hoặc DFS

## 3. Code chính (có comment)

```python
from collections import deque

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def serialize(root):
    """
    Convert tree to string
    Input: Tree
    Output: String like "1,2,3,null,null,4,5"
    """
    if not root:
        return ""
    
    result = []
    queue = deque([root])
    
    while queue:
        node = queue.popleft()
        if node:
            result.append(str(node.val))
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append("null")
    
    return ",".join(result)

def deserialize(data):
    """
    Convert string back to tree
    """
    if not data:
        return None
    
    values = data.split(",")
    root = TreeNode(int(values[0]))
    queue = deque([root])
    i = 1
    
    while queue and i < len(values):
        node = queue.popleft()
        
        if i < len(values) and values[i] != "null":
            node.left = TreeNode(int(values[i]))
            queue.append(node.left)
        i += 1
        
        if i < len(values) and values[i] != "null":
            node.right = TreeNode(int(values[i]))
            queue.append(node.right)
        i += 1
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 285 / 2000 |
| **Chapter** | Trees |
| **XP** | 2850 |