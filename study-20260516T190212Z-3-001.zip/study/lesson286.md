# Bài 286 — Construct Binary Tree from Preorder and Inorder (Medium)

## 1. Ôn tập

Từ bài 285, ta đã học Serialize/Deserialize. Hôm nay ta học **build tree** từ preorder và inorder!

## 2. Mục tiêu bài học

- Dùng preorder (root-first) và inorder (root-mid)
- Tìm root, split inorder, recursive build
- Time: O(n)

## 3. Code chính (có comment)

```python
def build_tree(preorder, inorder):
    """
    Build tree từ preorder và inorder
    Input: preorder=[3,9,20,15,7], inorder=[9,3,15,20,7]
    Output: Tree
    """
    if not preorder or not inorder:
        return None
    
    root_val = preorder[0]
    root = TreeNode(root_val)
    
    # Tìm root trong inorder
    mid = inorder.index(root_val)
    
    # Build left và right
    root.left = build_tree(preorder[1:mid+1], inorder[:mid])
    root.right = build_tree(preorder[mid+1:], inorder[mid+1:])
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 286 / 2000 |
| **Chapter** | Trees |
| **XP** | 2860 |