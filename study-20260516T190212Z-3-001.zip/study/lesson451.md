# Bài 451 — LRU Cache (Medium)

## 1. Ôn tập

Từ bài 430, ta đã học Copy List with Random Pointer. Hôm nay ta học **LRU Cache**!

## 2. Mục tiêu bài học

- Design Least Recently Used cache
- Get/put trong O(1)
- HashMap + Doubly Linked List

## 3. Code chính (có comment)

```python
from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity):
        self.cache = OrderedDict()
        self.capacity = capacity
    
    def get(self, key):
        if key not in self.cache:
            return -1
        self.cache.move_to_end(key)
        return self.cache[key]
    
    def put(self, key, value):
        if key in self.cache:
            self.cache.move_to_end(key)
        self.cache[key] = value
        if len(self.cache) > self.capacity:
            self.cache.popitem(last=False)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 451 / 2000 |
| **Chapter** | Design |
| **XP** | 4510 |