# Bài 190 — Async Database Connector

## 1. Project

Async wrapper cho database operations

## 2. Code

```python
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

class AsyncDB:
    def __init__(self, url):
        self.engine = create_async_engine(url)
    
    async def execute(self, query):
        async with self.engine.begin() as conn:
            result = await conn.execute(text(query))
            return result.fetchall()
    
    async def execute_many(self, query, params_list):
        async with self.engine.begin() as conn:
            await conn.execute(text(query), params_list)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 190 / 2000 |
| **XP** | 1900 |