# Bài 377 — First Bad Version (Easy)

## 1. Ôn tập

Từ bài 376, ta đã học Find Peak Element. Hôm nay ta học **First Bad Version**!

## 2. Mục tiêu bài học

- Tìm first bad version
- Binary search với isBadVersion API
- Left bound

## 3. Code chính (có comment)

```python
def first_bad_version(n):
    """
    First Bad Version
    Input: n=5, bad=4
    Output: 4
    """
    left, right = 1, n
    
    while left < right:
        mid = (left + right) // 2
        
        if is_bad_version(mid):
            right = mid
        else:
            left = mid + 1
    
    return left
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 377 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3770 |