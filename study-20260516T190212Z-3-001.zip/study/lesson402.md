# Bài 402 — Implement Stack using Queues (Easy)

## 1. Ôn tập

Từ bài 401, ta đã học Queue using Stacks. Hôm nay ta học **Implement Stack using Queues**!

## 2. Mục tiêu bài học

- Dùng queues để implement stack
- LIFO với FIFO operations
- Push O(n), others O(1)

## 3. Code chính (có comment)

```python
from collections import deque

class MyStack:
    def __init__(self):
        self.queue = deque()
    
    def push(self, x):
        self.queue.append(x)
        # Rotate để bring recent to front
        for _ in range(len(self.queue) - 1):
            self.queue.append(self.queue.popleft())
    
    def pop(self):
        return self.queue.popleft()
    
    def top(self):
        return self.queue[0]
    
    def empty(self):
        return len(self.queue) == 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 402 / 2000 |
| **Chapter** | Design |
| **XP** | 4020 |