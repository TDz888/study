# Bài 332 — N-Queens (Hard)

## 1. Ôn tập

Từ bài 331, ta đã học Combination Sum. Hôm nay ta học **N-Queens**!

## 2. Mục tiêu bài học

- Place N queens không attack nhau
- Backtracking với diagonal check
- Classic problem

## 3. Code chính (có comment)

```python
def solve_n_queens(n):
    """
    N-Queens
    Input: n=4
    Output: solutions với board configurations
    """
    result = []
    board = [['.' for _ in range(n)] for _ in range(n)]
    
    def is_valid(row, col):
        # Check column
        for i in range(row):
            if board[i][col] == 'Q':
                return False
        # Check diagonal
        i, j = row - 1, col - 1
        while i >= 0 and j >= 0:
            if board[i][j] == 'Q':
                return False
            i -= 1
            j -= 1
        i, j = row - 1, col + 1
        while i >= 0 and j < n:
            if board[i][j] == 'Q':
                return False
            i -= 1
            j += 1
        return True
    
    def backtrack(row):
        if row == n:
            result.append([''.join(row) for row in board])
            return
        
        for col in range(n):
            if is_valid(row, col):
                board[row][col] = 'Q'
                backtrack(row + 1)
                board[row][col] = '.'
    
    backtrack(0)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 332 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3320 |