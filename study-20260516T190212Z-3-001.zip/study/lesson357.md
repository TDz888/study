# Bài 357 — Non-overlapping Intervals (Medium)

## 1. Ôn tập

Từ bài 356, ta đã học Assign Cookies. Hôm nay ta học **Non-overlapping Intervals**!

## 2. Mục tiêu bài học

- Remove minimum intervals để non-overlap
- Sort by end time
- Greedy selection

## 3. Code chính (có comment)

```python
def erase_overlap_intervals(intervals):
    """
    Non-overlapping Intervals
    Input: [[1,2],[2,3],[3,4],[1,3]]
    Output: 1 (remove [1,3])
    """
    if not intervals:
        return 0
    
    intervals.sort(key=lambda x: x[1])
    
    count = 0
    end = intervals[0][1]
    
    for i in range(1, len(intervals)):
        if intervals[i][0] < end:
            count += 1
        else:
            end = intervals[i][1]
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 357 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3570 |