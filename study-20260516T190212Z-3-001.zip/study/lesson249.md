# Bài 249 — Dominant Path in Binary Tree (Medium)

## 1. Ôn tập

Từ bài 248, ta đã học subtree. Hôm nay ta học **Dominant Path**!

## 2. Mục tiêu bài học

- Tìm path có sum lớn nhất
- Có thể không qua root
- DFS tracking max sum

## 3. Code chính (có comment)

```python
def max_path_sum_anywhere(root: TreeNode) -> int:
    """
    Tìm max path sum (không nhất thiết qua root)
    Input: root = [-10,9,20,null,null,15,7]
    Output: 42
    """
    max_sum = float('-inf')
    
    def dfs(node):
        nonlocal max_sum
        if not node:
            return 0
        
        left = max(dfs(node.left), 0)
        right = max(dfs(node.right), 0)
        
        max_sum = max(max_sum, node.val + left + right)
        
        return node.val + max(left, right)
    
    dfs(root)
    return max_sum
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 249 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2490 |