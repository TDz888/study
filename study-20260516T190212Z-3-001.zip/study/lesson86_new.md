# Lesson 86 — Object-Oriented Design

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 85 - Fenwick Tree.

**Current Lesson:** Learning **OOP Design Patterns**.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- SOLID principles
- Design patterns

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### SOLID Principles

```python
# S - Single Responsibility
class User:
    def __init__(self, name):
        self.name = name

class UserRepository:
    def save(self, user):
        pass

# O - Open/Closed
class Shape:
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, r):
        self.r = r
    def area(self):
        return 3.14 * self.r ** 2

# L - Liskov Substitution
# Subclass can replace parent

# I - Interface Segregation
# Many small interfaces vs one big

# D - Dependency Inversion
# Depend on abstractions, not concrete
```

### Common Patterns

```python
# Singleton
class Singleton:
    _instance = None
    def __new__(cls):
        if not cls._instance:
            cls._instance = super().__new__(cls)
        return cls._instance

# Factory
class Dog:
    def speak(self): return "Woof"

class Cat:
    def speak(self): return "Meow"

def get_pet(pet_type="dog"):
    pets = {"dog": Dog, "cat": Cat}
    return pets[pet_type]()
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does Single Responsibility mean?**

> **Answer:** One class, one responsibility

---

**Type 87 to continue**