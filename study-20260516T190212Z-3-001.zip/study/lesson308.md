# Bài 308 — Climbing Stairs (Easy)

## 1. Ôn tập

Từ bài 307, ta đã học Longest Common Subsequence. Hôm nay ta học **Climbing Stairs** - DP đơn giản!

## 2. Mục tiêu bài học

- climbing n stairs, 1 hoặc 2 steps
- Đếm số distinct ways
- Fibonacci pattern

## 3. Code chính (có comment)

```python
def climb_stairs(n):
    """
    Climbing stairs
    Input: n=4
    Output: 5 (1-1-1-1, 1-2-1, 1-1-2, 2-1-1, 2-2)
    """
    if n <= 2:
        return n
    
    # dp[i] = ways để reach stair i
    prev1, prev2 = 2, 1
    
    for i in range(3, n + 1):
        current = prev1 + prev2
        prev2 = prev1
        prev1 = current
    
    return prev1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 308 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3080 |