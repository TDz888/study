# Bài 150 — classmethod and staticmethod

---

## 1. classmethod and staticmethod

```python
class MyClass:
    class_var = 10
    
    def instance_method(self):
        return "Instance method", self
    
    @classmethod
    def class_method(cls):
        return "Class method", cls, cls.class_var
    
    @staticmethod
    def static_method():
        return "Static method"

# Usage
obj = MyClass()
print(obj.instance_method())
print(MyClass.class_method())
print(MyClass.static_method())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 150 / 2000 |
| **XP** | 1500 |
| **Level** | Intermediate |