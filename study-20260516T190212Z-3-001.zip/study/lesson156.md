# Bài 156 — Coroutines

---

## 1. Coroutines

```python
async def fetch_data():
    import asyncio
    await asyncio.sleep(1)
    return "data"

async def main():
    result = await fetch_data()
    print(result)

asyncio.run(main())
```

---

## 2. async for, async with

```python
class AsyncIterator:
    def __init__(self, data):
        self.data = data
        self.index = 0
    
    def __aiter__(self):
        return self
    
    async def __anext__(self):
        if self.index >= len(self.data):
            raise StopAsyncIteration
        result = self.data[self.index]
        self.index += 1
        return result

async def main():
    async for item in AsyncIterator([1, 2, 3]):
        print(item)

asyncio.run(main())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 156 / 2000 |
| **XP** | 1560 |