# Bài 296 — Balanced Binary Tree (Easy)

## 1. Ôn tập

Từ bài 295, ta đã học Convert Sorted Array to BST. Hôm nay ta học **kiểm tra tree có balanced không**!

## 2. Mục tiêu bài học

- Tree balanced = left và right diff ≤ 1
- Kiểm tra cho tất cả subtrees
- Optimize: return -1 if unbalanced

## 3. Code chính (có comment)

```python
def is_balanced(root):
    """
    Kiểm tra balanced
    Input: Tree
    Output: True nếu balanced
    """
    def check(node):
        if not node:
            return 0
        
        left = check(node.left)
        if left == -1:
            return -1
        
        right = check(node.right)
        if right == -1:
            return -1
        
        # Unbalanced nếu diff > 1
        if abs(left - right) > 1:
            return -1
        
        return max(left, right) + 1
    
    return check(root) != -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 296 / 2000 |
| **Chapter** | Trees |
| **XP** | 2960 |