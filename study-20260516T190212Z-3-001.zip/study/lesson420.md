# Bài 420 — Minimum Difference in BST (Easy)

## 1. Ôn tập

Từ bài 419, ta đã học Convert BST to Greater Tree. Hôm nay ta học **Minimum Difference in BST**!

## 2. Mục tiêu bài học

- Tìm min difference giữa 2 nodes
- Inorder traversal gives sorted values
- Compare adjacent values

## 3. Code chính (có comment)

```python
def min_diff_in_bst(root):
    """
    Minimum Difference in BST
    Input: Tree
    Output: Min difference
    """
    result = float('inf')
    prev = None
    
    def inorder(node):
        nonlocal result, prev
        if not node:
            return
        
        inorder(node.left)
        
        if prev:
            result = min(result, node.val - prev)
        prev = node.val
        
        inorder(node.right)
    
    inorder(root)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 420 / 2000 |
| **Chapter** | Trees |
| **XP** | 4200 |