# Bài 168 — asyncio.create_task vs gather

## 1. Ôn tập

Ta đã dùng:
- `asyncio.gather()` - chạy nhiều task, đợi tất cả
- `asyncio.create_task()` - tạo task không đợi

Nhưng khi nào dùng cái nào?

## 2. Mục tiêu bài học

- Phân biệt `create_task` và `gather`
- Hiểu khi nào cần detach task
- Xử lý error trong từng trường hợp

## 3. Code chính (có comment)

```python
import asyncio

async def task_a():
    await asyncio.sleep(2)
    return "A done"

async def task_b():
    await asyncio.sleep(1)
    return "B done"

async def task_c():
    await asyncio.sleep(0.5)
    return "C done"

async def main():
    # Cách 1: gather - đợi TẤT CẢ xong
    print("=== gather ===")
    results = await asyncio.gather(task_a(), task_b(), task_c())
    print(results)  # ['A done', 'B done', 'C done']
    
    # Cách 2: create_task - detach để chạy
    print("\n=== create_task + gather ===")
    # Tạo task mà KHÔNG đợi
    task_b_obj = asyncio.create_task(task_b())  # Chạy ngay!
    task_c_obj = asyncio.create_task(task_c())
    
    # Làm việc khác trong khi B và C chạy
    print("Doing other work...")
    await asyncio.sleep(0.3)
    
    # Đợi tất cả hoàn thành
    all_results = await asyncio.gather(task_b_obj, task_c_obj)
    print(all_results)
    
    # Cách 3: Create task với tên
    print("\n=== Named tasks ===")
    task = asyncio.create_task(task_a(), name="my_task")
    print(f"Task name: {task.get_name()}")
    result = await task
    print(result)

asyncio.run(main())
```

## 4. Trace chạy code

```
=== gather ===
['A done', 'B done', 'C done']

=== create_task + gather ===
Doing other work...
['B done', 'C done']

=== Named tasks ===
Task name: my_task
A done
```

## 5. Debug tư duy

### Khi nào dùng gather?
- Khi cần kết quả của TẤT CẢ tasks
- Khi cần đợi tất cả xong mới tiếp tục

### Khi nào dùng create_task?
- Khi muốn start task sớm nhưng không cần đợi ngay
- Khi muốn làm việc khác trong khi task chạy
- Khi cần quản lý task riêng lẻ

### Error handling khác nhau
```python
# gather - exception sẽ bị raise sau khi tất cả chạy
try:
    await asyncio.gather(task1(), failing_task())
except Exception as e:
    print(f"Error: {e}")

# create_task - exception bị implicit, cần explicit check
task = asyncio.create_task(failing_task())
# ...
result = await task  # Exception sẽ được raise ở đây
```

## 6. Ghi nhớ nhanh

| Phương thức | Đặc điểm |
|-------------|----------|
| `gather` | Đợi tất cả, return list kết quả |
| `create_task` | Tạo ngay, không đợi, có thể cancel riêng |
| `wait()` | Đợi một số task, có thể lấy done + pending |

## 7. Mini test (3 câu)

**Câu 1:** gather trả về gì?
- A) Task objects
- B) List kết quả theo thứ tự
- C) Dict
- D) Tuple

**Câu 2:** create_task có đợi task hoàn thành không?
- A) Có
- B) Không
- C) Tùy trường hợp
- D) Chỉ đợi 1 lần

**Câu 3:** Muốn chạy task ngay mà không cần kết quả ngay, dùng?
- A) gather
- B) create_task
- C) wait
- D) sleep

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Background Scanner"

```python
class BackgroundScanner:
    def __init__(self):
        self.tasks = []
    
    async def start_scan(self, target):
        # Tạo task scan nhưng không block
        task = asyncio.create_task(self._scan(target))
        self.tasks.append(task)
    
    async def wait_all(self):
        # Đợi tất cả scan hoàn thành
        return await asyncio.gather(*self.tasks)
```

## 9. Bonus

Tạo hệ thống:
- Một task chính
- Nhiều background tasks
- Timeout riêng cho từng task
- Cancel một số task khi cần

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 168 / 2000 |
| **XP** | 1680 |