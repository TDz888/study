# Bài 161 — asyncio.Lock

## 1. Ôn tập

Ở bài trước, ta đã học về `Semaphore` - dùng để giới hạn số lượng tác vụ chạy cùng lúc.Semaphore cho phép N tiến trình cùng hoạt động, nhưng không đảm bảo an toàn khi chúng truy cập chung một tài nguyên.

## 2. Mục tiêu bài học

- Hiểu `asyncio.Lock` là gì và khi nào cần dùng
- Học cách bảo vệ tài nguyên chia sẻ trong async code
- Phân biệt được Lock vs Semaphore

## 3. Code chính (có comment)

```python
import asyncio

# Tài nguyên chia sẻ - cần bảo vệ
shared_counter = 0

# Lock để đồng bộ hóa
lock = asyncio.Lock()

async def increment_with_lock(id):
    """Tăng biến đếm một cách an toàn"""
    global shared_counter
    
    # Chỉ một task được vào khối này tại một thời điểm
    async with lock:
        current = shared_counter
        await asyncio.sleep(0.1)  # Giả lập xử lý
        shared_counter = current + 1
        print(f"Task {id}: counter = {shared_counter}")

async def increment_without_lock(id):
    """Tăng biến đếm KHÔNG an toàn - race condition"""
    global shared_counter
    
    current = shared_counter
    await asyncio.sleep(0.1)  # Giả lập xử lý
    shared_counter = current + 1
    print(f"Task {id}: counter = {shared_counter}")

async def main():
    print("=== VỚI LOCK (An toàn) ===")
    global shared_counter
    shared_counter = 0
    
    tasks = [increment_with_lock(i) for i in range(3)]
    await asyncio.gather(*tasks)
    print(f"Kết quả cuối: {shared_counter}")  # Sẽ là 3
    
    print("\n=== KHÔNG LOCK (Rủi ro) ===")
    shared_counter = 0
    tasks = [increment_without_lock(i) for i in range(3)]
    await asyncio.gather(*tasks)
    print(f"Kết quả cuối: {shared_counter}")  # Có thể không phải 3

asyncio.run(main())
```

## 4. Trace chạy code

**Với Lock:**
```
Task 0: counter = 1
Task 1: counter = 2
Task 2: counter = 3
Kết quả cuối: 3  ✓ Đúng
```

**Không Lock (Race Condition):**
```
Task 0: counter = 1
Task 1: counter = 1  ← Đọc TRƯỚC khi Task 0 ghi
Task 2: counter = 1
Kết quả cuối: 1  ✗ Sai
```

## 5. Debug tư duy

### Sai lầm thường gặp
**Sai:** Dùng `lock` ở đầu hàm rồi `await` dài phía sau

```python
async def wrong_usage():
    async with lock:  # Lock quá lâu!
        await process_batch()  # Các task khác phải đợi rất lâu
```

**Đúng:** Chỉ lock phần cần bảo vệ

```python
async def correct_usage():
    data = await fetch_data()  # Không cần lock
    async with lock:  # Chỉ lock phần thay đổi data
        shared_data = data
```

## 6. Ghi nhớ nhanh

| Khái niệm | Ý nghĩa |
|-----------|---------|
| `Lock` | Chỉ cho phép 1 task truy cập tại một thời điểm |
| `Semaphore(N)` | Cho phép N task truy cập cùng lúc |
| `async with lock` | Cách dùng Lock trong async |
| Race Condition | Lỗi khi nhiều task đọc/ghi cùng lúc |

## 7. Mini test (3 câu)

**Câu 1:** Lock đảm bảo mấy task có thể vào vùng trọng yếu cùng lúc?
- A) 0
- B) 1
- C) Nhiều
- D) Tùy ý

**Câu 2:** Đâu là cách dùng Lock đúng?
- A) `with lock:`
- B) `async with lock:`
- C) `lock.acquire()`
- D) `await lock`

**Câu 3:** Khi nào dùng Lock thay vì Semaphore?
- A) Khi cần giới hạn số lượng
- B) Khi cần bảo vệ tài nguyên chia sẻ
- C) Khi cần chạy song song
- D) Khi không có async

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Singleton Pattern với async"

```python
class AsyncSingleton:
    _instance = None
    _lock = asyncio.Lock()
    
    @classmethod
    async def get_instance(cls):
        # Viết code để đảm bảo chỉ tạo 1 instance
        pass

# Test
a = await AsyncSingleton.get_instance()
b = await AsyncSingleton.get_instance()
print(a is b)  # True
```

**Gợi ý:** Dùng `async with cls._lock:` và kiểm tra `_instance is None`

## 9. Bonus

Tạo một producer-consumer với:
- Nhiều producer ghi vào queue
- Một consumer đọc với lock
- Dùng `asyncio.Queue` + `asyncio.Lock`

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 161 / 2000 |
| **Chapter** | Async/Await Nâng cao |
| **XP** | 1610 |