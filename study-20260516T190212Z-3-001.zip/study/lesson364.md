# Bài 364 — Check if Number is a Sum of Powers of Three (Medium)

## 1. Ôn tập

Từ bài 363, ta đã học Most Common Word. Hôm nay ta học **Check Power of Three**!

## 2. Mục tiêu bài học

- Kiểm tra n có phải power of 3 không
- Math approach: 3^k = n
- Loop division

## 3. Code chính (có comment)

```python
def is_power_of_three(n):
    """
    Check Power of Three
    Input: n=27
    Output: True (3^3)
    """
    if n <= 0:
        return False
    
    while n % 3 == 0:
        n //= 3
    
    return n == 1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 364 / 2000 |
| **Chapter** | Math |
| **XP** | 3640 |