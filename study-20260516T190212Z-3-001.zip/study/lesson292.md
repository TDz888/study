# Bài 292 — Lowest Common Ancestor (Medium)

## 1. Ôn tập

Từ bài 291, ta đã học Kth Smallest in BST. Hôm nay ta học **tìm Lowest Common Ancestor**!

## 2. Mục tiêu bài học

- Tìm LCA của 2 nodes trong binary tree
- LCA = lowest node có cả p và q trong subtree
- Dùng recursive traversal

## 3. Code chính (có comment)

```python
def lowest_common_ancestor(root, p, q):
    """
    Tìm LCA
    Input: root, p, q (nodes)
    Output: LCA node
    """
    if not root or root == p or root == q:
        return root
    
    # Search left và right
    left = lowest_common_ancestor(root.left, p, q)
    right = lowest_common_ancestor(root.right, p, q)
    
    # Nếu cả 2 tìm thấy → root là LCA
    if left and right:
        return root
    
    # Return whichever tìm thấy
    return left or right
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 292 / 2000 |
| **Chapter** | Trees |
| **XP** | 2920 |