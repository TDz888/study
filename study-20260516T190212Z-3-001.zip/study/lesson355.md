# Bài 355 — Array Partition (Easy)

## 1. Ôn tập

Từ bài 354, ta đã học Reverse String. Hôm nay ta học **Array Partition**!

## 2. Mục tiêu bài học

- Pair nums, maximize min of each pair
- Sort và sum minimums
- Math reasoning

## 3. Code chính (có comment)

```python
def array_pair_sum(nums):
    """
    Array Partition
    Input: [1,4,3,2]
    Output: 4 (pairs: (1,2), (3,4), min sum = 1+3=4)
    """
    nums.sort()
    
    return sum(nums[::2])
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 355 / 2000 |
| **Chapter** | Array |
| **XP** | 3550 |