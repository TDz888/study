# Lesson 55 — Decorators

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 54 - Iterators.

**Current Lesson:** Learning **Decorators** — modify function behavior.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- What decorators are
- Writing simple decorators
- @decorator syntax
- Decorators with arguments
- Preserving metadata with functools

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Basic Decorator

```python
def my_decorator(func):
    def wrapper():
        print("=== Before ===")
        func()
        print("=== After ===")
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")

say_hello()
# === Before ===
# Hello!
# === After ===
```

### Decorator with Arguments

```python
def repeat(times):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(times):
                func(*args, **kwargs)
        return wrapper
    return decorator

@repeat(3)
def greet(name):
    print(f"Hello {name}!")

greet("World")  # Prints 3 times
```

### Preserve Metadata with functools

```python
import functools

def my_decorator(func):
    @functools.wraps(func)  # Preserves original metadata
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def example():
    """Example docstring"""
    pass

print(example.__name__)  # example (not wrapper!)
print(example.__doc__)   # Example docstring
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does @functools.wraps do?**

> **Answer:** Preserves the original function's name and docstring when using decorators.

---

**Type 56 to continue**