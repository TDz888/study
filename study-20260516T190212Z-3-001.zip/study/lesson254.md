# Bài 254 — BST Insert (Easy)

## 1. Ôn tập

Từ bài 253, ta đã học tìm kiếm trong BST. Hôm nay ta học **chèn node mới** vào BST!

## 2. Mục tiêu bài học

- Chèn node mới vào BST giữ nguyên BST property
- Xử lý 3 trường hợp: chèn vào vị trí trống, bên trái, bên phải
- Độ phức tạp O(log n) cho balanced tree

## 3. Code chính (có comment)

```python
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def insert_bst(root: TreeNode, val: int) -> TreeNode:
    """
    Chèn val vào BST
    Input: root = [4,2,7,1,3], val = 5
    Output: root với node mới chèn vào
    """
    # Base case: tìm được vị trí trống
    if not root:
        return TreeNode(val)
    
    # Nếu val nhỏ hơn root, chèn vào bên trái
    if val < root.val:
        root.left = insert_bst(root.left, val)
    # Nếu val lớn hơn root, chèn vào bên phải
    else:
        root.right = insert_bst(root.right, val)
    
    return root
```

## 4. Giải thích

| Bước | Hành động |
|------|-----------|
| 1 | Nếu root là None → tạo node mới và return |
| 2 | Nếu val < root.val → đệ quy sang bên trái |
| 3 | Nếu val > root.val → đệ quy sang bên phải |
| 4 | Return root sau khi chèn xong |

## 5. Ví dụ minh họa

```
Chèn val = 5 vào cây:
       4
      / \
     2   7
    / \
   1   3

5 > 4 → sang phải
5 < 7 → sang trái
7.left = None → tạo node 5

Kết quả:
       4
      / \
     2   7
    / \  /
   1   3 5
```

## 6. Bài tập

**LeetCode 701: Insert into a Binary Search Tree**

```python
# Đề: Chèn node mới vào BST, return root
# Input: root = [4,2,7,1,3,None,None,None,None,None,None], val = 5
# Output: [4,2,7,1,3,5]
```

Gợi ý: Dùng đệ quy như code trên.

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 254 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2540 |