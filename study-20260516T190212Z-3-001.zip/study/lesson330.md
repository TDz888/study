# Bài 330 — Subsets (Medium)

## 1. Ôn tập

Từ bài 329, ta đã học Permutations. Hôm nay ta học **Subsets**!

## 2. Mục tiêu bài học

- Generate tất cả subsets
- Iterative hoặc recursive
- Binary representation

## 3. Code chính (có comment)

```python
def subsets(nums):
    """
    Subsets
    Input: [1,2,3]
    Output: [[],[1],[2],[3],[1,2],[1,3],[2,3],[1,2,3]]
    """
    result = [[]]
    
    for num in nums:
        # Thêm num vào tất cả existing subsets
        new_subsets = [subset + [num] for subset in result]
        result.extend(new_subsets)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 330 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3300 |