# Bài 369 — Longest Common Prefix (Easy)

## 1. Ôn tập

Từ bài 368, ta đã học Roman to Integer. Hôm nay ta học **Longest Common Prefix**!

## 2. Mục tiêu bài học

- Tìm longest common prefix
- Horizontal scanning
- Sort approach

## 3. Code chính (có comment)

```python
def longest_common_prefix(strs):
    """
    Longest Common Prefix
    Input: ["flower","flow","flight"]
    Output: "fl"
    """
    if not strs:
        return ""
    
    prefix = strs[0]
    
    for s in strs[1:]:
        while not s.startswith(prefix):
            prefix = prefix[:-1]
            if not prefix:
                return ""
    
    return prefix
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 369 / 2000 |
| **Chapter** | String |
| **XP** | 3690 |