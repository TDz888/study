# Bài 149 — __slots__

---

## 1. __slots__ for memory optimization

```python
# Without __slots__ - uses more memory
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

# With __slots__ - less memory
class OptimizedPerson:
    __slots__ = ['name', 'age']
    
    def __init__(self, name, age):
        self.name = name
        self.age = age

# Difference
p1 = Person("Alice", 25)
p2 = OptimizedPerson("Alice", 25)

print(p1.__dict__)  # Has __dict__
print(p2.__dict__)  # AttributeError - no __dict__!

# Faster attribute access
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 149 / 2000 |
| **XP** | 1490 |
| **Level** | Advanced |