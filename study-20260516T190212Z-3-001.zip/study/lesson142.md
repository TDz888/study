# Bài 142 — doctest

---

## 1. doctest module

```python
def add(a, b):
    """
    Add two numbers.
    
    >>> add(2, 3)
    5
    >>> add(0, 0)
    0
    >>> add(-1, 1)
    0
    """
    return a + b

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 142 / 2000 |
| **XP** | 1420 |
| **Level** | Intermediate |