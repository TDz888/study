# Bài 418 — Range Sum of BST (Easy)

## 1. Ôn tập

Từ bài 417, ta đã học Trim a BST. Hôm nay ta học **Range Sum of BST**!

## 2. Mục tiêu bài học

- Sum tất cả nodes trong range [L, R]
- Leverage BST property
- O(n)

## 3. Code chính (có comment)

```python
def range_sum_bst(root, low, high):
    """
    Range Sum of BST
    Input: root, low=7, high=15
    Output: sum trong range
    """
    if not root:
        return 0
    
    if root.val < low:
        return range_sum_bst(root.right, low, high)
    if root.val > high:
        return range_sum_bst(root.left, low, high)
    
    return (root.val + 
            range_sum_bst(root.left, low, high) + 
            range_sum_bst(root.right, low, high))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 418 / 2000 |
| **Chapter** | Trees |
| **XP** | 4180 |