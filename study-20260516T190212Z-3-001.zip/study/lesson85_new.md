# Lesson 85 — Fenwick Tree (Binary Indexed Tree)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 84 - Segment Tree.

**Current Lesson:** Learning **Fenwick Tree** — efficient prefix sum data structure.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Fenwick Tree structure
- Update and query operations

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### BIT Implementation

```python
class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)  # 1-indexed
    
    def update(self, i, delta):
        """Update position i by delta"""
        while i <= self.n:
            self.tree[i] += delta
            i += i & (-i)  # Move to parent
    
    def prefix_sum(self, i):
        """Sum from 1 to i"""
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & (-i)
        return s
    
    def range_sum(self, l, r):
        """Sum from l to r"""
        return self.prefix_sum(r) - self.prefix_sum(l - 1)

# Usage
bit = BIT(5)
bit.update(1, 1)
bit.update(2, 3)
bit.update(3, 5)
print(bit.prefix_sum(3))  # 9
print(bit.range_sum(2, 3))  # 8
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is BIT good for?**

> **Answer:** Efficient prefix sum and updates

---

**Type 86 to continue**