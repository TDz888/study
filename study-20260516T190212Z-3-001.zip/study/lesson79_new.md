# Lesson 79 — Trees (P1)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 78 - Graph Algorithms.

**Current Lesson:** Learning **Trees** — hierarchical data structures.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Binary tree structure
- Tree traversals

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Binary Tree

```python
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

# Create tree
root = TreeNode(1)
root.left = TreeNode(2)
root.right = TreeNode(3)
root.left.left = TreeNode(4)
root.left.right = TreeNode(5)

# Visualization:
#       1
#      / \
#     2   3
#    / \
#   4   5
```

### Tree Traversals

```python
# Inorder: Left -> Root -> Right
def inorder(root):
    if root:
        inorder(root.left)
        print(root.val, end=' ')
        inorder(root.right)

# Preorder: Root -> Left -> Right
def preorder(root):
    if root:
        print(root.val, end=' ')
        preorder(root.left)
        preorder(root.right)

# Postorder: Left -> Right -> Root
def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.val, end=' ')

# Test
inorder(root)   # 4 2 5 1 3
preorder(root)  # 1 2 4 5 3
postorder(root) # 4 5 2 3 1
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is the inorder traversal of a BST?**

> **Answer:** Sorted order of elements

---

**Type 80 to continue**