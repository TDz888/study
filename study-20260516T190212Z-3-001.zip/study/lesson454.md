# Bài 454 — Walls and Gates (Medium)

## 1. Ôn tập

Từ bài 453, ta đã học Number of Islands. Hôm nay ta học **Walls and Gates**!

## 2. Mục tiêu bài học

- Fill empty rooms với distance to gate
- BFS from all gates
- O(m*n)

## 3. Code chính (có comment)

```python
from collections import deque

def walls_and_gates(rooms):
    """
    Walls and Gates
    Input: rooms=[[2147483647,-1,0,2147483647],
                  [2147483647,2147483647,2147483647,-1],
                  [2147483647,-1,2147483647,-1],
                  [0,-1,2147483647,2147483647]]
    Output: rooms với distances
    """
    if not rooms:
        return
    
    rows, cols = len(rooms), len(rooms[0])
    queue = deque()
    
    # Add all gates
    for r in range(rows):
        for c in range(cols):
            if rooms[r][c] == 0:
                queue.append((r, c, 0))
    
    directions = [(0,1),(0,-1),(1,0),(-1,0)]
    
    while queue:
        r, c, dist = queue.popleft()
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and rooms[nr][nc] == 2147483647:
                rooms[nr][nc] = dist + 1
                queue.append((nr, nc, dist + 1))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 454 / 2000 |
| **Chapter** | BFS |
| **XP** | 4540 |