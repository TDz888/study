# Bài 134 — bisect (Binary Search)

---

## 1. bisect module

```python
import bisect

# List must be sorted
arr = [1, 3, 5, 7, 9]

# bisect_left
pos = bisect.bisect_left(arr, 5)
print(pos)  # 2

# bisect_right
pos = bisect.bisect_right(arr, 5)
print(pos)  # 3

# Insert position
bisect.insort(arr, 4)
print(arr)  # [1, 3, 4, 5, 7, 9]

# Find position for 6
pos = bisect.bisect_left(arr, 6)
print(pos)  # 4
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 134 / 2000 |
| **XP** | 1340 |
| **Level** | Intermediate |