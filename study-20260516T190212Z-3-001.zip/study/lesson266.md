# Bài 266 — Path Sum II (Medium)

## 1. Ôn tập

Từ bài 265, ta đã học kiểm tra có đường đi = target không. Hôm nay ta học **tìm tất cả đường đi**!

## 2. Mục tiêu bài học

- Tìm tất cả đường đi từ root đến leaf có tổng = target
- Lưu đường đi vào result
- Backtracking để thêm/xóa node

## 3. Code chính (có comment)

```python
def path_sum(root: TreeNode, target: int) -> list:
    """
    Tìm tất cả đường đi có tổng = target
    Input: root = [5,4,8,11,None,13,4,7,2,None,None,5,4], target = 22
    Output: [[5,4,11,2], [5,8,4,5]]
    """
    result = []
    
    def traverse(node, remaining, path):
        if not node:
            return
        
        # Thêm node hiện tại vào path
        path.append(node.val)
        remaining -= node.val
        
        # Nếu là leaf và tổng = target → lưu path
        if not node.left and not node.right and remaining == 0:
            result.append(list(path))
        
        # Đệ quy 2 cây con
        traverse(node.left, remaining, path)
        traverse(node.right, remaining, path)
        
        # Backtracking: xóa node cuối
        path.pop()
    
    traverse(root, target, [])
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 266 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2660 |