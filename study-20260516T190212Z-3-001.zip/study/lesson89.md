# Bài 89 — Design Patterns (Behavioral)

---

## 1. Giới thiệu
Học về **Behavioral Design Patterns**.

---

## 2. Observer

```python
class Subject:
    def __init__(self):
        self.observers = []
    
    def attach(self, observer):
        self.observers.append(observer)
    
    def notify(self):
        for obs in self.observers:
            obs.update()

class Observer:
    def update(self):
        print("Updated!")

s = Subject()
o1 = Observer()
o2 = Observer()
s.attach(o1)
s.attach(o2)
s.notify()
```

---

## 3. Strategy

```python
class Strategy:
    def execute(self, data):
        pass

class ConcreteA(Strategy):
    def execute(self, data):
        return sorted(data)

class ConcreteB(Strategy):
    def execute(self, data):
        return sorted(data, reverse=True)

class Context:
    def __init__(self, strategy):
        self.strategy = strategy
    
    def do_something(self, data):
        return self.strategy.execute(data)

c = Context(ConcreteA())
print(c.do_something([3, 1, 2]))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 89 / 2000 |
| **XP** | 890 |
| **Level** | Advanced |