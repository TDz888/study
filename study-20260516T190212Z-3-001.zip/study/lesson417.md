# Bài 417 — Trim a BST (Easy)

## 1. Ôn tập

Từ bài 416, ta đã học Sum of Root to Leaf. Hôm nay ta học **Trim a BST**!

## 2. Mục tiêu bài học

- Remove nodes ngoài range [low, high]
- Recursively trim
- BST property preserved

## 3. Code chính (có comment)

```python
def trim_bst(root, low, high):
    """
    Trim BST
    Input: root, low=1, high=3
    Output: Tree đã trim
    """
    if not root:
        return None
    
    if root.val < low:
        return trim_bst(root.right, low, high)
    if root.val > high:
        return trim_bst(root.left, low, high)
    
    root.left = trim_bst(root.left, low, high)
    root.right = trim_bst(root.right, low, high)
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 417 / 2000 |
| **Chapter** | Trees |
| **XP** | 4170 |