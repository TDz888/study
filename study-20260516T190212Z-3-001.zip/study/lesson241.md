# Bài 241 — Lowest Common Ancestor (Medium)

## 1. Ôn tập

Từ bài 240, ta đã học kth smallest. Hôm nay ta học **Lowest Common Ancestor**!

## 2. Mục tiêu bài học

- Tìm tổ tiên chung thấp nhất của 2 nodes
- Có thể dùng path hoặc recursive
- Binary Lifting cho nhiều queries

## 3. Code chính (có comment)

```python
def lowest_common_ancestor(root: TreeNode, p: TreeNode, q: TreeNode) -> TreeNode:
    """
    Tìm LCA của 2 nodes
    Input: root = [3,5,1,6,2,0,8,null,null,7,4], p=5, q=1
    Output: 3
    """
    if not root or root == p or root == q:
        return root
    
    left = lowest_common_ancestor(root.left, p, q)
    right = lowest_common_ancestor(root.right, p, q)
    
    if left and right:
        return root
    return left or right
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 241 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2410 |