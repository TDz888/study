# Bài 323 — Trapping Rain Water (Hard)

## 1. Ôn tập

Từ bài 322, ta đã học Valid Sudoku. Hôm nay ta học **Trapping Rain Water**!

## 2. Mục tiêu bài học

- Tính nước bị trapped giữa các walls
- Two pointers approach
- Water at i = min(max_left, max_right) - height[i]

## 3. Code chính (có comment)

```python
def trap(height):
    """
    Trapping Rain Water
    Input: [0,1,0,2,1,0,1,3,2,1,2,1]
    Output: 6 units
    """
    if not height:
        return 0
    
    left, right = 0, len(height) - 1
    left_max, right_max = 0, 0
    water = 0
    
    while left < right:
        if height[left] < height[right]:
            if height[left] >= left_max:
                left_max = height[left]
            else:
                water += left_max - height[left]
            left += 1
        else:
            if height[right] >= right_max:
                right_max = height[right]
            else:
                water += right_max - height[right]
            right -= 1
    
    return water
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 323 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3230 |