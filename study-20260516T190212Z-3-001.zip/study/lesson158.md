# Bài 158 — aiofiles

---

## 1. Async file operations

```python
# pip install aiofiles
import aiofiles
import asyncio

async def read_file():
    async with aiofiles.open('file.txt', 'r') as f:
        content = await f.read()
    print(content)

async def write_file():
    async with aiofiles.open('output.txt', 'w') as f:
        await f.write('Hello async!')

async def main():
    await write_file()
    await read_file()

asyncio.run(main())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 158 / 2000 |
| **XP** | 1580 |