# Bài 238 — Binary Tree Maximum Path Sum (Hard)

## 1. Ôn tập

Từ bài 237, ta đã học zigzag traversal. Hôm nay ta học **Maximum Path Sum**!

## 2. Mục tiêu bài học

- Tìm max sum của bất kỳ path nào
- Path có thể không qua root
- Helper return max contribution từ node

## 3. Code chính (có comment)

```python
def max_path_sum(root: TreeNode) -> int:
    """
    Tìm maximum path sum
    Input: root = [-10,9,20,null,null,15,7]
    Output: 42 (path: 20->15->7)
    """
    max_sum = float('-inf')
    
    def dfs(node):
        nonlocal max_sum
        if not node:
            return 0
        
        # Tính max từ left và right
        left = max(dfs(node.left), 0)
        right = max(dfs(node.right), 0)
        
        # Path through node
        max_sum = max(max_sum, node.val + left + right)
        
        # Return max contribution cho parent
        return node.val + max(left, right)
    
    dfs(root)
    return max_sum
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 238 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2380 |