# Bài 383 — Minimum Window Substring (Hard)

## 1. Ôn tập

Từ bài 382, ta đã học Find All Anagrams. Hôm nay ta học **Minimum Window Substring**!

## 2. Mục tiêu bài học

- Tìm minimum window chứa tất cả chars của t
- Sliding window với two counters
- O(n)

## 3. Code chính (có comment)

```python
def min_window(s, t):
    """
    Minimum Window Substring
    Input: s="ADOBECODEBANC", t="ABC"
    Output: "BANC"
    """
    from collections import Counter
    
    t_count = Counter(t)
    window = Counter()
    
    left = 0
    required = len(t_count)
    formed = 0
    min_len = float('inf')
    result = ""
    
    for right in range(len(s)):
        window[s[right]] += 1
        
        if s[right] in t_count and window[s[right]] == t_count[s[right]]:
            formed += 1
        
        while formed == required:
            if right - left + 1 < min_len:
                min_len = right - left + 1
                result = s[left:right+1]
            
            window[s[left]] -= 1
            if s[left] in t_count and window[s[left]] < t_count[s[left]]:
                formed -= 1
            left += 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 383 / 2000 |
| **Chapter** | Sliding Window |
| **XP** | 3830 |