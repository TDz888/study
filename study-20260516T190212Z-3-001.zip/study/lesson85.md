# Bài 85 — Fenwick Tree (Binary Indexed Tree)

---

## 1. Ôn tập
Bài 84 đã học về Segment Tree. Giờ học **Fenwick Tree** (còn gọi là Binary Indexed Tree - BIT) — cấu trúc dữ liệu tối ưu cho prefix sum.

---

## 2. Mục tiêu bài học
- Hiểu Fenwick Tree là gì
- Biết cách cài đặt BIT
- Nắm vững update và query
- So sánh với Segment Tree

---

## 3. Code chính (có comment)

### BIT Implementation
```python
class BIT:
    def __init__(self, n):
        """Khởi tạo BIT với n phần tử"""
        self.n = n
        self.tree = [0] * (n + 1)  # 1-indexed
    
    def update(self, i, delta):
        """Cập nhật giá trị tại vị trí i thêm delta"""
        while i <= self.n:
            self.tree[i] += delta
            i += i & (-i)  # Di chuyển đến parent
    
    def prefix_sum(self, i):
        """Tính tổng từ 1 đến i"""
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & (-i)  # Di chuyển đến parent
        return s
    
    def range_sum(self, l, r):
        """Tính tổng từ l đến r"""
        return self.prefix_sum(r) - self.prefix_sum(l - 1)

# Test
bit = BIT(5)

# Thêm giá trị: [1, 2, 3, 4, 5]
for i in range(1, 6):
    bit.update(i, i)

print(bit.prefix_sum(3))      # 1 + 2 + 3 = 6
print(bit.range_sum(2, 4))    # 2 + 3 + 4 = 9
```

### Cách BIT hoạt động
```python
# Cập nhật tại index 1:
# tree[1] += delta
# i = 1 + (1 & -1) = 2
# tree[2] += delta
# i = 2 + (2 & -1) = 4
# tree[4] += delta
# i = 4 + (4 & -1) = 8 > n → dừng

# Query tại index 3:
# s += tree[3]
# i = 3 - (3 & -1) = 2
# s += tree[2]
# i = 2 - (2 & -1) = 0 → dừng
```

---

## 4. Trace chạy code

```
BIT với n=5, cập nhật giá trị [1,2,3,4,5]:

Initial: tree = [0, 0, 0, 0, 0, 0]

Update(1, 1): tree[1]+=1, tree[2]+=1, tree[4]+=1
            → tree = [0,1,1,0,1,0]

Update(2, 2): tree[2]+=2, tree[4]+=2
            → tree = [0,1,3,0,3,0]

Update(3, 3): tree[3]+=3, tree[4]+=3
            → tree = [0,1,3,3,6,0]

Update(4, 4): tree[4]+=4
            → tree = [0,1,3,3,10,0]

Update(5, 5): tree[5]+=5
            → tree = [0,1,3,3,10,5]

Query(3): tree[3] + tree[2] = 3 + 3 = 6
         → 1 + 2 + 3 = 6 ✓
```

---

## 5. Debug tư duy

### ❌ Lỗi 1 — Nhầm 0-indexed và 1-indexed
```python
# LỖI! BIT dùng 1-indexed
bit = BIT(5)
bit.update(0, 1)  # LỖI! Index bắt đầu từ 1

# ✅ Sửa
bit.update(1, 1)  # Đúng
```

### ❌ Lỗi 2 — Không hiểu i & -i
```python
# i & -i là phép toán lấy least significant bit
# 6 (110) & -6 (010) = 2 (010)
# 4 (100) & -4 (100) = 4 (100)
# 8 (1000) & -8 (1000) = 8 (1000)

# Công thức di chuyển trong BIT:
# Update: i += i & -i (lên parent)
# Query: i -= i & -i (xuống child)
```

### ❌ Lỗi 3 — So sánh với Segment Tree
```python
# Fenwick Tree:
# - Code ngắn hơn
# - Memory ít hơn O(n)
# - Chỉ hỗ trợ prefix sum

# Segment Tree:
# - Code dài hơn  
# - Memory nhiều hơn O(4n)
# - Hỗ trợ range query và update phức tạp hơn
# - Lazy propagation
```

---

## 6. Ghi nhớ nhanh

| Operation | Time Complexity | Space |
|-----------|----------------|-------|
| Update | O(log n) | O(n) |
| Prefix Sum | O(log n) | |
| Range Sum | O(log n) | |

**MẸO NHỚ:** BIT = "Cây chỉ số nhị phân" - dùng phép toán & để di chuyển.

---

## 7. Mini test (3 câu)

**Câu 1:** BIT dùng mấy index?
> Đáp án: **1-indexed** (bắt đầu từ 1, không dùng index 0)

**Câu 2:** Cập nhật một phần tử trong BIT mất bao lâu?
> Đáp án: **O(log n)**

**Câu 3:** Ưu điểm của BIT so với Segment Tree?
> Đáp án: **Code ngắn hơn, memory ít hơn**

---

## 8. LeetCode Practice

### Bài tập: Range Sum Query
**Yêu cầu:** Tạo class với update và sum

**Input:**
```
["BIT", "update", "sum", "update", "sum"]
[[5], [1, 3], [1, 3], [2, 2], [1, 5]]
```

**Output:**
```
3
7
```

**✅ Đáp án:**
```python
class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)
    
    def update(self, i, delta):
        while i <= self.n:
            self.tree[i] += delta
            i += i & (-i)
    
    def prefix_sum(self, i):
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & -i
        return s
    
    def range_sum(self, l, r):
        return self.prefix_sum(r) - self.prefix_sum(l - 1)

# Test
bit = BIT(5)
bit.update(1, 3)
print(bit.range_sum(1, 3))  # 3
bit.update(2, 2)
print(bit.range_sum(1, 5))  # 7
```

---

## 9. Bonus (nếu học tốt)

**Thử thách:** Tìm k-th smallest element trong array

**Input:**
```
[1, 3, 5, 2, 2], k=3
```

**Output:** `2` (phần tử nhỏ thứ 3 là 2)

**✅ Đáp án:**
```python
class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)
    
    def update(self, i, delta):
        while i <= self.n:
            self.tree[i] += delta
            i += i & -i
    
    def prefix_sum(self, i):
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & -i
        return s
    
    def find_kth(self, k):
        # Binary search trên BIT
        idx = 0
        bit_mask = 1 << (self.n.bit_length() - 1)
        
        while bit_mask:
            t = idx + bit_mask
            if t <= self.n and self.tree[t] < k:
                idx = t
                k -= self.tree[t]
            bit_mask >>= 1
        
        return idx + 1

# Test
nums = [1, 3, 5, 2, 2]
max_val = max(nums)
bit = BIT(max_val)

for num in nums:
    bit.update(num, 1)

print(bit.find_kth(3))  # 2
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 85 / 2000 |
| **Chapter** | 5 (Data Structures) |
| **XP** | 850 (+20 XP khi hoàn thành) |
| **Level** | Advanced |

---

**🎉 Bạn đã hoàn thành Bài 85!**

Gõ **86** để học tiếp Bài 86 (Trie) →