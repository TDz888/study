# Bài 121 — Environment Variables

---

## 1. Ôn tập
Bài 120 đã học Secrets Module. Giờ học **Environment Variables** trong Python.

---

## 2. Mục tiêu bài học
- Đọc biến môi trường
- Đặt biến môi trường
- Ứng dụng thực tế

---

## 3. Code chính (có comment)

### Đọc Environment Variables
```python
import os

# Lấy giá trị
print(os.environ.get('HOME'))     # Linux/Mac
print(os.environ.get('PATH'))     # Đường dẫn hệ thống

# Lấy với default
print(os.environ.get('UNKNOWN', 'default'))

# Danh sách tất cả
for key, value in os.environ.items():
    print(f"{key}={value}")
```

### Đặt Environment Variable
```python
import os

# Đặt biến (chỉ trong session hiện tại)
os.environ['MY_VAR'] = 'hello'
print(os.environ.get('MY_VAR'))  # hello

# Xóa biến
del os.environ['MY_VAR']
```

---

## 4. Debug tư duy

### ❌ Lỗi 1 — Key không tồn tại
```python
# LỖI! KeyError
print(os.environ['NONEXISTENT'])

# ✅ Dùng get
print(os.environ.get('NONEXISTENT'))
```

---

## 8. LeetCode Practice

### Bài tập: Đọc config
**Yêu cầu:** Đọc biến môi trường

**Input:** (không có)

**Output:** giá trị hoặc default

**✅ Đáp án:**
```python
import os

database_url = os.environ.get('DATABASE_URL', 'sqlite://default.db')
print(database_url)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 121 / 2000 |
| **Chapter** | 4 (Data Structures) |
| **XP** | 1210 (+10 XP khi hoàn thành) |
| **Level** | Easy |

---

**🎉 Bạn đã hoàn thành Bài 121!**

Gõ **122** để học tiếp Bài 122 (Argparse) →