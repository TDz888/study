# Lesson 61 — Datetime Handling

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 60 - CSV Handling.

**Current Lesson:** Learning **DateTime** — working with dates and times.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- datetime module basics
- Format and parse datetime
- Timedelta operations

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
from datetime import datetime, date, time, timedelta

# Current time
now = datetime.now()
print(now)  # 2024-01-15 10:30:45

# Create specific datetime
dt = datetime(2024, 1, 15, 10, 30, 45)

# Format
print(now.strftime("%Y-%m-%d"))  # 2024-01-15
print(now.strftime("%H:%M:%S"))  # 10:30:45

# Parse
dt = datetime.strptime("2024-01-15 10:30", "%Y-%m-%d %H:%M")
```

### Timedelta

```python
from datetime import timedelta

# Add/subtract time
future = now + timedelta(days=7)
past = now - timedelta(hours=24)
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does strftime do?**

> **Answer:** Converts datetime to string with specified format

---

**Type 62 to continue**