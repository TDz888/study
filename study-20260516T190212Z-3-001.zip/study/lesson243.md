# Bài 243 — Construct Binary Tree from Preorder Inorder (Medium)

## 1. Ôn tập

Từ bài 242, ta đã học serialize. Hôm nay ta học **Build Tree từ Preorder & Inorder**!

## 2. Mục tiêu bài học

- Tái tạo tree từ 2 traversals
- Preorder: root, left, right
- Inorder: left, root, right
- Recursive với index tracking

## 3. Code chính (có comment)

```python
def build_tree(preorder: List[int], inorder: List[int]) -> TreeNode:
    """
    Build tree từ preorder và inorder
    Input: pre=[3,9,20,15,7], in=[9,3,15,20,7]
    Output: [3,9,20,null,null,15,7]
    """
    if not preorder or not inorder:
        return None
    
    index_map = {val: i for i, val in enumerate(inorder)}
    
    def build(pre_start, pre_end, in_start, in_end):
        if pre_start > pre_end:
            return None
        
        root_val = preorder[pre_start]
        root = TreeNode(root_val)
        
        in_root_idx = index_map[root_val]
        left_size = in_root_idx - in_start
        
        root.left = build(pre_start+1, pre_start+left_size, in_start, in_root_idx-1)
        root.right = build(pre_start+left_size+1, pre_end, in_root_idx+1, in_end)
        
        return root
    
    return build(0, len(preorder)-1, 0, len(inorder)-1)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 243 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2430 |