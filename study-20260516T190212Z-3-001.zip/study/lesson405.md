# Bài 405 — Binary Tree Zigzag Level Order (Medium)

## 1. Ôn tập

Từ bài 404, ta đã học Level Order. Hôm nay ta học **Zigzag Level Order**!

## 2. Mục tiêu bài học

- Traverse với zigzag pattern
- L→R, then R→L
- BFS với reverse flag

## 3. Code chính (có comment)

```python
def zigzag_level_order(root):
    """
    Zigzag Level Order
    Input: Tree
    Output: [[1], [3,2], [4,5]]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    left_to_right = True
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        if not left_to_right:
            level.reverse()
        result.append(level)
        left_to_right = not left_to_right
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 405 / 2000 |
| **Chapter** | Trees |
| **XP** | 4050 |