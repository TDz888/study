# Bài 394 — Power of Two (Easy)

## 1. Ôn tập

Từ bài 393, ta đã học Bitwise AND. Hôm nay ta học **Power of Two**!

## 2. Mục tiêu bài học

- Kiểm tra n có phải power of 2 không
- Bit manipulation: n & (n-1)
- O(1)

## 3. Code chính (có comment)

```python
def is_power_of_two(n):
    """
    Power of Two
    Input: n=16
    Output: True
    """
    if n <= 0:
        return False
    
    return n & (n - 1) == 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 394 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3940 |