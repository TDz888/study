# Lesson 75 — BFS and DFS

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 74 - Functional Programming.

**Current Lesson:** Learning **BFS** and **DFS** — graph traversal algorithms.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- BFS (Breadth-First Search)
- DFS (Depth-First Search)
- When to use each

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Graph Representation

```python
from collections import deque

graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': [],
    'F': []
}

# Visualization:
#     A
#    / \
#   B   C
#  / \   \
# D   E   F
```

### BFS (Breadth-First Search)

```python
from collections import deque

def bfs(graph, start):
    visited = set()
    queue = deque([start])
    visited.add(start)
    
    while queue:
        node = queue.popleft()
        print(node, end=' ')
        
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

# Output: A B C D E F
```

### DFS (Depth-First Search)

```python
def dfs(graph, start, visited=None):
    if visited is None:
        visited = set()
    
    print(start, end=' ')
    visited.add(start)
    
    for neighbor in graph[start]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)

# Output: A B D E C F
```

### When to Use

| Algorithm | Best For |
|-----------|----------|
| BFS | Shortest path, level-order |
| DFS | Path finding, cycle detection |

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What data structure does BFS use?**

> **Answer:** Queue

---

**Type 76 to continue**