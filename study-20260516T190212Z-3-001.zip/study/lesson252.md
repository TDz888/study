# Bài 252 — Merge Two Binary Trees (Easy)

## 1. Ôn tập

Từ bài 251, ta đã học univalue path. Hôm nay ta học **Merge Two Binary Trees**!

## 2. Mục tiêu bài học

- Merge hai trees thành một
- Cộng values nếu cả hai đều có
- Recursive

## 3. Code chính (có comment)

```python
def merge_trees(t1: TreeNode, t2: TreeNode) -> TreeNode:
    """
    Merge hai trees
    Input: t1=[1,3,2,5], t2=[2,1,3,null,4,null,7]
    Output: [3,4,5,5,4,null,7]
    """
    if not t1:
        return t2
    if not t2:
        return t1
    
    t1.val += t2.val
    t1.left = merge_trees(t1.left, t2.left)
    t1.right = merge_trees(t1.right, t2.right)
    
    return t1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 252 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2520 |