# Bài 314 — Longest Increasing Path in Matrix (Hard)

## 1. Ôn tập

Từ bài 313, ta đã học Target Sum. Hôm nay ta học **Longest Increasing Path in Matrix**!

## 2. Mục tiêu bài học

- Tìm longest increasing path trong matrix
- DFS + memoization
- 4 directions

## 3. Code chính (có comment)

```python
def longest_increasing_path(matrix):
    """
    Longest Increasing Path
    Input: matrix=[[9,9,4],[6,6,8],[2,1,1]]
    Output: 4 ([1,2,6,9] hoặc [1,2,6,8])
    """
    if not matrix:
        return 0
    
    rows, cols = len(matrix), len(matrix[0])
    memo = {}
    
    def dfs(r, c):
        if (r, c) in memo:
            return memo[(r, c)]
        
        max_path = 1
        for dr, dc in [(0,1),(0,-1),(1,0),(-1,0)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and matrix[nr][nc] > matrix[r][c]:
                max_path = max(max_path, 1 + dfs(nr, nc))
        
        memo[(r, c)] = max_path
        return max_path
    
    return max(dfs(r, c) for r in range(rows) for c in range(cols))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 314 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3140 |