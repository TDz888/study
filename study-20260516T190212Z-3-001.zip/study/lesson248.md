# Bài 248 — Subtree of Another Tree (Easy)

## 1. Ôn tập

Từ bài 247, ta đã học next pointers. Hôm nay ta học **Subtree of Another Tree**!

## 2. Mục tiêu bài học

- Kiểm tra tree có chứa subtree không
- Match structure và values
- Recursive check

## 3. Code chính (có comment)

```python
def is_subtree(root: TreeNode, sub_root: TreeNode) -> bool:
    """
    Kiểm tra root có chứa sub_root không
    Input: root = [3,4,5,1,2], sub = [4,1,2]
    Output: True
    """
    if not root:
        return False
    if not sub_root:
        return True
    
    def is_same(s, t):
        if not s and not t:
            return True
        if not s or not t:
            return False
        return s.val == t.val and is_same(s.left, t.left) and is_same(s.right, t.right)
    
    # Check từng node
    return is_same(root, sub_root) or is_subtree(root.left, sub_root) or is_subtree(root.right, sub_root)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 248 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2480 |