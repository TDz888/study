# Bài 301 — Coin Change (Medium)

## 1. Ôn tập

Từ bài 300, ta đã học Longest Increasing Subsequence. Hôm nay ta học **Coin Change** - DP cổ điển!

## 2. Mục tiêu bài học

- Tìm số coins ít nhất để tạo amount
- Unbounded knapsack
- dp[i] = min coins cho amount i

## 3. Code chính (có comment)

```python
def coin_change(coins, amount):
    """
    Tìm min coins
    Input: coins=[1,2,5], amount=11
    Output: 3 (5+5+1)
    """
    # dp[i] = min coins cho amount i
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    
    for i in range(1, amount + 1):
        for coin in coins:
            if coin <= i:
                dp[i] = min(dp[i], dp[i - coin] + 1)
    
    return dp[amount] if dp[amount] != float('inf') else -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 301 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3010 |