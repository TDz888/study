# Bài 361 — Valid Anagram (Easy)

## 1. Ôn tập

Từ bài 360, ta đã học Isomorphic Strings. Hôm nay ta học **Valid Anagram**!

## 2. Mục tiêu bài học

- Kiểm tra 2 strings có anagram không
- Sort hoặc Counter
- O(n)

## 3. Code chính (có comment)

```python
def is_anagram(s, t):
    """
    Valid Anagram
    Input: s="anagram", t="nagaram"
    Output: True
    """
    if len(s) != len(t):
        return False
    
    from collections import Counter
    return Counter(s) == Counter(t)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 361 / 2000 |
| **Chapter** | String |
| **XP** | 3610 |