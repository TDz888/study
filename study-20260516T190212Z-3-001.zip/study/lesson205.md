# Bài 205 — LeetCode: Maximum Subarray (Medium)

## 1. Ôn tập

Từ bài 201-204, ta đã học hash table, two pointers, linked list. Hôm nay ta học **Dynamic Programming** cơ bản nhất: Kadane's Algorithm!

## 2. Mục tiêu bài học

- Tìm subarray có tổng lớn nhất
- Hiểu Kadane's Algorithm
- Nắm vững DP approach

## 3. Code chính (có comment)

```python
from typing import List

def max_sub_array(nums: List[int]) -> int:
    """
    Tìm subarray có tổng lớn nhất
    Input: [-2,1,-3,4,-1,2,1,-5,4]
    Output: 6 (subarray: [4,-1,2,1])
    
    Kadane's Algorithm:
    - Tại mỗi vị trí, quyết định: extend hay restart
    """
    # max_current = tổng lớn nhất kết thúc tại vị trí hiện tại
    # max_global = tổng lớn nhất tìm được
    
    max_current = max_global = nums[0]
    
    for i in range(1, len(nums)):
        # Quyết định: extend hay restart
        # Nếu nums[i] + max_current < nums[i] → restart
        max_current = max(nums[i], max_current + nums[i])
        
        # Cập nhật global max
        max_global = max(max_global, max_current)
    
    return max_global

# Test
nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
print(max_sub_array(nums))  # 6
```

## 4. Trace chạy code

```
nums = [-2,1,-3,4,-1,2,1,-5,4]

i=0: max_current=max_global=-2
i=1: max_current=max(1, -2+1)=1 → max_global=1
i=2: max_current=max(-3, 1-3)=-2 → max_global=1  
i=3: max_current=max(4, -2+4)=4 → max_global=4
i=4: max_current=max(-1, 4-1)=3 → max_global=4
i=5: max_current=max(2, 3+2)=5 → max_global=5
i=6: max_current=max(1, 5+1)=6 → max_global=6  ← MAX!
i=7: max_current=max(-5, 6-5)=1 → max_global=6
i=8: max_current=max(4, 1+4)=5 → max_global=6

Output: 6
```

## 5. Debug tư duy

### Tại sao công thức là max(nums[i], max_current + nums[i])?
```
Nếu max_current + nums[i] < nums[i]:
  → Tổng trước là negative, tốt hơn restart

Ví dụ: max_current = -5, nums[i] = 3
max_current + nums[i] = -2 < 3
→ Nên restart từ 3
```

### Chỉ cần 2 biến, không cần array!
```python
# Sai: Dùng DP array
dp = [0] * len(nums)  # Không cần!

# Đúng: Chỉ 2 biến
max_current = max_global = nums[0]
```

## 6. Ghi nhớ nhanh

| Approach | Time | Space |
|----------|------|-------|
| Brute Force | O(n³) | O(1) |
| DP (Kadane) | O(n) | O(1) |
| Divide & Conquer | O(n log n) | O(log n) |

## 7. Mini test (3 câu)

**Câu 1:** Kadane's Algorithm dùng mấy biến?
- A) 1
- B) 2
- C) n
- D) n²

**Câu 2:** max_current = max(nums[i], max_current + nums[i]) nghĩa là gì?
- A) Cộng tất cả
- B) Extend hoặc restart
- C) Tìm max
- D) Reset về 0

**Câu 3:** Time complexity là?
- A) O(n²)
- B) O(n³)
- C) O(n)
- D) O(log n)

**Đáp án:** 1-B, 2-B, 3-C

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 205 / 2000 |
| **XP** | 2050 |