# Bài 385 — Find the Duplicate Number (Medium)

## 1. Ôn tập

Từ bài 384, ta đã học Subarray Sum Equals K. Hôm nay ta học **Find the Duplicate Number**!

## 2. Mục tiêu bài học

- Tìm duplicate trong array 1→n
- Không dùng extra space
- Floyd's Tortoise (Linked List cycle)

## 3. Code chính (có comment)

```python
def find_duplicate(nums):
    """
    Find Duplicate
    Input: [1,3,4,2,2]
    Output: 2
    """
    # Floyd's Tortoise
    slow = nums[0]
    fast = nums[nums[0]]
    
    while slow != fast:
        slow = nums[slow]
        fast = nums[nums[fast]]
    
    slow = 0
    while slow != fast:
        slow = nums[slow]
        fast = nums[fast]
    
    return slow
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 385 / 2000 |
| **Chapter** | Array |
| **XP** | 3850 |