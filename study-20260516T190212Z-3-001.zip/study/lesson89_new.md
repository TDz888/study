# Lesson 89 — Design Patterns (Behavioral)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 88 - Design Patterns (Structural).

**Current Lesson:** Learning **Behavioral Design Patterns**.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Observer pattern
- Strategy pattern

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Observer

```python
class Subject:
    def __init__(self):
        self.observers = []
    
    def attach(self, observer):
        self.observers.append(observer)
    
    def notify(self):
        for obs in self.observers:
            obs.update()

class Observer:
    def update(self):
        print("Updated!")

s = Subject()
o1 = Observer()
o2 = Observer()
s.attach(o1)
s.attach(o2)
s.notify()
```

### Strategy

```python
class Strategy:
    def execute(self, data):
        pass

class StrategyA(Strategy):
    def execute(self, data):
        return sorted(data)

class StrategyB(Strategy):
    def execute(self, data):
        return data[::-1]

class Context:
    def __init__(self, strategy):
        self.strategy = strategy
    
    def do_something(self, data):
        return self.strategy.execute(data)

context = Context(StrategyA())
print(context.do_something([3,1,2]))  # [1,2,3]
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does Observer pattern do?**

> **Answer:** Notifies multiple objects of state changes

---

**Type 90 to continue**