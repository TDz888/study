# Bài 104 — NumPy Basics

---

## 1. NumPy Arrays

```python
import numpy as np

# Tạo array
arr = np.array([1, 2, 3, 4, 5])
print(arr)  # [1 2 3 4 5]

# Array 2D
arr2d = np.array([[1, 2], [3, 4]])
print(arr2d)

# Array với giá trị mặc định
zeros = np.zeros((3, 3))
ones = np.ones((2, 4))
range_arr = np.arange(0, 10, 2)  # [0 2 4 6 8]
```

---

## 2. Operations

```python
arr = np.array([1, 2, 3])
print(arr + 1)    # [2 3 4]
print(arr * 2)    # [2 4 6]
print(arr.sum())  # 6
print(arr.mean()) # 2.0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 104 / 2000 |
| **XP** | 1040 |
| **Level** | Intermediate |