# Bài 273 — AVL Insert (Medium)

## 1. Ôn tập

Từ bài 272, ta đã học AVL cơ bản. Hôm nay ta học **chèn vào AVL** tự cân bằng!

## 2. Mục tiêu bài học

- Insert như BST bình thường
- Sau insert: kiểm tra balance và rotate nếu cần
- Độ phức tạp O(log n)

## 3. Code chính (có comment)

```python
def avl_insert(node, val):
    # 1. Insert như BST bình thường
    if not node:
        return AVLNode(val)
    
    if val < node.val:
        node.left = avl_insert(node.left, val)
    elif val > node.val:
        node.right = avl_insert(node.right, val)
    else:
        return node
    
    # 2. Cập nhật height
    node.height = 1 + max(get_height(node.left), get_height(node.right))
    
    # 3. Kiểm tra balance
    balance = get_balance(node)
    
    # 4. Rotate nếu mất cân bằng
    # Left Left Case
    if balance > 1 and val < node.left.val:
        return right_rotate(node)
    
    # Right Right Case
    if balance < -1 and val > node.right.val:
        return left_rotate(node)
    
    # Left Right Case
    if balance > 1 and val > node.left.val:
        node.left = left_rotate(node.left)
        return right_rotate(node)
    
    # Right Left Case
    if balance < -1 and val < node.right.val:
        node.right = right_rotate(node.right)
        return left_rotate(node)
    
    return node
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 273 / 2000 |
| **Chapter** | Advanced Trees |
| **XP** | 2730 |