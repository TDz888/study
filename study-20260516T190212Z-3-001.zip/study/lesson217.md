# Bài 217 — LeetCode: Ransom Note (Easy)

## 1. Ôn tập

Bài 216 dùng Two Pointers cho move zeroes. Hôm nay ta học **Character counting** - dùng dictionary để so sánh!

## 2. Mục tiêu bài học

- Kiểm tra có thể tạo ransom note từ magazine
- Dùng Counter (dict) để đếm
- So sánh counts

## 3. Code chính (có comment)

```python
from collections import Counter

def can_construct(ransom_note: str, magazine: str) -> bool:
    """
    Kiểm tra có thể tạo ransom từ magazine
    Input: ransomNote="aab", magazine="baa"
    Output: True
    """
    # Đếm characters trong magazine
    magazine_counts = Counter(magazine)
    
    # Check từng character trong ransom
    for char in ransom_note:
        if magazine_counts[char] <= 0:
            return False
        magazine_counts[char] -= 1
    
    return True

# Test
print(can_construct("aab", "baa"))   # True
print(can_construct("aa", "aab"))    # False
```

## 4. Ghi nhớ nhanh

```python
# Counter là dict đặc biệt cho counting
Counter("hello")  # {'h':1, 'e':1, 'l':2, 'o':1}
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 217 / 2000 |
| **XP** | 2170 |