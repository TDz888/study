# Bài 226 — Word Ladder (Medium)

## 1. Ôn tập

Từ bài 225, ta đã học clone graph. Hôm nay ta học **Word Ladder** - biến đổi từ!

## 2. Mục tiêu bài học

- Tìm shortest transformation sequence
- BFS tìm đường ngắn nhất
- Biến đổi từng ký tự một

## 3. Code chính (có comment)

```python
def ladder_length(begin_word: str, end_word: str, word_list: List[str]) -> int:
    """
    Tìm độ dài shortest transformation
    Input: begin="hit", end="cog", list=["hot","dot","dog","lot","log","cog"]
    Output: 5
    """
    word_set = set(word_list)
    if end_word not in word_set:
        return 0
    
    queue = [(begin_word, 1)]
    visited = set([begin_word])
    
    while queue:
        word, length = queue.pop(0)
        
        if word == end_word:
            return length
        
        # Thử thay đổi từng ký tự
        for i in range(len(word)):
            for c in 'abcdefghijklmnopqrstuvwxyz':
                new_word = word[:i] + c + word[i+1:]
                if new_word in word_set and new_word not in visited:
                    visited.add(new_word)
                    queue.append((new_word, length + 1))
    
    return 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 226 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2260 |