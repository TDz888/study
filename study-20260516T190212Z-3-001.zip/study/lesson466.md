# Bài 466 — Find the Distance Value (Easy)

## 1. Ôn tập

Từ bài 465, ta đã học Remove Element. Hôm nay ta học **Find the Distance Value**!

## 2. Mục tiêu bài học

- Count elements cách xa hơn d từ tất cả elements trong arr2
- Sort approach hoặc brute force
- O(n*m)

## 3. Code chính (có comment)

```python
def find_the_distance_value(arr1, arr2, d):
    """
    Distance Value
    Input: arr1=[4,1,0,2], arr2=[1,9,2,10], d=2
    Output: 2 (0 cách 1,9,2,10 >=2)
    """
    count = 0
    
    for a in arr1:
        valid = True
        for b in arr2:
            if abs(a - b) <= d:
                valid = False
                break
        if valid:
            count += 1
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 466 / 2000 |
| **Chapter** | Array |
| **XP** | 4660 |