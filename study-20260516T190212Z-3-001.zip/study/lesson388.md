# Bài 388 — Encode and Decode TinyURL (Medium)

## 1. Ôn tập

Từ bài 387, ta đã học First Unique Character. Hôm nay ta học **Encode and Decode TinyURL**!

## 2. Mục tiêu bài học

- Encode long URL → short URL
- Decode short URL → long URL
- Hash-based approach

## 3. Code chính (có comment)

```python
import random
import string

class Codec:
    def __init__(self):
        self.url_map = {}
        self.alphabet = string.ascii_letters + string.digits
    
    def encode(self, longUrl):
        """Encode long URL to short URL"""
        code = ''.join(random.choices(self.alphabet, k=6))
        self.url_map[code] = longUrl
        return "http://tinyurl.com/" + code
    
    def decode(self, shortUrl):
        """Decode short URL to long URL"""
        code = shortUrl.split('/')[-1]
        return self.url_map.get(code, "")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 388 / 2000 |
| **Chapter** | Design |
| **XP** | 3880 |