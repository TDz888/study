# Bài 281 — Redundant Connection (Medium)

## 1. Ôn tập

Từ bài 280, ta đã học Number of Connected Components. Hôm nay ta học **tìm cạnh gây cycle** trong tree!

## 2. Mục tiêu bài học

- Tìm cạnh thừa gây cycle trong undirected graph
- Dùng Union-Find để detect cycle
- Đảm bảo graph cuối là cây (n nodes, n-1 edges)

## 3. Code chính (có comment)

```python
def find_redundant_connection(edges):
    """
    Tìm cạnh gây cycle
    Input: [[1,2],[1,3],[2,3]]
    Output: [2,3] (cạnh thừa)
    """
    parent = list(range(1001))
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        px, py = find(x), find(y)
        if px == py:
            return False  # Cycle detected
        parent[px] = py
        return True
    
    for a, b in edges:
        if not union(a, b):
            return [a, b]
    
    return []
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 281 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2810 |