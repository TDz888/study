# Bài 74 — Functional Programming

---

## 1. Ôn tập
Học về **Functional Programming** trong Python.

---

## 2. Mục tiêu
- First-class functions
- Higher-order functions
- Partial functions
- Currying

---

## 3. Higher-Order Functions

```python
# Function như tham số
def apply(func, value):
    return func(value)

def double(x):
    return x * 2

print(apply(double, 5))  # 10

# Function trả về function
def make_multiplier(n):
    def multiplier(x):
        return x * n
    return multiplier

times3 = make_multiplier(3)
print(times3(5))  # 15
```

---

## 4. Partial Functions

```python
from functools import partial

def power(base, exponent):
    return base ** exponent

# Tạo hàm mới với exponent cố định
square = partial(power, exponent=2)
cube = partial(power, exponent=3)

print(square(5))  # 25
print(cube(5))    # 125
```

---

## 5. Currying

```python
# Currying - chia hàm thành chuỗi
def curried_power(exponent):
    def power(base):
        return base ** exponent
    return power

cube = curried_power(3)
print(cube(5))  # 125
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 74 / 2000 |
| **XP** | 740 |
| **Level** | Advanced |