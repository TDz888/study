# Bài 183 — Performance Optimization

## 1. Ôn tập

Code chạy đúng rồi, làm sao cho nhanh hơn?

## 2. Mục tiêu bài học

- Profile code
- Tối ưu bottlenecks
- Memory optimization

## 3. Code chính (có comment)

```python
import time

# 1. Time measurement
def timeit(func):
    start = time.perf_counter()
    result = func()
    end = time.perf_counter()
    print(f"Time: {end - start:.4f}s")
    return result

# 2. Profiling
# python -m cProfile -s cumtime script.py

# 3. Memory profiling
# pip install memory_profiler
# @profile decorator

# 4. Common optimizations:
# - List → Generator khi không cần list
# - Use built-in (map, filter, sum)
# - Avoid global variables in loops
# - Cache repeated calculations

# Example: List vs Generator
def sum_of_squares_list(n):
    return sum([x**2 for x in range(n)])

def sum_of_squares_gen(n):
    return sum(x**2 for x in range(n))

# Generator nhanh hơn cho n lớn!
```

## 4. Tips

| Kỹ thuật | Ứng dụng |
|---------|---------|
| Generator | Thay list khi không cần |
| Built-in | sum, min, max nhanh hơn loop |
| List comprehension | Nhanh hơn append |
| Local variables | Nhanh hơn global |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 183 / 2000 |
| **XP** | 1830 |