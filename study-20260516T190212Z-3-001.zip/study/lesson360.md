# Bài 360 — Isomorphic Strings (Easy)

## 1. Ôn tập

Từ bài 359, ta đã học Ransom Note. Hôm nay ta học **Isomorphic Strings**!

## 2. Mục tiêu bài học

- Kiểm tra pattern preservation
- Map s→t và check t→s
- Two-way mapping

## 3. Code chính (có comment)

```python
def is_isomorphic(s, t):
    """
    Isomorphic Strings
    Input: s="egg", t="add"
    Output: True
    """
    if len(s) != len(t):
        return False
    
    s_to_t = {}
    t_to_s = {}
    
    for c1, c2 in zip(s, t):
        if c1 in s_to_t and s_to_t[c1] != c2:
            return False
        if c2 in t_to_s and t_to_s[c2] != c1:
            return False
        s_to_t[c1] = c2
        t_to_s[c2] = c1
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 360 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3600 |