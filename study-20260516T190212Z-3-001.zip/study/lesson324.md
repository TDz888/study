# Bài 324 — Largest Rectangle in Histogram (Hard)

## 1. Ôn tập

Từ bài 323, ta đã học Trapping Rain Water. Hôm nay ta học **Largest Rectangle in Histogram**!

## 2. Mục tiêu bài học

- Tìm largest rectangle trong histogram
- Dùng stack để track indices
- O(n) time

## 3. Code chính (có comment)

```python
def largest_rectangle(heights):
    """
    Largest Rectangle
    Input: [2,1,5,6,2,3]
    Output: 10 (5*2)
    """
    stack = []
    max_area = 0
    
    for i in range(len(heights)):
        # Extend rectangle
        while stack and heights[stack[-1]] > heights[i]:
            h = heights[stack.pop()]
            width = i if not stack else i - stack[-1] - 1
            max_area = max(max_area, h * width)
        stack.append(i)
    
    # Process remaining
    while stack:
        h = heights[stack.pop()]
        width = len(heights) if not stack else len(heights) - stack[-1] - 1
        max_area = max(max_area, h * width)
    
    return max_area
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 324 / 2000 |
| **Chapter** | Stack |
| **XP** | 3240 |