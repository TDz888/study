# Bài 133 — operator module

---

## 1. operator module

```python
import operator

# Arithmetic
print(operator.add(1, 2))        # 3
print(operator.sub(5, 3))       # 2
print(operator.mul(4, 5))       # 20
print(operator.truediv(10, 2)) # 5.0
print(operator.pow(2, 3))       # 8

# Comparison
print(operator.eq(1, 1))        # True
print(operator.ne(1, 2))        # True
print(operator.lt(1, 2))       # True

# Item access
print(operator.getitem([1,2,3], 1))  # 2
print(operator.setitem([1,2,3], 0, 99))  # [99, 2, 3]

# Attr access
class MyClass:
    x = 10
obj = MyClass()
print(operator.attrgetter('x')(obj))  # 10
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 133 / 2000 |
| **XP** | 1330 |
| **Level** | Intermediate |