# Bài 216 — LeetCode: Move Zeroes (Easy)

## 1. Ôn tập

Từ bài 201-215, ta đã học nhiều kỹ thuật LeetCode. Hôm nay ta học **Two Pointers biến thể** - move zeroes!

## 2. Mục tiêu bài học

- Di chuyển tất cả 0 về cuối
- Giữ thứ tự các phần tử khác
- In-place (không tạo mảng mới)

## 3. Code chính (có comment)

```python
def move_zeroes(nums: List[int]) -> None:
    """
    Di chuyển tất cả 0 về cuối mảng
    Input: [0,1,0,3,12]
    Output: [1,3,12,0,0]
    """
    # slow pointer: vị trí cuối cùng của non-zero
    slow = 0
    
    # Fast pointer: duyệt qua mảng
    for fast in range(len(nums)):
        # Nếu gặp non-zero → đưa về vị trí slow
        if nums[fast] != 0:
            nums[slow] = nums[fast]
            slow += 1
    
    # Fill remaining với 0
    while slow < len(nums):
        nums[slow] = 0
        slow += 1

# Test
nums = [0, 1, 0, 3, 12]
move_zeroes(nums)
print(nums)  # [1, 3, 12, 0, 0]
```

## 4. Trace chạy code

```
nums = [0,1,0,3,12]

fast=0: nums[0]=0 → skip
fast=1: nums[1]=1 → nums[0]=1, slow=1
fast=2: nums[2]=0 → skip  
fast=3: nums[3]=3 → nums[1]=3, slow=2
fast=4: nums[4]=12 → nums[2]=12, slow=3

Fill: slow=3→4→5: nums[3]=0, nums[4]=0

Result: [1,3,12,0,0]
```

## 5. Ghi nhớ nhanh

| Method | Time | Space |
|--------|------|-------|
| Two Pointers | O(n) | O(1) |
| Create new array | O(n) | O(n) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 216 / 2000 |
| **XP** | 2160 |