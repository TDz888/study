# Bài 467 — Height Checker (Easy)

## 1. Ôn tập

Từ bài 466, ta đã học Distance Value. Hôm nay ta học **Height Checker**!

## 2. Mục tiêu bài học

- Đếm students cần di chuyển để sorted
- Sort và compare
- O(n log n)

## 3. Code chính (có comment)

```python
def height_checker(heights):
    """
    Height Checker
    Input: [1,1,4,2,1,3]
    Output: 3 (cần move 3 students)
    """
    sorted_heights = sorted(heights)
    count = 0
    
    for i in range(len(heights)):
        if heights[i] != sorted_heights[i]:
            count += 1
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 467 / 2000 |
| **Chapter** | Array |
| **XP** | 4670 |