# Bài 255 — BST Delete (Medium)

## 1. Ôn tập

Từ bài 254, ta đã học chèn node vào BST. Hôm nay ta học **xóa node** khỏi BST!

## 2. Mục tiêu bài học

- Xóa node trong BST giữ nguyên BST property
- 3 trường hợp: node lá, node có 1 con, node có 2 con
- Tìm successor/predecessor khi xóa node có 2 con

## 3. Code chính (có comment)

```python
def delete_bst(root: TreeNode, val: int) -> TreeNode:
    """
    Xóa node có giá trị val khỏi BST
    Input: root = [5,3,6,2,4,None,7], val = 3
    Output: root sau khi xóa
    """
    if not root:
        return None
    
    # Tìm node cần xóa
    if val < root.val:
        root.left = delete_bst(root.left, val)
    elif val > root.val:
        root.right = delete_bst(root.right, val)
    else:
        # Đã tìm được node cần xóa
        
        # Case 1: Node là lá (không có con)
        if not root.left and not root.right:
            return None
        
        # Case 2: Chỉ có 1 con
        if not root.left:
            return root.right
        if not root.right:
            return root.left
        
        # Case 3: Có 2 con
        # Tìm successor (node nhỏ nhất bên phải)
        successor = find_min(root.right)
        root.val = successor.val
        # Xóa successor
        root.right = delete_bst(root.right, successor.val)
    
    return root

def find_min(node):
    """Tìm node nhỏ nhất (go to leftmost)"""
    while node.left:
        node = node.left
    return node
```

## 4. Giải thích 3 trường hợp

| Case | Mô tả | Xử lý |
|------|-------|-------|
| **Node lá** | Không có con | Xóa trực tiếp, return None |
| **1 con** | Có left HOẶC right | Thay node bằng con |
| **2 con** | Có cả left và right | Tìm successor, copy giá trị, xóa successor |

## 5. Ví dụ minh họa

```
Xóa node 3:
       5
      / \
     3   6        ← Node 3 có 2 con
    / \   \
   2   4   7

Tìm successor (node nhỏ nhất bên phải của 3) = 4
Copy 4 vào vị trí 3, xóa node 4

Kết quả:
       5
      / \
     4   6
    /     \
   2       7
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 255 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2550 |