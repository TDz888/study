# Bài 327 — 3Sum Closest (Medium)

## 1. Ôn tập

Từ bài 326, ta đã học Container With Most Water. Hôm nay ta học **3Sum Closest**!

## 2. Mục tiêu bài học

- Tìm 3 số có sum gần target nhất
- Sort + two pointers
- O(n²)

## 3. Code chính (có comment)

def three_sum_closest(nums, target):
    """
    3Sum Closest
    Input: [-1,2,1,-4], target=1
    Output: 2 (-1+1+2)
    """
    nums.sort()
    closest = float('inf')
    
    for i in range(len(nums) - 2):
        left, right = i + 1, len(nums) - 1
        
        while left < right:
            current = nums[i] + nums[left] + nums[right]
            
            if current == target:
                return current
            
            if abs(current - target) < abs(closest - target):
                closest = current
            
            if current < target:
                left += 1
            else:
                right -= 1
    
    return closest
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 327 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3270 |