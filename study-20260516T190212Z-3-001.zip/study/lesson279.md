# Bài 279 — Course Schedule (Medium)

## 1. Ôn tập

Từ bài 278, ta đã học Clone Graph. Hôm nay ta học **kiểm tra dependency** - topological sort!

## 2. Mục tiêu bài học

- N course, có prerequisite pairs
- Kiểm tra có thể hoàn thành tất cả không
- Dùng Topological Sort (detect cycle)

## 3. Code chính (có comment)

```python
def can_finish(num_courses, prerequisites):
    """
    Kiểm tra có thể hoàn thành tất cả courses không
    Input: num_courses = 2, prerequisites = [[1,0]]
    Output: True (phải học 0 trước 1)
    """
    # Build graph và in-degree
    graph = {i: [] for i in range(num_courses)}
    in_degree = [0] * num_courses
    
    for course, prereq in prerequisites:
        graph[prereq].append(course)
        in_degree[course] += 1
    
    # BFS: start với in_degree = 0
    queue = [i for i in range(num_courses) if in_degree[i] == 0]
    count = 0
    
    while queue:
        node = queue.pop(0)
        count += 1
        
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    return count == num_courses
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 279 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2790 |