# Bài 98 — Multiprocessing

---

## 1. Multiprocessing Basics

```python
import multiprocessing
import time

def worker(num):
    print(f'Starting worker {num}')
    time.sleep(2)
    print(f'Ending worker {num}')

if __name__ == '__main__':
    processes = []
    for i in range(4):
        p = multiprocessing.Process(target=worker, args=(i,))
        processes.append(p)
        p.start()
    
    for p in processes:
        p.join()
    
    print('All done')
```

---

## 2. Pool

```python
from multiprocessing import Pool

def square(x):
    return x * x

if __name__ == '__main__':
    with Pool(4) as pool:
        results = pool.map(square, [1, 2, 3, 4, 5])
        print(results)  # [1, 4, 9, 16, 25]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 98 / 2000 |
| **XP** | 980 |
| **Level** | Advanced |