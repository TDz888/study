# Bài 404 — Binary Tree Level Order Traversal (Medium)

## 1. Ôn tập

Từ bài 403, ta đã học Min Stack. Hôm nay ta học **Level Order Traversal**!

## 2. Mục tiêu bài học

- Traverse tree theo levels
- BFS với queue
- Return list of lists

## 3. Code chính (có comment)

```python
from collections import deque

def level_order(root):
    """
    Level Order Traversal
    Input: Tree
    Output: [[level1], [level2], ...]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 404 / 2000 |
| **Chapter** | Trees |
| **XP** | 4040 |