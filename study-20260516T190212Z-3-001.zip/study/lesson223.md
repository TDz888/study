# Bài 223 — Number of Islands (Medium)

## 1. Ôn tập

Từ bài 222, ta đã học Flood Fill. Hôm nay ta học **Number of Islands** - đếm số đảo trong grid!

## 2. Mục tiêu bài học

- Đếm số connected components = "islands"
- Dùng DFS/BFS để explore
- Mark visited để tránh đếm lại

## 3. Code chính (có comment)

```python
def num_islands(grid: List[List[str]]) -> int:
    """
    Đếm số islands trong grid
    Input: grid = [
        ["1","1","1","1","0"],
        ["1","1","0","1","0"],
        ["1","1","0","0","0"],
        ["0","0","0","0","0"]
    ]
    Output: 1
    """
    if not grid:
        return 0
    
    rows, cols = len(grid), len(grid[0])
    count = 0
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return
        if grid[r][c] != "1":
            return
        
        # Mark visited
        grid[r][c] = "0"
        
        # Explore 4 directions
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == "1":
                dfs(r, c)
                count += 1
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 223 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2230 |