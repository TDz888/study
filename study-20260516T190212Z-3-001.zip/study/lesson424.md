# Bài 424 — Linked List Cycle (Easy)

## 1. Ôn tập

Từ bài 423, ta đã học Sorted List to BST. Hôm nay ta học **Linked List Cycle**!

## 2. Mục tiêu bài học

- Detect cycle trong linked list
- Floyd's Tortoise and Hare
- O(n)

## 3. Code chính (có comment)

```python
def has_cycle(head):
    """
    Linked List Cycle
    Input: linked list
    Output: True nếu có cycle
    """
    if not head or not head.next:
        return False
    
    slow = head
    fast = head
    
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        
        if slow == fast:
            return True
    
    return False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 424 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4240 |