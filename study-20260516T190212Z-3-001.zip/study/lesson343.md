# Bài 343 — Longest Increasing Subsequence (Medium)

## 1. Ôn tập

Từ bài 342, ta đã học Median. Hôm nay ta học **Longest Increasing Subsequence**!

## 2. Mục tiêu bài học

- Tìm LIS trong unsorted array
- DP hoặc Binary Search
- O(n log n)

## 3. Code chính (có comment)

```python
def length_of_lis(nums):
    """
    LIS - Binary Search
    Input: [10,9,2,5,3,7,101,18]
    Output: 4
    """
    import bisect
    
    sub = []
    for num in nums:
        pos = bisect.bisect_left(sub, num)
        if pos == len(sub):
            sub.append(num)
        else:
            sub[pos] = num
    
    return len(sub)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 343 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3430 |