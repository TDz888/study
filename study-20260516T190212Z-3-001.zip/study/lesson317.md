# Bài 317 — Remove Duplicates from Sorted Array II (Medium)

## 1. Ôn tập

Từ bài 316, ta đã học Reverse Linked List II. Hôm nay ta học **Remove Duplicates II**!

## 2. Mục tiêu bài học

- Remove duplicates, cho phép tối đa 2 duplicates
- In-place modification
- Two pointers

## 3. Code chính (có comment)

```python
def remove_duplicates(nums):
    """
    Remove Duplicates II
    Input: [1,1,1,2,2,3]
    Output: 5 ([1,1,2,2,3])
    """
    if len(nums) <= 2:
        return len(nums)
    
    count = 1  # Đếm duplicates
    
    for i in range(1, len(nums)):
        if nums[i] == nums[i-1]:
            count += 1
            if count > 2:
                # Mark để xóa
                nums[i] = None
        else:
            count = 1
    
    # Remove Nones
    index = 0
    for num in nums:
        if num is not None:
            nums[index] = num
            index += 1
    
    return index
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 317 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3170 |