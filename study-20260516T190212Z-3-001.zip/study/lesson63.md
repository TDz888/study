# Bài 63 — Regular Expressions (P2)

---

## 1. Ôn tập
Học regex nâng cao.

---

## 2. Mục tiêu
- Character classes
- Quantifiers
- Groups và alternation
- Lookahead/lookbehind

---

## 3. Character Classes

```python
# [abc] - any of a, b, or c
re.search(r"[aeiou]", "hello")  # 'e'

# [a-z] - range
re.search(r"[a-z]+", "Hello123")  # 'ello'

# [^abc] - not a, b, c
re.search(r"[^0-9]", "123abc")  # 'a'
```

---

## 4. Quantifiers

```python
# * - 0 or more
re.search(r"ab*c", "ac")  # 'ac'
re.search(r"ab*c", "abbbc")  # 'abbbc'

# + - 1 or more
re.search(r"ab+c", "abbbc")  # 'abbbc'

# ? - 0 or 1
re.search(r"colou?r", "color")  # 'color'
re.search(r"colou?r", "colour")  # 'colour'

# {n} - exactly n
re.search(r"\d{4}", "123456")  # '1234'

# {n,} - n or more
re.search(r"\d{2,}", "123456")  # '123456'
```

---

## 5. Groups

```python
# Capture groups
match = re.search(r"(\d{3})-(\d{4})", "123-4567")
print(match.group(1))  # 123
print(match.group(2))  # 4567
print(match.groups())  # ('123', '4567')

# Named groups
match = re.search(r"(?P<area>\d{3})-(?P<num>\d{4})", "123-4567")
print(match.group("area"))  # 123

# Alternation
re.search(r"cat|dog", "I have a cat")  # 'cat'
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 63 / 2000 |
| **XP** | 630 |
| **Level** | Intermediate |