# Bài 76 — Dynamic Programming (P1)

---

## 1. Ôn tập
Học **Dynamic Programming** — quy hoạch động.

---

## 2. Mục tiêu
- DP cơ bản
- Memoization
- Tabulation

---

## 3. Fibonacci với DP

```python
# Naive - O(2^n)
def fib_naive(n):
    if n <= 1:
        return n
    return fib_naive(n-1) + fib_naive(n-2)

# Memoization - Top-down DP
memo = {}
def fib_memo(n):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fib_memo(n-1) + fib_memo(n-2)
    return memo[n]

# Tabulation - Bottom-up DP
def fib_tab(n):
    if n <= 1:
        return n
    dp = [0] * (n + 1)
    dp[1] = 1
    for i in range(2, n + 1):
        dp[i] = dp[i-1] + dp[i-2]
    return dp[n]

# Space optimized
def fib_optimized(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b
```

---

## 4. Climbing Stairs

```python
def climb(n):
    if n <= 2:
        return n
    a, b = 1, 2
    for i in range(3, n + 1):
        a, b = b, a + b
    return b
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 76 / 2000 |
| **XP** | 760 |
| **Level** | Advanced |