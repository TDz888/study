# Bài 413 — Cousins in Binary Tree (Easy)

## 1. Ôn tập

Từ bài 412, ta đã học Merge Two BSTs. Hôm nay ta học **Cousins in Binary Tree**!

## 2. Mục tiêu bài học

- Kiểm tra 2 nodes có cousins không
- Same depth, different parents
- BFS

## 3. Code chính (có comment)

```python
def is_cousins(root, x, y):
    """
    Cousins in Binary Tree
    Input: root, x, y
    Output: True nếu cousins
    """
    if not root:
        return False
    
    queue = [root]
    parent = {root.val: None}
    
    while queue:
        size = len(queue)
        x_found = y_found = False
        
        for _ in range(size):
            node = queue.pop(0)
            
            if node.val == x:
                x_found = True
            if node.val == y:
                y_found = True
            
            if node.left:
                parent[node.left.val] = node.val
                queue.append(node.left)
            if node.right:
                parent[node.right.val] = node.val
                queue.append(node.right)
        
        if x_found and y_found:
            return parent[x] != parent[y]
        if x_found or y_found:
            return False
    
    return False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 413 / 2000 |
| **Chapter** | Trees |
| **XP** | 4130 |