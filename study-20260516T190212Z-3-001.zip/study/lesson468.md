# Lesson 468 — Relative Sort Array

---

## 1. KNOWLEDGE CONNECTION

Từ bài 467, bạn đã học **Height Checker** - so sánh mảng với mảng đã sắp xếp. Bài hôm nay sẽ mở rộng sang **Relative Sort Array** - sắp xếp một mảng dựa trên thứ tự của mảng khác. Đây là kỹ năng quan trọng trong việc xử lý dữ liệu có thứ tự ưu tiên.

## 2. TODAY'S MISSION

Hôm nay bạn sẽ học:
- Sắp xếp mảng arr1 theo thứ tự của arr2
- Các phần tử không có trong arr2 sẽ được sắp xếp tăng dần ở cuối
- Kỹ thuật: Counting Sort kết hợp với custom order

## 3. CONCEPT FOUNDATION

**Relative Sort Array** là bài toán sắp xếp có điều kiện:
- Elements trong arr2 giữ nguyên thứ tự như trong arr2
- Elements không trong arr2 được sắp xếp tăng dần

Ví dụ:
```
arr1 = [2,3,1,3,2,4,6,7,9,2,19]
arr2 = [2,1,4,3,9,6]
→ Output: [2,2,1,4,3,3,9,6,7,19]
```

## 4. TERMINOLOGY EXPLANATION

- **Counting Sort**: Thuật toán sắp xếp đếm số lần xuất hiện, O(n+k)
- **Custom Order**: Thứ tự được định nghĩa bởi người dùng, không phải tự nhiên
- **Relative**: Liên quan đến, phụ thuộc vào

## 5. MAIN CODE

```python
def relative_sort_array(arr1, arr2):
    """
    Sắp xếp arr1 theo thứ tự trong arr2
    
    Input: arr1=[2,3,1,3,2,4,6,7,9,2,19], arr2=[2,1,4,3,9,6]
    Output: [2,2,1,4,3,3,9,6,7,19]
    
    Giải thích:
    - 2 xuất hiện 2 lần → [2,2]
    - 1 xuất hiện 1 lần → [1]
    - 4 xuất hiện 1 lần → [4]
    - 3 xuất hiện 2 lần → [3,3]
    - 9 xuất hiện 1 lần → [9]
    - 6 xuất hiện 1 lần → [6]
    - Các phần tử còn lại [7,19] sắp xếp tăng dần
    """
    # Bước 1: Đếm số lần xuất hiện trong arr1
    from collections import Counter
    count = Counter(arr1)
    
    # Bước 2: Tạo kết quả theo thứ tự arr2
    result = []
    for num in arr2:
        result.extend([num] * count[num])
        del count[num]  # Xóa để không xử lý lại
    
    # Bước 3: Thêm các phần tử còn lại sắp xếp tăng dần
    for num in sorted(count.keys()):
        result.extend([num] * count[num])
    
    return result
```

## 6. EXECUTION TRACE

```python
# Test với ví dụ
arr1 = [2,3,1,3,2,4,6,7,9,2,19]
arr2 = [2,1,4,3,9,6]

# Bước 1: Đếm
# count = {2: 3, 3: 2, 1: 1, 4: 1, 6: 1, 7: 1, 9: 1, 19: 1}

# Bước 2: Theo thứ tự arr2
# num=2: result = [2,2,2], count[2] = 0
# num=1: result = [2,2,2,1], count[1] = 0  
# num=4: result = [2,2,2,1,4], count[4] = 0
# num=3: result = [2,2,2,1,4,3,3], count[3] = 0
# num=9: result = [2,2,2,1,4,3,3,9], count[9] = 0
# num=6: result = [2,2,2,1,4,3,3,9,6], count[6] = 0
# count còn: {7:1, 19:1}

# Bước 3: Thêm phần tử còn lại
# sorted([7,19]) = [7,19]
# result = [2,2,2,1,4,3,3,9,6,7,19]

# Output: [2,2,2,1,4,3,3,9,6,7,19]
```

## 7. VISUAL THINKING MODE

```
arr1 = [2,3,1,3,2,4,6,7,9,2,19]
        ↓ Đếm
count = {2:3, 3:2, 1:1, 4:1, 6:1, 7:1, 9:1, 19:1}

arr2 = [2,1,4,3,9,6]  ← Thứ tự ưu tiên

         ┌─────────────────────────────────────┐
         │ 2×3 = [2,2,2]                      │
         │ 1×1 = [1]                          │
         │ 4×1 = [4]                          │
         │ 3×2 = [3,3]                        │
         │ 9×1 = [9]                          │
         │ 6×1 = [6]                          │
         └─────────────────────────────────────┘
         
         Phần còn lại: [7,19] → sorted = [7,19]
         
Output: [2,2,2,1,4,3,3,9,6,7,19]
```

## 8. DEBUG THINKING MODE

**Common Mistakes:**
1. **Quên xóa count sau khi xử lý** → Có thể xử lý lại phần tử
2. **Không sắp xếp phần còn lại** → Output không đúng thứ tự
3. **Sai logic extend** → Dùng append thay vì extend

**Cách sửa:**
```python
# ❌ Sai: result.append([num] * count[num])
# ✅ Đúng: result.extend([num] * count[num])

# ❌ Quên xóa: 
# ✅ Đúng: del count[num]
```

## 9. MEMORY REINFORCEMENT

**Key Points:**
- Counter để đếm tần suất
- Theo thứ tự arr2 để lấy phần tử ưu tiên
- Phần còn lại sorted() rồi thêm vào
- Time: O(n + k log k), Space: O(k)

**Pattern:**
```python
count = Counter(arr1)
result = []
for num in arr2:
    result.extend([num] * count[num])
    del count[num]
result.extend([num] * count[num] for num in sorted(count))
```

## 10. MINI TEST

1. **Câu hỏi**: Nếu arr1 = [1,2,3,2,1] và arr2 = [2,1], output là gì?
2. **Câu hỏi**: Phần tử nào sẽ được đưa lên đầu kết quả?
3. **Câu hỏi**: Tại sao cần del count[num] sau khi xử lý?

## 11. LEETCODE PRACTICE

**Problem:** Relative Sort Array (LeetCode 1122)
- Easy level
- Sử dụng counting approach

**Starter Code:**
```python
def relativeSortArray(arr1, arr2):
    # Your code here
    pass
```

**Hints:**
1. Dùng Counter hoặc dictionary để đếm
2. Lặp qua arr2 trước
3. Sau đó xử lý phần còn lại

## 12. BONUS CHALLENGE

Nếu bạn muốn thử thách thêm:
- Tự implement không dùng Counter
- Giải quyết trong O(n) không dùng sorted()
- Xử lý trường hợp arr2 có phần tử trùng lặp

## 13. LESSON REFLECTION

Hôm nay bạn đã học được:
- Cách sắp xếp theo thứ tự tùy chỉnh
- Kỹ thuật Counting Sort trong thực tế
- Cách xử lý phần tử ưu tiên và phần còn lại

**Strengths:**
- Hiểu được logic đếm và sắp xếp
- Biết cách xử lý hai loại phần tử

**Areas to Improve:**
- Thực hành nhiều hơn với các biến thể

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 468 / 2000 |
| **Chapter** | Array |
| **XP** | +25 |
| **Mastery** | Sorting |
| **Next** | Next Permutation |