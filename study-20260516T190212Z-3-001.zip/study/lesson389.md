# Bài 389 — Missing Number (Easy)

## 1. Ôn tập

Từ bài 388, ta đã học Encode/Decode. Hôm nay ta học **Missing Number**!

## 2. Mục tiêu bài học

- Tìm số missing trong 0→n
- XOR approach
- O(n), O(1) space

## 3. Code chính (có comment)

```python
def missing_number(nums):
    """
    Missing Number
    Input: [3,0,1]
    Output: 2
    """
    missing = len(nums)
    
    for i, num in enumerate(nums):
        missing ^= i ^ num
    
    return missing
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 389 / 2000 |
| **Chapter** | Array |
| **XP** | 3890 |