# Bài 167 — Async Generator

## 1. Ôn tập

Ta đã quen với:
- Generator thông thường: `yield`
- Async function: `async def`
- Async context manager: `__aenter__`, `__aexit__`

Điều gì xảy ra khi kết hợp cả hai?

## 2. Mục tiêu bài học

- Hiểu async generator: `async def` + `yield`
- Dùng `async for` để lặp
- Xử lý stream dữ liệu hiệu quả

## 3. Code chính (có comment)

```python
import asyncio

async def async_number_generator(n):
    """Async generator - yield giá trị theo thời gian"""
    for i in range(n):
        await asyncio.sleep(0.5)  # Giả lập lấy dữ liệu từ API
        yield i  # Yield nhưng không block event loop!

async def async_data_stream():
    """Stream dữ liệu từ nhiều nguồn"""
    sources = [
        async_number_generator(3),
        async_number_generator(3),
    ]
    
    # Merge nhiều streams
    async for item in asyncio.gather(*sources):
        yield item

async def main():
    # Cách 1: Dùng async for trực tiếp
    print("=== Async for direct ===")
    async for num in async_number_generator(5):
        print(f"Got: {num}")
    
    print("\n=== List comprehension with async ===")
    # Cách 2: Thu thập tất cả
    numbers = [x async for x in async_number_generator(3)]
    print(numbers)
    
    print("\n=== Async generator với enumerate ===")
    async for i, num in enumerate(async_number_generator(3)):
        print(f"Index {i}: {num}")

asyncio.run(main())
```

## 4. Trace chạy code

```
=== Async for direct ===
Got: 0
Got: 1
Got: 2
Got: 3
Got: 4

=== List comprehension with async ===
[0, 1, 2]

=== Async generator với enumerate ===
Index 0: 0
Index 1: 1
Index 2: 2
```

## 5. Debug tư duy

### Sai lầm thường gặp
**Sai:** Dùng for thường với async generator

```python
# Không hoạt động!
for num in async_gen():
    print(num)
```

**Đúng:** Dùng async for

```python
# Chính xác
async for num in async_gen():
    print(num)
```

### Async comprehension
```python
# Async list comprehension
result = [x async for x in async_gen()]

# Async dict comprehension  
result = {k: v async for k, v in async_dict_gen()}
```

## 6. Ghi nhớ nhanh

| Cú pháp | Công dụng |
|---------|-----------|
| `async def gen(): yield x` | Tạo async generator |
| `async for x in gen()` | Lặp qua async generator |
| `[x async for x in gen()]` | Async list comprehension |
| `async_generator.send()` | Gửi giá trị vào generator |

## 7. Mini test (3 câu)

**Câu 1:** Async generator kết hợp những gì?
- A) async def + yield
- B) def + yield
- C) async def + return
- D) def + return

**Câu 2:** Cách lặp qua async generator?
- A) for
- B) while
- C) async for
- D) each

**Câu 3:** `[x async for x in gen()]` là gì?
- A) Async function
- B) Async list comprehension
- C) Generator expression
- D) Lambda

**Đáp án:** 1-A, 2-C, 3-B

## 8. LeetCode practice

**Bài:** "Real-time Data Processor"

```python
async def fetch_prices(symbols):
    """Lấy giá liên tục từ API"""
    for symbol in symbols:
        price = await get_price(symbol)  # API call
        yield {'symbol': symbol, 'price': price}
        await asyncio.sleep(1)

async def process_prices(symbols):
    # Xử lý real-time price stream
    async for data in fetch_prices(symbols):
        # Làm gì đó với data
        pass
```

## 9. Bonus

Tạo:
- Async generator đọc file theo chunk
- Merge nhiều async generators
- Làm backpressure handling

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 167 / 2000 |
| **XP** | 1670 |