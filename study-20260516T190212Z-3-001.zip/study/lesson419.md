# Bài 419 — Convert BST to Greater Tree (Medium)

## 1. Ôn tập

Từ bài 418, ta đã học Range Sum of BST. Hôm nay ta học **Convert BST to Greater Tree**!

## 2. Mục tiêu bài học

- Mỗi node = sum của itself + tất cả greater values
- Reverse inorder: right → root → left
- Accumulate sum

## 3. Code chính (có comment)

```python
def convert_bst(root):
    """
    Convert BST to Greater Tree
    Input: [4,1,6,0,2,5,7]
    Output: [30,36,21,30,26,28,23]
    """
    total = 0
    
    def reverse_inorder(node):
        nonlocal total
        if not node:
            return
        
        reverse_inorder(node.right)
        
        total += node.val
        node.val = total
        
        reverse_inorder(node.left)
    
    reverse_inorder(root)
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 419 / 2000 |
| **Chapter** | Trees |
| **XP** | 4190 |