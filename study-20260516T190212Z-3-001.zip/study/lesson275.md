# Bài 275 — Graph BFS (Breadth First Search)

## 1. Ôn tập

Từ bài 274, ta đã học Graph cơ bản. Hôm nay ta học **BFS** - tìm kiếm theo chiều rộng!

## 2. Mục tiêu bài học

- Duyệt graph theo từng tầng
- Dùng Queue để lưu nodes
- Tìm đường đi ngắn nhất trong unweighted graph

## 3. Code chính (có comment)

```python
from collections import deque

def bfs(graph, start):
    """
    BFS từ start node
    Input: graph = {'A': ['B', 'C'], 'B': ['A', 'D'], ...}, start = 'A'
    Output: ['A', 'B', 'C', 'D']
    """
    visited = set()
    queue = deque([start])
    result = []
    
    visited.add(start)
    
    while queue:
        node = queue.popleft()
        result.append(node)
        
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    
    return result
```

## 4. Quy trình

```
Start: A
Queue: [A]

Level 1: A → B, C
Level 2: B → D, C → D (D đã visit)
Result: A, B, C, D
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 275 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2750 |