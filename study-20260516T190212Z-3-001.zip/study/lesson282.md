# Bài 282 — Keys and Rooms (Medium)

## 1. Ôn tập

Từ bài 281, ta đã học Redundant Connection. Hôm nay ta học **kiểm tra có thể visit tất cả rooms** không!

## 2. Mục tiêu bài học

- Có n phòng, mỗi phòng có keys đến phòng khác
- Kiểm tra có thể visit tất cả phòng không
- Dùng DFS/BFS từ room 0

## 3. Code chính (có comment)

```python
def can_visit_all_rooms(rooms):
    """
    Kiểm tra visit tất cả phòng
    Input: [[1],[2],[3],[]]
    Output: True (0→1→2→3)
    """
    visited = set()
    stack = [0]  # Start from room 0
    
    while stack:
        room = stack.pop()
        if room in visited:
            continue
        visited.add(room)
        
        # Thêm các phòng có thể visit
        for key in rooms[room]:
            if key not in visited:
                stack.append(key)
    
    return len(visited) == len(rooms)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 282 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2820 |