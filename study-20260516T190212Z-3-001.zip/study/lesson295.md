# Bài 295 — Convert Sorted Array to BST (Easy)

## 1. Ôn tập

Từ bài 294, ta đã học Maximum Depth. Hôm nay ta học **build balanced BST** từ sorted array!

## 2. Mục tiêu bài học

- Convert sorted array → balanced BST
- Chọn mid là root để đảm bảo balanced
- Recursive build left/right

## 3. Code chính (có comment)

```python
def sorted_array_to_bst(nums):
    """
    Array → Balanced BST
    Input: Sorted array
    Output: Balanced BST
    """
    if not nums:
        return None
    
    # Chọn mid làm root
    mid = len(nums) // 2
    root = TreeNode(nums[mid])
    
    # Build left và right từ subarrays
    root.left = sorted_array_to_bst(nums[:mid])
    root.right = sorted_array_to_bst(nums[mid+1:])
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 295 / 2000 |
| **Chapter** | Trees |
| **XP** | 2950 |