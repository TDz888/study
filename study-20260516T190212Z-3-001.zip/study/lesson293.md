# Bài 293 — Binary Tree Right Side View (Medium)

## 1. Ôn tập

Từ bài 292, ta đã học Lowest Common Ancestor. Hôm nay ta học **nhìn từ phải** của binary tree!

## 2. Mục tiêu bài học

- Lấy nodes nhìn từ phía phải (rightmost of each level)
- Dùng BFS hoặc DFS
- Level order traversal

## 3. Code chính (có comment)

```python
def right_side_view(root):
    """
    Right side view
    Input: Tree
    Output: List of rightmost nodes mỗi level
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        
        for i in range(level_size):
            node = queue.popleft()
            
            # Lấy node cuối của level
            if i == level_size - 1:
                result.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 293 / 2000 |
| **Chapter** | Trees |
| **XP** | 2930 |