# Bài 310 — Combination Sum IV (Medium)

## 1. Ôn tập

Từ bài 309, ta đã học Best Time to Buy and Sell Stock. Hôm nay ta học **Combination Sum IV**!

## 2. Mục tiêu bài học

- Đếm số combinations sum = target
- Thứ tự khác nhau tính là combination khác
- dp[i] = ways để achieve sum i

## 3. Code chính (có comment)

```python
def combination_sum_iv(nums, target):
    """
    Combination Sum IV
    Input: nums=[1,2,3], target=4
    Output: 7 ([1,1,1,1], [1,1,2], [1,2,1], [2,1,1], [2,2], [1,3], [3,1])
    """
    # dp[i] = ways để achieve sum i
    dp = [0] * (target + 1)
    dp[0] = 1
    
    for i in range(1, target + 1):
        for num in nums:
            if num <= i:
                dp[i] += dp[i - num]
    
    return dp[target]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 310 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3100 |