# Bài 212 — LeetCode: Climbing Stairs (Easy)

## 1. Ôn tập

Bài 211 dùng Binary Search. Hôm nay ta học **Dynamic Programming cơ bản** - Fibonacci pattern!

## 2. Mục tiêu bài học

- Đếm số cách leo cầu thang
- Nắm Fibonacci DP pattern
- Space optimization

## 3. Code chính (có comment)

```python
def climb_stairs(n: int) -> int:
    """
    Nếu có thể leo 1 hoặc 2 bậc, có bao nhiêu cách lên n bậc?
    
    n=1: 1 cách (1)
    n=2: 2 cách (1+1, 2)
    n=3: 3 cách (1+1+1, 1+2, 2+1)
    n=4: 5 cách
    """
    if n <= 2:
        return n
    
    # DP: ways(n) = ways(n-1) + ways(n-2)
    prev2, prev1 = 1, 2
    
    for i in range(3, n + 1):
        current = prev1 + prev2
        prev2 = prev1
        prev1 = current
    
    return prev1

# Test
print(climb_stairs(2))  # 2
print(climb_stairs(3))  # 3
print(climb_stairs(4))  # 5
print(climb_stairs(5))  # 8
```

## 4. Trace chạy code

```
n=5

prev2=1 (ways(1)), prev1=2 (ways(2))
i=3: current=3, prev2=2, prev1=3 → ways(3)=3
i=4: current=5, prev2=3, prev1=5 → ways(4)=5  
i=5: current=8, prev2=5, prev1=8 → ways(5)=8

Output: 8
```

## 5. Debug tư duy

### Đây là Fibonacci!
```python
# Fibonacci: 1, 1, 2, 3, 5, 8, 13...
# Climbing: 1, 2, 3, 5, 8...

# Công thức giống nhau!
```

### Space O(1) vì chỉ cần 2 biến!
```python
# Không cần array
dp = [0] * (n + 1)  # Unnecessary!
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 212 / 2000 |
| **XP** | 2120 |