# Bài 351 — Majority Element (Easy)

## 1. Ôn tập

Từ bài 350, ta đã học Two Sum II. Hôm nay ta học **Majority Element**!

## 2. Mục tiêu bài học

- Tìm element xuất hiện > n/2 lần
- Boyer-Moore Voting Algorithm
- O(n) time, O(1) space

## 3. Code chính (có comment)

```python
def majority_element(nums):
    """
    Majority Element
    Input: [3,2,3]
    Output: 3
    """
    count = 0
    candidate = None
    
    for num in nums:
        if count == 0:
            candidate = num
        count += (1 if num == candidate else -1)
    
    return candidate
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 351 / 2000 |
| **Chapter** | Array |
| **XP** | 3510 |