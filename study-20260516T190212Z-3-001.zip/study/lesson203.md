# Bài 203 — LeetCode: Remove Duplicates (Easy)

## 1. Ôn tập

Bài 202 dùng Two Pointers để so sánh từ hai đầu. Hôm nay ta dùng Two Pointers để XÓA phần tử trong mảng!

## 2. Mục tiêu bài học

- Xóa phần tử trùng trong mảng đã sort
- Dùng Two Pointers không tạo mảng mới
- Return số phần tử unique

## 3. Code chính (có comment)

```python
from typing import List

def remove_duplicates(nums: List[int]) -> int:
    """
    Xóa duplicate trong sorted array
    Không dùng extra space
    
    Input: [1,1,2]
    Output: 2, nums = [1,2,_]
    """
    if not nums:
        return 0
    
    # slow pointer: vị trí cuối cùng của unique elements
    # fast pointer: duyệt qua tất cả elements
    slow = 0
    
    for fast in range(1, len(nums)):
        # Nếu nums[fast] khác nums[slow] → có element mới
        if nums[fast] != nums[slow]:
            slow += 1
            nums[slow] = nums[fast]  # Ghi đè
    
    return slow + 1  # Số lượng unique

# Test
nums = [1, 1, 2, 2, 3, 3, 3]
k = remove_duplicates(nums)
print(f"K={k}, nums[:k]={nums[:k]}")  # K=3, nums=[1,2,3]
```

## 4. Trace chạy code

```
nums = [1, 1, 2, 2, 3, 3, 3]
slow=0

fast=1: nums[1]=1 == nums[0]=1 → skip
fast=2: nums[2]=2 != nums[0]=1 → slow=1, nums[1]=2
fast=3: nums[3]=2 == nums[1]=2 → skip  
fast=4: nums[4]=3 != nums[1]=2 → slow=2, nums[2]=3
fast=5: nums[5]=3 == nums[2]=3 → skip
fast=6: nums[6]=3 == nums[2]=3 → skip

Result: K=3, nums=[1,2,3]
```

## 5. Debug tư duy

### Tại sao không dùng set?
```python
# Sai: Set không giữ thứ tự và không modify original array
unique = set(nums)  # Wrong!

# Đúng: Two pointers modify trực tiếp
```

### slow bắt đầu từ 0, return slow+1
```python
# Mảng [1,1,2]: slow cuối = 1 → return 2
# Mảng [1,2,3]: slow cuối = 2 → return 3
# Công thức: return slow + 1
```

## 6. Ghi nhớ nhanh

| Loại | Time | Space |
|------|------|-------|
| This approach | O(n) | O(1) |
| Using Set | O(n) | O(n) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 203 / 2000 |
| **XP** | 2030 |