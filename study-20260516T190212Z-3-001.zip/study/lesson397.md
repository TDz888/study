# Bài 397 — Count Primes (Medium)

## 1. Ôn tập

Từ bài 396, ta đã học Power of Four. Hôm nay ta học **Count Primes**!

## 2. Mục tiêu bài học

- Đếm số primes < n
- Sieve of Eratosthenes
- O(n log log n)

## 3. Code chính (có comment)

```python
def count_primes(n):
    """
    Count Primes
    Input: n=10
    Output: 4 (2,3,5,7)
    """
    if n <= 2:
        return 0
    
    is_prime = [True] * n
    is_prime[0] = is_prime[1] = False
    
    for i in range(2, int(n**0.5) + 1):
        if is_prime[i]:
            for j in range(i*i, n, i):
                is_prime[j] = False
    
    return sum(is_prime)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 397 / 2000 |
| **Chapter** | Math |
| **XP** | 3970 |