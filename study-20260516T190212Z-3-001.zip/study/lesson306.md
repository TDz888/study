# Bài 306 — House Robber (Medium)

## 1. Ôn tập

Từ bài 305, ta đã học Word Break. Hôm nay ta học **House Robber** - DP cổ điển!

## 2. Mục tiêu bài học

- Không được rob 2 houses liên tiếp
- Tìm max money có thể rob
- dp[i] = max money rob đến house i

## 3. Code chính (có comment)

```python
def house_robber(nums):
    """
    House Robber
    Input: [1,2,3,1]
    Output: 4 (1+3)
    """
    if not nums:
        return 0
    if len(nums) == 1:
        return nums[0]
    
    n = len(nums)
    # dp[i] = max money đến index i
    dp = [0] * n
    dp[0] = nums[0]
    dp[1] = max(nums[0], nums[1])
    
    for i in range(2, n):
        dp[i] = max(dp[i-1], dp[i-2] + nums[i])
    
    return dp[n-1]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 306 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3060 |