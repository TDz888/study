# Bài 234 — Redundant Connection (Medium)

## 1. Ôn tập

Từ bài 233, ta đã học Union-Find. Hôm nay ta học **Redundant Connection** - tìm cạnh thừa!

## 2. Mục tiêu bài học

- Tìm cạnh tạo cycle trong tree
- Dùng Union-Find
- Return cạnh cuối cùng tạo cycle

## 3. Code chính (có comment)

```python
def find_redundant_connection(edges: List[List[int]]) -> List[int]:
    """
    Tìm cạnh thừa (tạo cycle)
    Input: edges=[[1,2],[1,3],[2,3]]
    Output: [2,3]
    """
    parent = list(range(1001))  # Max nodes
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        px, py = find(x), find(y)
        if px == py:
            return False  # Đã same set -> cycle
        parent[px] = py
        return True
    
    for u, v in edges:
        if not union(u, v):
            return [u, v]
    
    return []
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 234 / 2000 |
| **Chapter** | Union-Find |
| **XP** | 2340 |