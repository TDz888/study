# Bài 349 — Intersection of Two Arrays (Easy)

## 1. Ôn tập

Từ bài 348, ta đã học Inorder Traversal. Hôm nay ta học **Intersection of Two Arrays**!

## 2. Mục tiêu bài học

- Tìm intersection của 2 arrays
- Dùng sets
- Loại bỏ duplicates

## 3. Code chính (có comment)

```python
def intersection(nums1, nums2):
    """
    Intersection
    Input: [1,2,2,1], [2,2]
    Output: [2]
    """
    set1 = set(nums1)
    set2 = set(nums2)
    
    return list(set1 & set2)  # Set intersection
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 349 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3490 |