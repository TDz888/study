# Bài 191 — Logger System

## 1. Project

Structured async logging system

## 2. Code

```python
import logging
import json
from datetime import datetime

class AsyncLogger:
    def __init__(self, name):
        self.logger = logging.getLogger(name)
    
    async def log(self, level, message, **kwargs):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level,
            "message": message,
            **kwargs
        }
        self.logger.log(level, json.dumps(log_entry))
    
    async def info(self, msg, **kwargs): await self.log("INFO", msg, **kwargs)
    async def error(self, msg, **kwargs): await self.log("ERROR", msg, **kwargs)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 191 / 2000 |
| **XP** | 1910 |