# Bài 219 — Hash Table Patterns Tổng hợp

## 1. Ôn tập

Từ bài 201-218, ta đã học nhiều Hash Table problems. Hôm nay ta **tổng hợp** các patterns!

## 2. Mục tiêu bài học

- Nhận diện Hash Table problems
- Các patterns thường gặp
- Best practices

## 3. Patterns Tổng hợp

```python
# Pattern 1: Two Sum
# → Complement = target - num
def two_sum(nums, target):
    seen = {}
    for i, num in enumerate(nums):
        if target - num in seen:
            return [seen[target-num], i]
        seen[num] = i

# Pattern 2: Frequency Count  
# → Counter hoặc dict
def freq_count(arr):
    return {x: arr.count(x) for x in set(arr)}

# Pattern 3: Anagram Check
# → Sort hoặc count characters
def is_anagram(s1, s2):
    return Counter(s1) == Counter(s2)

# Pattern 4: Subarray Sum
# → Prefix sum + hashmap
def subarray_sum(nums, target):
    prefix = {0: 1}
    current = 0
    for num in nums:
        current += num
        if current - target in prefix:
            return True
        prefix[current] = prefix.get(current, 0) + 1
    return False
```

## 4. Khi nào dùng Hash Table?

| Use Case | Solution |
|----------|----------|
| Tìm cặp có tổng | Hash complement |
| Đếm frequency | Counter |
| Check duplicate | Set |
| Anagram | Counter/Sort |
| Subarray sum | Prefix + Hash |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 219 / 2000 |
| **XP** | 2190 |