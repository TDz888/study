# Bài 398 — Reverse String II (Easy)

## 1. Ôn tập

Từ bài 397, ta đã học Count Primes. Hôm nay ta học **Reverse String II**!

## 2. Mục tiêu bài học

- Reverse every k characters trong string
- Loop qua string
- O(n)

## 3. Code chính (có comment)

```python
def reverse_str(s, k):
    """
    Reverse String II
    Input: s="abcdefg", k=2
    Output: "bacdfeg"
    """
    s = list(s)
    
    for i in range(0, len(s), 2*k):
        left = i
        right = min(i + k - 1, len(s) - 1)
        
        while left < right:
            s[left], s[right] = s[right], s[left]
            left += 1
            right -= 1
    
    return ''.join(s)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 398 / 2000 |
| **Chapter** | String |
| **XP** | 3980 |