# Bài 411 — Insert into BST (Easy)

## 1. Ôn tập

Từ bài 410, ta đã học Search in BST. Hôm nay ta học **Insert into BST**!

## 2. Mục tiêu bài học

- Insert node vào BST
- Không cần rebalance
- O(h)

## 3. Code chính (có comment)

```python
def insert_into_bst(root, val):
    """
    Insert into BST
    Input: root, val
    Output: Tree với inserted node
    """
    if not root:
        return TreeNode(val)
    
    if val < root.val:
        root.left = insert_into_bst(root.left, val)
    else:
        root.right = insert_into_bst(root.right, val)
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 411 / 2000 |
| **Chapter** | Trees |
| **XP** | 4110 |