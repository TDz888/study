# Bài 185 — Practice: Chat Server

## 1. Project Overview

Xây dựng async chat server với:
- WebSocket
- Room management
- Broadcast messages

## 2. Code

```python
import asyncio
from websockets.server import serve

class ChatServer:
    def __init__(self):
        self.rooms = {}  # room -> set of ws
    
    async def handle(self, ws):
        room = None
        async for msg in ws:
            # Parse msg, join/leave/chat
            pass
    
    async def broadcast(self, room, msg):
        for ws in self.rooms.get(room, []):
            await ws.send(msg)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 185 / 2000 |
| **XP** | 1850 |