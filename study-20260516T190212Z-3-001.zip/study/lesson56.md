# Bài 56 — Context Managers

---

## 1. Ôn tập
Bài 55 đã học về Decorators. Giờ học về **Context Manager** — cách quản lý tài nguyên an toàn.

---

## 2. Mục tiêu bài học
- Hiểu context manager là gì
- Biết cách dùng `with` statement
- Tạo context manager tùy chỉnh
- Dùng contextlib decorators

---

## 3. Code chính (có comment)

### Context Manager cơ bản
```python
# Dùng with để quản lý tài nguyên
with open("file.txt", "r", encoding="utf-8") as f:
    content = f.read()
# File TỰ ĐỘNG đóng khi thoát khỏi block

# Không cần:
# f.close()  # Đã tự động!
```

### Tạo Context Manager với Class
```python
import time

class Timer:
    """Context manager đo thời gian"""
    def __enter__(self):
        """Chạy khi vào with block"""
        self.start = time.time()
        return self  # Giá trị gán cho as
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Chạy khi ra khỏi with block"""
        elapsed = time.time() - self.start
        print(f"Time: {elapsed:.4f}s")

# Sử dụng
with Timer() as t:
    result = sum(range(1000000))
    print(f"Result: {result}")
# Output: Result: ... Time: 0.0xxx s
```

### Dùng contextlib decorator
```python
from contextlib import contextmanager

@contextmanager
def my_context():
    """Tạo context manager bằng decorator"""
    print("Enter")           # Code trước yield
    yield "Resource"         # Giá trị cho as
    print("Exit")            # Code sau yield (chạy khi thoát)

# Sử dụng
with my_context() as r:
    print(f"Got: {r}")
# Output:
# Enter
# Got: Resource
# Exit
```

---

## 4. Trace chạy code

```
with Timer() as t:
    print("Running")

Flow:
1. __enter__() được gọi
   → self.start = time.time()
   → return self → gán cho t

2. Chạy code trong block
   → print("Running")

3. Khi ra khỏi block
   → __exit__(...) được gọi
   → In thời gian elapsed
```

---

## 5. Debug tư duy

### ❌ Lỗi 1 — Quên return trong __enter__
```python
# LỖI! __enter__ không return
class Timer:
    def __enter__(self):
        self.start = time.time()
        # Quên return!

with Timer() as t:
    print(t)  # t = None
```

### ❌ Lỗi 2 — Nhầm yield và return
```python
# yield: Dùng với @contextmanager (generator-based)
# return: Dùng với class (protocol-based)

# Class-based:
def __enter__(self):
    return self

# Generator-based:
yield "value"  # KHÔNG phải return!
```

### ❌ Lỗi 3 — Không xử lý exception trong __exit__
```python
# __exit__ nhận 3 tham số về exception
def __exit__(self, exc_type, exc_val, exc_tb):
    if exc_type:  # Có exception xảy ra
        print(f"Error: {exc_val}")
    return True  # True = đã xử lý, không re-raise
```

---

## 6. Ghi nhớ nhanh

| Method | Ý nghĩa |
|--------|---------|
| `__enter__` | Chạy khi vào block |
| `__exit__` | Chạy khi ra khỏi block |
| `yield` | Tạo context với @contextmanager |
| `as variable` | Nhận giá trị từ __enter__/yield |

**MẸO NHỚ:** Context manager = "Tự động cleanup" - dùng xong không cần lo close.

---

## 7. Mini test (3 câu)

**Câu 1:** File tự đóng khi nào trong with?
> Đáp án: **Khi thoát khỏi with block**

**Câu 2:** __exit__ có mấy parameters?
> Đáp án: **3** (exc_type, exc_val, exc_tb)**

**Câu 3:** Dùng @contextmanager thay vì class khi nào?
> Đáp án: **Khi code đơn giản, không cần nhiều state**

---

## 8. LeetCode Practice

### Bài tập: Context manager đếm số lần gọi
**Yêu cầu:** Tạo context manager đếm số lần sử dụng

**Input:**
```
3
```

**Output:** 
```
Total: 3
```

**✅ Đáp án:**
```python
from contextlib import contextmanager

@contextmanager
def counter():
    count = [0]
    yield count
    print(f"Total: {count[0]}")

with counter() as c:
    for _ in range(3):
        c[0] += 1
        print("Counted")
```

---

## 9. Bonus (nếu học tốt)

**Thử thách:** Context manager quản lý database connection

**Input:** (không có)

**Output:**
```
Connecting to database...
Query executed
Connection closed
```

**✅ Đáp án:**
```python
class DatabaseConnection:
    def __init__(self, db_name):
        self.db_name = db_name
    
    def __enter__(self):
        print(f"Connecting to {self.db_name}...")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("Connection closed")
        return True
    
    def query(self, sql):
        print("Query executed")

# Sử dụng
with DatabaseConnection("myDB") as db:
    db.query("SELECT * FROM users")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 56 / 2000 |
| **Chapter** | 3 (Functions) |
| **XP** | 560 (+20 XP khi hoàn thành) |
| **Level** | Advanced |

---

**🎉 Bạn đã hoàn thành Bài 56!**

Gõ **57** để học tiếp Bài 57 (Generators) →