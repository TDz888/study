# Lesson 73 — Named Tuples

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 72 - Data Classes.

**Current Lesson:** Learning **Named Tuples** — tuples with names.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Creating named tuples
- Accessing fields
- Methods

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

```python
from collections import namedtuple

# Define
Point = namedtuple('Point', ['x', 'y'])
Person = namedtuple('Person', 'name age city')

# Use
p = Point(10, 20)
print(p.x, p.y)  # 10 20
print(p[0], p[1])  # 10 20

person = Person("Alice", 25, "NYC")
print(person.name)  # Alice
```

### Methods

```python
# _replace - create new instance with changes
p2 = p._replace(x=100)
print(p2)  # Point(x=100, y=20)

# _asdict - convert to dictionary
print(person._asdict())  # {'name': 'Alice', ...}

# Make from iterable
data = [30, 40]
p3 = Point._make(data)
print(p3)  # Point(x=30, y=40)
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is the difference between namedtuple and dataclass?**

> **Answer:** namedtuple is immutable, dataclass is mutable

---

**Type 74 to continue**