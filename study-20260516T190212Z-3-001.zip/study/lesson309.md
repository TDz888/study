# Bài 309 — Best Time to Buy and Sell Stock (Medium)

## 1. Ôn tập

Từ bài 308, ta đã học Climbing Stairs. Hôm nay ta học **Best Time to Buy and Sell Stock**!

## 2. Mục tiêu bài học

- 1 transaction max profit
- Mua low, bán high
- Track min price và max profit

## 3. Code chính (có comment)

```python
def max_profit(prices):
    """
    Max profit
    Input: [7,1,5,3,6,4]
    Output: 5 (buy at 1, sell at 6)
    """
    if not prices:
        return 0
    
    min_price = float('inf')
    max_profit = 0
    
    for price in prices:
        # Update min price
        min_price = min(min_price, price)
        # Update max profit
        max_profit = max(max_profit, price - min_price)
    
    return max_profit
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 309 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3090 |