# Bài 460 — 01 Matrix (Medium)

## 1. Ôn tập

Từ bài 459, ta đã học Flood Fill. Hôm nay ta học **01 Matrix**!

## 2. Mục tiêu bài học

- Tìm distance đến nearest 0
- BFS từ all zeros
- O(m*n)

## 3. Code chính (có comment)

```python
from collections import deque

def update_matrix(mat):
    """
    01 Matrix
    Input: [[0,0,0],[0,1,0],[1,1,1]]
    Output: [[0,0,0],[0,1,0],[1,2,1]]
    """
    if not mat:
        return mat
    
    rows, cols = len(mat), len(mat[0])
    queue = deque()
    
    # Add all zeros
    for r in range(rows):
        for c in range(cols):
            if mat[r][c] == 0:
                queue.append((r, c))
            else:
                mat[r][c] = -1
    
    directions = [(0,1),(0,-1),(1,0),(-1,0)]
    
    while queue:
        r, c = queue.popleft()
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and mat[nr][nc] == -1:
                mat[nr][nc] = mat[r][c] + 1
                queue.append((nr, nc))
    
    return mat
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 460 / 2000 |
| **Chapter** | BFS |
| **XP** | 4600 |