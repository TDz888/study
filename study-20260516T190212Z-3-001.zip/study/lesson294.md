# Bài 294 — Maximum Depth of Binary Tree (Easy)

## 1. Ôn tập

Từ bài 293, ta đã học Right Side View. Hôm nay ta học **tìm maximum depth**!

## 2. Mục tiêu bài học

- Tìm độ sâu lớn nhất của tree
- Dùng DFS (recursive) hoặc BFS
- Cơ bản nhưng quan trọng

## 3. Code chính (có comment)

```python
def max_depth(root):
    """
    Maximum depth
    Input: Tree
    Output: Depth (số levels)
    """
    if not root:
        return 0
    
    # Recursive: 1 + max(left, right)
    return 1 + max(max_depth(root.left), max_depth(root.right))

# Cách 2: BFS - đếm levels
def max_depth_bfs(root):
    if not root:
        return 0
    
    depth = 0
    queue = deque([root])
    
    while queue:
        depth += 1
        for _ in range(len(queue)):
            node = queue.popleft()
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return depth
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 294 / 2000 |
| **Chapter** | Trees |
| **XP** | 2940 |