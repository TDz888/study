# Bài 86 — Object-Oriented Design

---

## 1. Giới thiệu
Học về **OOP Design Patterns**.

---

## 2. SOLID Principles

```python
# S - Single Responsibility
class User:
    def __init__(self, name):
        self.name = name

class UserRepository:
    def save(self, user):
        pass

# O - Open/Closed
class Shape:
    def area(self):
        pass

class Circle(Shape):
    def __init__(self, r):
        self.r = r
    def area(self):
        return 3.14 * self.r ** 2

# L - Liskov Substitution
# subclass có thể thay thế parent

# I - Interface Segregation
# Nhiều interface nhỏ thay vì 1 interface lớn

# D - Dependency Inversion
# Phụ thuộc abstraction không phải concrete
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 86 / 2000 |
| **XP** | 860 |
| **Level** | Advanced |