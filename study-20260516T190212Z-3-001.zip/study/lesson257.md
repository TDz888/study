# Bài 257 — Inorder Traversal (Easy)

## 1. Ôn tập

Từ bài 256, ta đã học kiểm tra BST. Hôm nay ta học **Inorder Traversal** - duyệt cây theo thứ tự giữa!

## 2. Mục tiêu bài học

- Duyệt: Left → Root → Right
- Kết quả của BST luôn là sorted array
- Dùng đệ quy hoặc stack

## 3. Code chính (có comment)

```python
def inorder_traversal(root: TreeNode) -> list:
    """
    Inorder: Left → Root → Right
    Input: root = [1,None,2,3]
    Output: [1,3,2]
    """
    result = []
    
    def traverse(node):
        if not node:
            return
        # 1. Duyệt cây con bên trái
        traverse(node.left)
        # 2. Visit root
        result.append(node.val)
        # 3. Duyệt cây con bên phải
        traverse(node.right)
    
    traverse(root)
    return result

# Cách 2: Dùng stack (iterative)
def inorder_iterative(root):
    result = []
    stack = []
    curr = root
    
    while curr or stack:
        # Đi hết sang trái
        while curr:
            stack.append(curr)
            curr = curr.left
        
        # Pop và visit
        curr = stack.pop()
        result.append(curr.val)
        # Sang phải
        curr = curr.right
    
    return result
```

## 4. Quy trình duyệt

```
       4
      / \
     2   6
    / \ / \
   1  3 5  7

Inorder: 1 → 2 → 3 → 4 → 5 → 6 → 7 (Sorted!)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 257 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2570 |