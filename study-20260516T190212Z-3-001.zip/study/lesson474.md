# Lesson 474 — Find Lucky Integer

---

## 1. KNOWLEDGE CONNECTION

Từ bài 473, bạn đã học **Set Mismatch** với counting. Bài hôm nay **Find Lucky Integer** - tìm số may mắn (số = số lần xuất hiện). Tiếp tục củng cố kỹ thuật đếm.

## 2. TODAY'S MISSION

- Tìm phần tử có giá trị = tần suất xuất hiện
- Return lớn nhất, nếu không có return -1

## 3. MAIN CODE

```python
def find_lucky(arr):
    """Tìm lucky integer"""
    from collections import Counter
    freq = Counter(arr)
    
    lucky = -1
    for num, count in freq.items():
        if num == count and num > lucky:
            lucky = num
    
    return lucky
```

## 4-13. Progress

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 474 / 2000 |
| **XP** | +10 |