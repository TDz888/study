# Bài 232 — Graph Valid Tree (Medium)

## 1. Ôn tập

Từ bài 231, ta đã học longest consecutive. Hôm nay ta học **Graph Valid Tree**!

## 2. Mục tiêu bài học

- Kiểm tra graph có phải là tree không
- Tree = connected + no cycle
- N nodes có N-1 edges

## 3. Code chính (có comment)

```python
def valid_tree(n: int, edges: List[List[int]]) -> bool:
    """
    Kiểm tra graph có phải là tree không
    Input: n=5, edges=[[0,1],[0,2],[0,3],[1,4]]
    Output: True
    """
    if len(edges) != n - 1:
        return False
    
    # Build adjacency list
    graph = [[] for _ in range(n)]
    for u, v in edges:
        graph[u].append(v)
        graph[v].append(u)
    
    visited = [False] * n
    
    def dfs(node, parent):
        visited[node] = True
        for neighbor in graph[node]:
            if not visited[neighbor]:
                if not dfs(neighbor, node):
                    return False
            elif neighbor != parent:
                # Có cycle
                return False
        return True
    
    # Check connected
    return dfs(0, -1) and all(visited)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 232 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2320 |