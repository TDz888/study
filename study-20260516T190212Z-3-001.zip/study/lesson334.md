# Bài 334 — Spiral Matrix (Medium)

## 1. Ôn tập

Từ bài 333, ta đã học Word Break II. Hôm nay ta học **Spiral Matrix**!

## 2. Mục tiêu bài học

- Traverse matrix theo spiral order
- 4 boundaries: top, bottom, left, right
- In-place tracking

## 3. Code chính (có comment)

```python
def spiral_order(matrix):
    """
    Spiral Order
    Input: [[1,2,3],[4,5,6],[7,8,9]]
    Output: [1,2,3,6,9,8,7,4,5]
    """
    result = []
    top, bottom, left, right = 0, len(matrix) - 1, 0, len(matrix[0]) - 1
    
    while top <= bottom and left <= right:
        # Left to right
        for col in range(left, right + 1):
            result.append(matrix[top][col])
        top += 1
        
        # Top to bottom
        for row in range(top, bottom + 1):
            result.append(matrix[row][right])
        right -= 1
        
        # Right to left
        if top <= bottom:
            for col in range(right, left - 1, -1):
                result.append(matrix[bottom][col])
            bottom -= 1
        
        # Bottom to top
        if left <= right:
            for row in range(bottom, top - 1, -1):
                result.append(matrix[row][left])
            left += 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 334 / 2000 |
| **Chapter** | Matrix |
| **XP** | 3340 |