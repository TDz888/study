# Bài 350 — Two Sum II (Easy)

## 1. Ôn tập

Từ bài 349, ta đã học Intersection. Hôm nay ta học **Two Sum II**!

## 2. Mục tiêu bài học

- Input sorted, tìm 2 số sum = target
- Two pointers
- O(n)

## 3. Code chính (có comment)

```python
def two_sum(numbers, target):
    """
    Two Sum II
    Input: [2,7,11,15], target=9
    Output: [1,2] (indexes)
    """
    left, right = 0, len(numbers) - 1
    
    while left < right:
        current_sum = numbers[left] + numbers[right]
        
        if current_sum == target:
            return [left + 1, right + 1]  # 1-indexed
        elif current_sum < target:
            left += 1
        else:
            right -= 1
    
    return []
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 350 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3500 |