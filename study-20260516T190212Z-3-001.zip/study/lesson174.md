# Bài 174 — Infinite Generators

## 1. Ôn tập

Generator có thể tạo sequence vô hạn! Đây là một trong những ứng dụng mạnh của generator.

## 2. Mục tiêu bài học

- Tạo infinite generators
- Fibonacci generator
- An toàn khi dùng với take/limit

## 3. Code chính (có comment)

```python
# Infinite counter
def count(start=0):
    while True:
        yield start
        start += 1

# Fibonacci infinite
def fibonacci():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

# Prime numbers infinite
def primes():
    n = 2
    while True:
        is_prime = True
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                is_prime = False
                break
        if is_prime:
            yield n
        n += 1

# Take function - lấy N phần tử từ generator
def take(n, gen):
    """Lấy n phần tử đầu từ generator"""
    result = []
    for _ in range(n):
        result.append(next(gen))
    return result

# Test
print(take(10, count()))           # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(take(10, fibonacci()))       # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
print(take(10, primes()))          # [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
```

## 4. Trace chạy code

```
[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
[0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
[2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
```

## 5. Debug tư duy

### Cẩn thận: Infinite = Infinity!
```python
# SAI: Quên limit!
for prime in primes():  # Loop mãi mãi!
    print(prime)

# ĐÚNG: Luôn có limit
for i, prime in enumerate(primes()):
    print(prime)
    if i >= 9:  # Chỉ 10 số
        break
```

### itertools.islice
```python
from itertools import islice

# Cách an toàn hơn
print(list(islice(fibonacci(), 10)))  # Lấy 10 phần tử đầu
```

## 6. Ghi nhớ nhanh

| Generator | Công dụng |
|-----------|-----------|
| `count()` | Counter vô hạn |
| `fibonacci()` | Dãy Fibonacci |
| `primes()` | Số nguyên tố |
| `islice(gen, n)` | Lấy n phần tử |

## 7. Mini test (3 câu)

**Câu 1:** Infinite generator cần gì?
- A) Không cần gì đặc biệt
- B) Vòng while True + yield
- C) return ở cuối
- D)break

**Câu 2:** Khi dùng infinite generator, cần gì?
- A) Không cần gì
- B) Limit/break/slice
- C) StopIteration
- D) Reset

**Câu 3:** itertools.islice dùng để?
- A) Tạo slice object
- B) Cắt generator lấy phần tử
- C) Sort generator
- D) Filter

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Clock Angles"

```python
def clock_angles():
    """Yield góc giờ-phút cho tất cả thời điểm trong ngày"""
    # 0:00 → 23:59
    pass

print(list(islice(clock_angles(), 10)))
```

## 9. Bonus

Tạo:
- Triangle numbers generator
- Square numbers generator
- Pythagorean triples generator

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 174 / 2000 |
| **XP** | 1740 |