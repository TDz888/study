# Bài 368 — Roman to Integer (Easy)

## 1. Ôn tập

Từ bài 367, ta đã học Integer to Roman. Hôm nay ta học **Roman to Integer**!

## 2. Mục tiêu bài học

- Convert Roman sang integer
- Subtractive rule: IV=4, IX=9, etc.
- Scan left to right

## 3. Code chính (có comment)

```python
def roman_to_int(s):
    """
    Roman to Integer
    Input: s="MCMXIV"
    Output: 1914
    """
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    
    result = 0
    prev = 0
    
    for char in reversed(s):
        val = values[char]
        if val < prev:
            result -= val
        else:
            result += val
        prev = val
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 368 / 2000 |
| **Chapter** | Math |
| **XP** | 3680 |