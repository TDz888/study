# Bài 170 — Chương trình Async hoàn chỉnh

## 1. Ôn tập

Qua các bài vừa qua, ta đã học:
- Lock, Event, Condition
- Queue, create_task, gather
- Cancellation, Shield

Hôm nay, ta sẽ KẾT HỢP tất cả để tạo một chương trình async hoàn chỉnh!

## 2. Mục tiêu bài học

- Tổng hợp kiến thức async
- Xây dựng hệ thống async thực tế
- Quản lý lifecycle hoàn chỉnh

## 3. Code chính (có comment)

```python
import asyncio
from dataclasses import dataclass
from typing import Optional

@dataclass
class Job:
    id: int
    data: str
    priority: int = 0

class AsyncJobSystem:
    """
    Hệ thống xử lý job hoàn chỉnh:
    - Queue với priority
    - Multiple workers
    - Graceful shutdown
    - Progress tracking
    """
    
    def __init__(self, num_workers: int = 3):
        self.num_workers = num_workers
        self.queue = asyncio.Queue()
        self.workers: list[asyncio.Task] = []
        self.is_shutdown = asyncio.Event()
        self.lock = asyncio.Lock()
        self.completed = 0
        self.failed = 0
    
    async def submit_job(self, job: Job):
        """Submit job vào queue"""
        await self.queue.put(job)
        print(f"Submitted: Job {job.id}")
    
    async def process_job(self, job: Job):
        """Xử lý một job"""
        try:
            # Giả lập xử lý
            await asyncio.sleep(0.5)
            
            # Update stats với lock
            async with self.lock:
                self.completed += 1
                print(f"Completed: Job {job.id} ({self.completed} done)")
            
        except Exception as e:
            async with self.lock:
                self.failed += 1
            raise
    
    async def worker(self, worker_id: int):
        """Worker xử lý jobs"""
        print(f"Worker {worker_id}: Started")
        
        while not self.is_shutdown.is_set():
            try:
                # Wait for job với timeout
                job = await asyncio.wait_for(
                    self.queue.get(),
                    timeout=1.0
                )
                await self.process_job(job)
                self.queue.task_done()
                
            except asyncio.TimeoutError:
                continue  # Tiếp tục vòng lặp
            except asyncio.CancelledError:
                print(f"Worker {worker_id}: Cancelled")
                break
        
        print(f"Worker {worker_id}: Stopped")
    
    async def start(self):
        """Khởi động workers"""
        self.workers = [
            asyncio.create_task(self.worker(i))
            for i in range(self.num_workers)
        ]
        print(f"Started {self.num_workers} workers")
    
    async def shutdown(self):
        """Graceful shutdown"""
        print("Shutting down...")
        self.is_shutdown.set()
        
        # Cancel workers
        for worker in self.workers:
            worker.cancel()
        
        # Wait all
        await asyncio.gather(*self.workers, return_exceptions=True)
        
        print(f"Shutdown complete. "
              f"Completed: {self.completed}, Failed: {self.failed}")

async def main():
    system = AsyncJobSystem(num_workers=3)
    await system.start()
    
    # Submit jobs
    jobs = [
        Job(1, "Data A", priority=1),
        Job(2, "Data B", priority=2),
        Job(3, "Data C", priority=0),
        Job(4, "Data D", priority=1),
        Job(5, "Data E", priority=2),
    ]
    
    for job in jobs:
        await system.submit_job(job)
    
    # Chờ queue hoàn thành
    await system.queue.join()
    
    # Shutdown
    await system.shutdown()

asyncio.run(main())
```

## 4. Trace chạy code

```
Started 3 workers
Submitted: Job 1
Submitted: Job 2
Submitted: Job 3
Submitted: Job 4
Submitted: Job 5
Worker 0: Started
Worker 1: Started
Worker 2: Started
Completed: Job 1 (1 done)
Completed: Job 2 (2 done)
Completed: Job 3 (3 done)
Completed: Job 4 (4 done)
Completed: Job 5 (5 done)
Shutting down...
Worker 0: Stopped
Worker 1: Stopped
Worker 2: Stopped
Shutdown complete. Completed: 5, Failed: 0
```

## 5. Debug tư duy

### Checklist cho hệ thống async hoàn chỉnh
```python
# 1. ✅ Khởi tạo resources
# 2. ✅ Quản lý lifecycle (start/stop)
# 3. ✅ Graceful shutdown
# 4. ✅ Error handling
# 5. ✅ Cleanup resources
# 6. ✅ Logging/Tracing
# 7. ✅ Concurrency limits
# 8. ✅ Timeout handling
```

### Các pattern thường dùng
```python
# Pattern 1: Service lifecycle
class AsyncService:
    async def __aenter__(self): await self.start()
    async def __aexit__(self, *args): await self.stop()

# Pattern 2: Background tasks
async def background_task():
    while True:
        await do_work()

# Pattern 3: Health check
async def health_check():
    return {"healthy": True}
```

## 6. Ghi nhớ nhanh

| Component | Vai trò |
|-----------|---------|
| Queue | Buffer jobs |
| Workers | Xử lý jobs |
| Event | Shutdown signaling |
| Lock | Bảo vệ shared state |
| gather | Đợi completion |

## 7. Mini test (3 câu)

**Câu 1:** shutdown() cần làm gì?
- A) Exit program
- B) Graceful stop workers, cleanup
- C) Cancel all tasks
- D) Clear queue

**Câu 2:** Event.is_set() dùng để làm gì?
- A) Set giá trị
- B) Kiểm tra shutdown flag
- C) Reset flag
- D) Xóa event

**Câu 3:** Tại sao cần Lock cho shared state?
- A) Để code đẹp hơn
- B) Tránh race condition
- C) Tăng tốc
- D) Không cần thiết

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Web Scraper với Rate Limiting"

```python
class AsyncScraper:
    """
    - Rate limiter (Semaphore)
    - Retry logic
    - Error handling
    - Graceful shutdown
    - Stats tracking
    """
    
    def __init__(self, max_concurrent=5, max_retries=3):
        # Viết code...
        pass
```

## 9. Bonus

Mở rộng hệ thống:
- Thêm retry logic cho failed jobs
- Thêm timeout cho từng job
- Thêm priority queue
- Thêm health check endpoint

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 170 / 2000 |
| **Chapter** | Async/Await Nâng cao |
| **XP** | 1700 |