# Bài 233 — Number of Connected Components (Medium)

## 1. Ôn tập

Từ bài 232, ta đã học valid tree. Hôm nay ta học **Number of Connected Components**!

## 2. Mục tiêu bài học

- Đếm số connected components
- Dùng Union-Find hoặc DFS
- Build graph từ edge list

## 3. Code chính (có comment)

```python
def count_components(n: int, edges: List[List[int]]) -> int:
    """
    Đếm số connected components
    Input: n=5, edges=[[0,1],[1,2],[3,4]]
    Output: 2
    """
    # Dùng Union-Find
    parent = list(range(n))
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        px, py = find(x), find(y)
        if px == py:
            return
        parent[px] = py
    
    for u, v in edges:
        union(u, v)
    
    # Đếm unique roots
    return len(set(find(i) for i in range(n)))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 233 / 2000 |
| **Chapter** | Union-Find |
| **XP** | 2330 |