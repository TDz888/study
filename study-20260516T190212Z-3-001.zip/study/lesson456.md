# Bài 456 — Course Schedule III (Medium)

## 1. Ôn tập

Từ bài 455, ta đã học Surrounded Regions. Hôm nay ta học **Course Schedule III**!

## 2. Mục tiêu bài học

- Tìm max courses có thể hoàn thành
- Greedy với sorting by end time
- Priority queue

## 3. Code chính (có comment)

```python
def schedule_course(courses):
    """
    Course Schedule III
    Input: [[100,200],[200,1300],[1000,1250],[2000,3200]]
    Output: 3
    """
    courses.sort(key=lambda x: x[1])
    total = 0
    heap = []
    
    for duration, end in courses:
        if total + duration <= end:
            total += duration
            heapq.heappush(heap, -duration)
        elif heap and -heap[0] > duration:
            total += duration + heapq.heappop(heap)
            heapq.heappush(heap, -duration)
    
    return len(heap)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 456 / 2000 |
| **Chapter** | Greedy |
| **XP** | 4560 |