# Bài 136 — collections (P2)

---

## 1. OrderedDict

```python
from collections import OrderedDict

# Python 3.7+ dicts maintain insertion order
d = OrderedDict()
d['a'] = 1
d['b'] = 2
d['c'] = 3

print(d.keys())  # odict_keys(['a', 'b', 'c'])

# Move to end
d.move_to_end('a')
print(d.keys())  # odict_keys(['b', 'c', 'a'])

# Pop last
print(d.popitem())  # ('a', 3)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 136 / 2000 |
| **XP** | 1360 |
| **Level** | Intermediate |