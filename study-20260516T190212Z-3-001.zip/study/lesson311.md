# Bài 311 — Perfect Squares (Medium)

## 1. Ôn tập

Từ bài 310, ta đã học Combination Sum IV. Hôm nay ta học **Perfect Squares**!

## 2. Mục tiêu bài học

- Tìm min perfect squares sum = n
- BFS hoặc DP
- Lagrange's theorem: max 4 squares

## 3. Code chính (có comment)

```python
def num_squares(n):
    """
    Perfect Squares
    Input: n=12
    Output: 3 (4+4+4 hoặc 9+1+1+1)
    """
    # dp[i] = min squares cho i
    dp = [float('inf')] * (n + 1)
    dp[0] = 0
    
    for i in range(1, n + 1):
        j = 1
        while j * j <= i:
            dp[i] = min(dp[i], dp[i - j*j] + 1)
            j += 1
    
    return dp[n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 311 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3110 |