# Bài 267 — Binary Tree Right Side View (Medium)

## 1. Ôn tập

Từ bài 266, ta đã học Path Sum II. Hôm nay ta học **nhìn cây từ bên phải** - lấy các node visible từ phải!

## 2. Mục tiêu bài học

- Lấy node visible nhất ở mỗi level (từ phải nhìn)
- Dùng BFS hoặc DFS (ưu tiên phải trước)
- Mỗi level chỉ lấy 1 node

## 3. Code chính (có comment)

```python
from collections import deque

def right_side_view(root: TreeNode) -> list:
    """
    Nhìn cây từ bên phải
    Input: root = [1,2,3,None,5,None,4]
    Output: [1,3,4]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        
        for i in range(level_size):
            node = queue.popleft()
            
            # Lấy node cuối cùng của mỗi level
            if i == level_size - 1:
                result.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
    
    return result
```

## 4. Minh họa

```
       1            ← Nhìn từ phải: node 1
      / \
     2   3          ← Level 2: node 3 visible
       /
      4              ← Level 3: node 4 visible

Result: [1, 3, 4]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 267 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2670 |