# Lesson 88 — Design Patterns (Structural)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 87 - Design Patterns (Creational).

**Current Lesson:** Learning **Structural Design Patterns**.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Adapter pattern
- Decorator pattern

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Adapter

```python
class OldInterface:
    def old_method(self):
        return "old"

class Adapter:
    def __init__(self):
        self.adaptee = OldInterface()
    
    def new_method(self):
        return self.adaptee.old_method() + " adapted"

a = Adapter()
print(a.new_method())  # old adapted
```

### Decorator

```python
class Coffee:
    def cost(self):
        return 5

class Milk:
    def __init__(self, coffee):
        self.coffee = coffee
    def cost(self):
        return self.coffee.cost() + 1

class Sugar:
    def __init__(self, coffee):
        self.coffee = coffee
    def cost(self):
        return self.coffee.cost() + 2

coffee = Coffee()
coffee = Milk(coffee)
coffee = Sugar(coffee)
print(coffee.cost())  # 8
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does Adapter pattern do?**

> **Answer:** Converts interface to compatible one

---

**Type 89 to continue**