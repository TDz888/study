# Bài 457 — Evaluate Division (Medium)

## 1. Ôn tập

Từ bài 456, ta đã học Course Schedule III. Hôm nay ta học **Evaluate Division**!

## 2. Mục tiêu bài học

- Tính kết quả division queries
- Build graph và DFS
- O(Q * N)

## 3. Code chính (có comment)

```python
def calc_equation(equations, values, queries):
    """
    Evaluate Division
    Input: equations=[[a,b],[b,c]], values=[2.0,3.0], queries=[[a,c],[b,a]]
    Output: [6.0, 0.5]
    """
    graph = {}
    
    # Build graph
    for (a, b), val in zip(equations, values):
        if a not in graph: graph[a] = {}
        if b not in graph: graph[b] = {}
        graph[a][b] = val
        graph[b][a] = 1.0 / val
    
    def dfs(a, b, visited):
        if a not in graph or b not in graph:
            return -1.0
        if a == b:
            return 1.0
        
        visited.add(a)
        for neighbor, val in graph[a].items():
            if neighbor in visited:
                continue
            result = dfs(neighbor, b, visited)
            if result != -1.0:
                return val * result
        
        return -1.0
    
    return [dfs(a, b, set()) for a, b in queries]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 457 / 2000 |
| **Chapter** | Graph |
| **XP** | 4570 |