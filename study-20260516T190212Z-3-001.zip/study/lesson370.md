# Bài 370 — Valid Parentheses (Easy)

## 1. Ôn tập

Từ bài 369, ta đã học Longest Common Prefix. Hôm nay ta học **Valid Parentheses**!

## 2. Mục tiêu bài học

- Kiểm tra parentheses balanced không
- Dùng stack
- Match open với close

## 3. Code chính (có comment)

```python
def is_valid(s):
    """
    Valid Parentheses
    Input: s="()[]{}"
    Output: True
    """
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    
    for char in s:
        if char in pairs:
            if not stack or stack[-1] != pairs[char]:
                return False
            stack.pop()
        else:
            stack.append(char)
    
    return len(stack) == 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 370 / 2000 |
| **Chapter** | Stack |
| **XP** | 3700 |