# Bài 261 — Maximum Depth of Binary Tree (Easy)

## 1. Ôn tập

Từ bài 260, ta đã học Level Order. Hôm nay ta học tính **độ sâu tối đa** của cây!

## 2. Mục tiêu bài học

- Tìm độ sâu lớn nhất từ root đến leaf
- Dùng đệ quy: depth = 1 + max(left, right)
- Độ phức tạp O(n)

## 3. Code chính (có comment)

```python
def max_depth(root: TreeNode) -> int:
    """
    Tìm độ sâu tối đa
    Input: root = [3,9,20,None,None,15,7]
    Output: 3
    """
    # Base case: cây rỗng
    if not root:
        return 0
    
    # Đệ quy: 1 + độ sâu lớn nhất của 2 cây con
    left_depth = max_depth(root.left)
    right_depth = max_depth(root.right)
    
    return 1 + max(left_depth, right_depth)
```

## 4. Minh họa

```
       3          Depth = 1
      /
     9            Depth = 2
      \
       20         Depth = 3
      /  \
     15   7       Depth = 3 (leaf)

→ Maximum Depth = 3
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 261 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2610 |