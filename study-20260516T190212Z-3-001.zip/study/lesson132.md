# Bài 132 — functools (P1)

---

## 1. functools - Tools

```python
import functools

# reduce
result = functools.reduce(lambda x, y: x + y, [1, 2, 3, 4, 5])
print(result)  # 15

# lru_cache (memoization)
@functools.lru_cache(maxsize=128)
def fib(n):
    if n < 2: return n
    return fib(n-1) + fib(n-2)

print(fib(100))  # Fast due to cache

# partial
from functools import partial
def power(base, exponent):
    return base ** exponent
square = partial(power, exponent=2)
print(square(5))  # 25
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 132 / 2000 |
| **XP** | 1320 |
| **Level** | Intermediate |