# Bài 331 — Combination Sum (Medium)

## 1. Ôn tập

Từ bài 330, ta đã học Subsets. Hôm nay ta học **Combination Sum**!

## 2. Mục tiêu bài học

- Tìm combinations sum = target
- Có thể dùng elements nhiều lần
- Backtracking

## 3. Code chính (có comment)

```python
def combination_sum(candidates, target):
    """
    Combination Sum
    Input: candidates=[2,3,6,7], target=7
    Output: [[2,2,3],[7]]
    """
    result = []
    
    def backtrack(start, path, remaining):
        if remaining == 0:
            result.append(path[:])
            return
        if remaining < 0:
            return
        
        for i in range(start, len(candidates)):
            path.append(candidates[i])
            backtrack(i, path, remaining - candidates[i])
            path.pop()
    
    backtrack(0, [], target)
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 331 / 2000 |
| **Chapter** | Backtracking |
| **XP** | 3310 |