# Bài 177 — StopIteration Handling

## 1. Ôn tập

Ta đã biết `__next__` raise `StopIteration` khi hết. Hôm nay ta học cách xử lý nó!

## 2. Mục tiêu bài học

- Hiểu khi nào StopIteration được raise
- Dùng try/except xử lý
- Tạo infinite iterator an toàn

## 3. Code chính (có comment)

```python
class InfiniteCounter:
    def __init__(self, start=0):
        self.n = start
    
    def __iter__(self):
        return self
    
    def __next__(self):
        val = self.n
        self.n += 1
        return val

# Cách dùng:
counter = InfiniteCounter(5)
for i in range(3):
    print(next(counter))  # 5, 6, 7

# Xử lý StopIteration
def safe_next(iterator, default=None):
    try:
        return next(iterator)
    except StopIteration:
        return default

# Test
print(safe_next(counter))  # 8
print(safe_next(counter))  # 9
gen = (x for x in range(2))
print(safe_next(gen))  # 0
print(safe_next(gen))  # 1
print(safe_next(gen))  # None (đã hết)
```

## 4. Debug tư duy

### Tránh swallow StopIteration!
```python
# SAI - vòng lặp KHÔNG BAO GIỜ DỪNG!
class Broken:
    def __init__(self):
        self.n = 0
    
    def __next__(self):
        self.n += 1
        return self.n  # Không bao giờ raise!
```

### Iterator có limit
```python
class BoundedCounter:
    def __init__(self, start, end):
        self.current = start
        self.end = end
    
    def __next__(self):
        if self.current >= self.end:
            raise StopIteration
        val = self.current
        self.current += 1
        return val
```

## 5. Ghi nhớ nhanh

| Cách dùng | Code |
|-----------|------|
| Tự động | `for x in iterator` |
| Manual | `next(it)` → StopIteration |
| Safe | `getattr(it, '__next__', lambda: default)()` |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 177 / 2000 |
| **XP** | 1770 |