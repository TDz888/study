# Bài 340 — String to Integer (Medium)

## 1. Ôn tập

Từ bài 339, ta đã học Reverse Integer. Hôm nay ta học **String to Integer (atoi)**!

## 2. Mục tiêu bài học

- Parse string thành integer
- Skip whitespace, handle signs
- Clamp to 32-bit range

## 3. Code chính (có comment)

```python
def my_atoi(s):
    """
    String to Integer
    Input: "   -42"
    Output: -42
    """
    s = s.strip()
    if not s:
        return 0
    
    sign = 1
    if s[0] in '+-':
        sign = -1 if s[0] == '-' else 1
        s = s[1:]
    
    result = 0
    for char in s:
        if not char.isdigit():
            break
        result = result * 10 + int(char)
        
        # Clamp to 32-bit
        if result > 2**31 - 1:
            return 2**31 - 1 if sign == 1 else -2**31
    
    return sign * result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 340 / 2000 |
| **Chapter** | String |
| **XP** | 3400 |