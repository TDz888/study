# Bài 379 — Valid Perfect Square (Medium)

## 1. Ôn tập

Từ bài 378, ta đã học Perfect Squares. Hôm nay ta học **Valid Perfect Square**!

## 2. Mục tiêu bài học

- Kiểm tra perfect square không dùng sqrt
- Binary search
- Newton's method

## 3. Code chính (có comment)

```python
def is_perfect_square(num):
    """
    Valid Perfect Square
    Input: num=16
    Output: True
    """
    if num < 2:
        return True
    
    left, right = 1, num // 2
    
    while left <= right:
        mid = (left + right) // 2
        square = mid * mid
        
        if square == num:
            return True
        elif square < num:
            left = mid + 1
        else:
            right = mid - 1
    
    return False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 379 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3790 |