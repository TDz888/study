# Bài 94 — SQL with Python (P1)

---

## 1. SQL Commands

```python
import sqlite3

conn = sqlite3.connect('shop.db')
c = conn.cursor()

# CREATE
c.execute('''CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name TEXT,
    price REAL
)''')

# INSERT
c.execute("INSERT INTO products VALUES (NULL, 'Laptop', 999.99)")
c.execute("INSERT INTO products VALUES (NULL, 'Phone', 499.99)")

# UPDATE
c.execute("UPDATE products SET price = 899.99 WHERE name = 'Laptop'")

# DELETE
c.execute("DELETE FROM products WHERE id = 1")

# SELECT
c.execute("SELECT * FROM products WHERE price > 500")
results = c.fetchall()
for r in results:
    print(r)

conn.commit()
conn.close()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 94 / 2000 |
| **XP** | 940 |
| **Level** | Intermediate |