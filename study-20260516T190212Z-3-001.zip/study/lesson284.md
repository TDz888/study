# Bài 284 — Clone Binary Tree with Random Pointer (Medium)

## 1. Ôn tập

Từ bài 283, ta đã học Maximum Area of Island. Hôm nay ta học **clone binary tree** với random pointer!

## 2. Mục tiêu bài học

- Clone tree với extra random pointer
- Xử lý circular references
- Dùng dictionary để map old→new

## 3. Code chính (có comment)

```python
class Node:
    def __init__(self, val=0, left=None, right=None, random=None):
        self.val = val
        self.left = left
        self.right = right
        self.random = random

def clone_tree(root):
    """
    Clone tree với random pointer
    Input: Tree với random pointers
    Output: Deep copy tree
    """
    if not root:
        return None
    
    # Map: old_node -> new_node
    visited = {}
    
    def clone(node):
        if not node:
            return None
        if node in visited:
            return visited[node]
        
        new_node = Node(node.val)
        visited[node] = new_node
        
        new_node.left = clone(node.left)
        new_node.right = clone(node.right)
        new_node.random = clone(node.random)
        
        return new_node
    
    return clone(root)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 284 / 2000 |
| **Chapter** | Trees |
| **XP** | 2840 |