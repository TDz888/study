# Bài 352 — Contains Duplicate (Easy)

## 1. Ôn tập

Từ bài 351, ta đã học Majority Element. Hôm nay ta học **Contains Duplicate**!

## 2. Mục tiêu bài học

- Kiểm tra có duplicate không
- Dùng set để track seen
- O(n)

## 3. Code chính (có comment)

```python
def contains_duplicate(nums):
    """
    Contains Duplicate
    Input: [1,2,3,1]
    Output: True
    """
    seen = set()
    
    for num in nums:
        if num in seen:
            return True
        seen.add(num)
    
    return False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 352 / 2000 |
| **Chapter** | Array |
| **XP** | 3520 |