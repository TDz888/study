# Bài 346 — Candy (Hard)

## 1. Ôn tập

Từ bài 345, ta đã học Jump Game II. Hôm nay ta học **Candy**!

## 2. Mục tiêu bài học

- Distribute candies với rating constraints
- Left to right + right to left pass
- O(n)

## 3. Code chính (có comment)

```python
def candy(ratings):
    """
    Candy
    Input: [1,0,2]
    Output: 5 (2,1,2)
    """
    n = len(ratings)
    candies = [1] * n
    
    # Left to right
    for i in range(1, n):
        if ratings[i] > ratings[i-1]:
            candies[i] = candies[i-1] + 1
    
    # Right to left
    for i in range(n-2, -1, -1):
        if ratings[i] > ratings[i+1]:
            candies[i] = max(candies[i], candies[i+1] + 1)
    
    return sum(candies)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 346 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3460 |