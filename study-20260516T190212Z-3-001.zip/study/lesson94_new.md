# Lesson 94 — SQL Basics (P1)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 93 - SQLite with Python.

**Current Lesson:** Learning **SQL Basics** — the universal language for working with databases.

**Why This Matters:**
- SQL is used in virtually every database (MySQL, PostgreSQL, Oracle, SQLite)
- Understanding SQL is essential for any data-related work
- It's the foundation for data analysis, backend development, and more

**Connection:**
```
SQLite → SQL Language → Any Database
   ↓           ↓            ↓
File-based  Query        MySQL/PostgreSQL
```

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- The four fundamental SQL operations (CRUD)
- Writing SELECT queries with conditions
- Filtering data with WHERE clauses
- Sorting results with ORDER BY
- Limiting results with LIMIT

**Real-world analogy:**
- SQL is like asking questions to a database:
  - "Show me all users" → SELECT
  - "Add a new user" → INSERT
  - "Change this user's email" → UPDATE
  - "Remove this user" → DELETE

-------------------------------------------------------------------------------
3. CONCEPT FOUNDATION
-------------------------------------------------------------------------------

### What is SQL?

SQL (Structured Query Language) is a standardized language for managing and manipulating relational databases. It allows you to:

- **Query** data (ask questions)
- **Insert** new data
- **Update** existing data
- **Delete** data
- **Create** database structures (tables, indexes)

### Types of SQL Commands

| Category | Commands | Purpose |
|----------|----------|---------|
| **DDL** | CREATE, DROP, ALTER | Define structure |
| **DML** | INSERT, UPDATE, DELETE | Manipulate data |
| **DQL** | SELECT | Query data |
| **DCL** | GRANT, REVOKE | Control access |

For this lesson, we'll focus on DML and DQL.

-------------------------------------------------------------------------------
4. TERMINOLOGY EXPLANATION
-------------------------------------------------------------------------------

| Term | Simple Meaning |
|------|----------------|
| **Query** | A request for data from database |
| **Table** | Collection of rows and columns |
| **Row** | A single record (like one person) |
| **Column** | A specific attribute (like name) |
| **Primary Key** | Unique identifier for each row |
| **WHERE clause** | Condition to filter results |
| **ORDER BY** | Sort results by a column |
| **LIMIT** | Restrict number of results |

-------------------------------------------------------------------------------
5. MAIN CODE
-------------------------------------------------------------------------------

### 1. Setting Up the Database

```python
import sqlite3

# Create connection and get cursor
conn = sqlite3.connect('shop.db')
cursor = conn.cursor()

# Create a products table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        category TEXT,
        stock INTEGER DEFAULT 0
    )
''')

# Insert some sample data
sample_products = [
    ('Laptop', 999.99, 'Electronics', 50),
    ('Phone', 499.99, 'Electronics', 100),
    ('Keyboard', 79.99, 'Electronics', 200),
    ('Desk', 299.99, 'Furniture', 30),
    ('Chair', 199.99, 'Furniture', 25),
    ('Monitor', 349.99, 'Electronics', 75),
    ('Mouse', 29.99, 'Electronics', 300),
    ('Table', 149.99, 'Furniture', 40)
]

cursor.executemany(
    "INSERT INTO products (name, price, category, stock) VALUES (?, ?, ?, ?)",
    sample_products
)

conn.commit()
print("Database setup complete!")
```

### 2. SELECT - Reading Data

```python
# Basic SELECT - get all data
cursor.execute("SELECT * FROM products")
all_products = cursor.fetchall()
print("All products:")
for p in all_products:
    print(f"  {p}")

# SELECT specific columns
cursor.execute("SELECT name, price FROM products")
print("\nNames and prices:")
for name, price in cursor.fetchall():
    print(f"  {name}: ${price:.2f}")

# SELECT with WHERE - filter results
cursor.execute("SELECT * FROM products WHERE category = 'Electronics'")
print("\nElectronics products:")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[2]}")

# WHERE with comparison operators
cursor.execute("SELECT * FROM products WHERE price > 200")
print("\nProducts over $200:")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[2]}")

# Multiple conditions with AND/OR
cursor.execute("SELECT * FROM products WHERE category = 'Electronics' AND price < 100")
print("\nCheap electronics (under $100):")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[2]}")
```

### 3. Filtering Operators

```python
# Equality
cursor.execute("SELECT * FROM products WHERE category = 'Furniture'")

# Not equal
cursor.execute("SELECT * FROM products WHERE category != 'Electronics'")

# Greater than / Less than
cursor.execute("SELECT * FROM products WHERE price >= 100 AND price <= 300")

# IN - check if value is in a list
cursor.execute("SELECT * FROM products WHERE name IN ('Laptop', 'Phone', 'Mouse')")

# LIKE - pattern matching
# % = any characters, _ = single character
cursor.execute("SELECT * FROM products WHERE name LIKE 'M%'")  # Starts with M
cursor.execute("SELECT * FROM products WHERE name LIKE '%able'")  # Ends with able

# BETWEEN - range check (inclusive)
cursor.execute("SELECT * FROM products WHERE price BETWEEN 50 AND 200")

# IS NULL / IS NOT NULL
cursor.execute("SELECT * FROM products WHERE category IS NULL")
cursor.execute("SELECT * FROM products WHERE category IS NOT NULL")
```

### 4. Sorting and Limiting

```python
# ORDER BY - sort results
cursor.execute("SELECT * FROM products ORDER BY price")  # Ascending (default)
cursor.execute("SELECT * FROM products ORDER BY price DESC")  # Descending
cursor.execute("SELECT * FROM products ORDER BY category, price")  # Multiple columns

# LIMIT - restrict number of results
cursor.execute("SELECT * FROM products ORDER BY price DESC LIMIT 3")  # Top 3 expensive
cursor.execute("SELECT * FROM products ORDER BY stock LIMIT 1")  # Least stock

# OFFSET - skip results (for pagination)
cursor.execute("SELECT * FROM products ORDER BY name LIMIT 5 OFFSET 5")  # Page 2

# Combined example
cursor.execute("""
    SELECT name, price 
    FROM products 
    WHERE price < 500 
    ORDER BY price DESC 
    LIMIT 10
""")
```

### 5. UPDATE - Modifying Data

```python
# Update single row
cursor.execute(
    "UPDATE products SET price = ? WHERE name = ?",
    (899.99, 'Laptop')
)
print(f"Rows updated: {cursor.rowcount}")

# Update multiple rows
cursor.execute(
    "UPDATE products SET stock = stock - 10 WHERE stock > 0"
)

# Update with calculation
cursor.execute(
    "UPDATE products SET price = price * 0.9 WHERE category = 'Furniture'"
)  # 10% discount on furniture

conn.commit()
```

### 6. DELETE - Removing Data

```python
# Delete specific row
cursor.execute("DELETE FROM products WHERE name = 'Mouse'")

# Delete with condition
cursor.execute("DELETE FROM products WHERE stock = 0")

# Delete all (careful!)
# cursor.execute("DELETE FROM products")

conn.commit()
```

### 7. Complete CRUD Example

```python
import sqlite3

class ProductStore:
    def __init__(self, db_name='store.db'):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()
    
    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL NOT NULL,
                category TEXT,
                stock INTEGER DEFAULT 0
            )
        ''')
        self.conn.commit()
    
    def add_product(self, name, price, category, stock=0):
        self.cursor.execute(
            "INSERT INTO products (name, price, category, stock) VALUES (?, ?, ?, ?)",
            (name, price, category, stock)
        )
        self.conn.commit()
        print(f"Added: {name}")
    
    def get_products(self, category=None, min_price=None, max_price=None):
        query = "SELECT * FROM products WHERE 1=1"
        params = []
        
        if category:
            query += " AND category = ?"
            params.append(category)
        if min_price is not None:
            query += " AND price >= ?"
            params.append(min_price)
        if max_price is not None:
            query += " AND price <= ?"
            params.append(max_price)
        
        self.cursor.execute(query, params)
        return self.cursor.fetchall()
    
    def update_price(self, product_id, new_price):
        self.cursor.execute(
            "UPDATE products SET price = ? WHERE id = ?",
            (new_price, product_id)
        )
        self.conn.commit()
    
    def update_stock(self, product_id, quantity):
        self.cursor.execute(
            "UPDATE products SET stock = stock + ? WHERE id = ?",
            (quantity, product_id)
        )
        self.conn.commit()
    
    def delete_product(self, product_id):
        self.cursor.execute(
            "DELETE FROM products WHERE id = ?",
            (product_id,)
        )
        self.conn.commit()
    
    def close(self):
        self.conn.close()


# Usage
store = ProductStore()

# Add products
store.add_product("Laptop", 999.99, "Electronics", 10)
store.add_product("Phone", 499.99, "Electronics", 20)
store.add_product("Desk", 299.99, "Furniture", 5)

# Get all electronics under $600
results = store.get_products(category="Electronics", max_price=600)
print("\nElectronics under $600:")
for r in results:
    print(f"  {r[1]}: ${r[2]}")

store.close()
```

-------------------------------------------------------------------------------
6. EXECUTION TRACE
-------------------------------------------------------------------------------

### Trace: SELECT with WHERE

```python
# Query:
cursor.execute("SELECT * FROM products WHERE category = 'Electronics'")

# Step 1: Scan the products table
# Step 2: For each row, check if category = 'Electronics'
# Step 3: Keep only matching rows
# Step 4: Return results

# Example data:
# (1, 'Laptop', 999.99, 'Electronics', 10) → MATCH ✓
# (2, 'Phone', 499.99, 'Electronics', 20) → MATCH ✓
# (3, 'Desk', 299.99, 'Furniture', 5)    → NO MATCH

# Result: [(1, 'Laptop', ...), (2, 'Phone', ...)]
```

### Trace: ORDER BY with LIMIT

```python
# Query:
cursor.execute("SELECT * FROM products ORDER BY price DESC LIMIT 3")

# Step 1: Get all products
# Step 2: Sort by price (highest first)
# Step 3: Take only first 3

# Example:
# All: [299, 149, 999, 499, 79]
# Sorted: [999, 499, 299, 149, 79]
# Limited: [999, 499, 299]
```

-------------------------------------------------------------------------------
7. VISUAL THINKING MODE
-------------------------------------------------------------------------------

### SQL Query Flow

```
┌──────────────┐
│   SELECT     │  ← What columns?
└──────────────┘
       │
       ▼
┌──────────────┐
│     FROM     │  ← Which table?
└──────────────┘
       │
       ▼
┌──────────────┐
│    WHERE     │  ← What conditions?
└──────────────┘
       │
       ▼
┌──────────────┐
│  ORDER BY    │  ← How to sort?
└──────────────┘
       │
       ▼
┌──────────────┐
│    LIMIT     │  ← How many?
└──────────────┘
```

### WHERE Clause Evaluation

```
products table:
┌────┬─────────┬────────┬─────────────┬──────┐
│ id │ name    │ price  │ category    │stock │
├────┼─────────┼────────┼─────────────┼──────┤
│ 1  │ Laptop  │ 999    │ Electronics │ 10   │
│ 2  │ Phone   │ 499    │ Electronics │ 20   │
│ 3  │ Desk    │ 299    │ Furniture   │ 5    │
│ 4  │ Mouse   │ 29     │ Electronics │ 100  │
└────┴─────────┴────────┴─────────────┴──────┘

WHERE category = 'Electronics':
→ Keeps rows where category is 'Electronics'
→ Result: rows 1, 2, 4
```

-------------------------------------------------------------------------------
8. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake 1: Forgetting WHERE in UPDATE/DELETE

```python
# ❌ WRONG - Updates ALL rows!
cursor.execute("UPDATE products SET price = 100")

# ✅ CORRECT - Always specify which rows
cursor.execute("UPDATE products SET price = 100 WHERE id = 1")
```

**Why it happens:** Without WHERE, the operation affects every row.

**Prevention:** Always double-check your WHERE clause.

---

### Common Mistake 2: String Concatenation in SQL

```python
# ❌ WRONG - SQL Injection risk!
name = "Laptop'; DROP TABLE products; --"
cursor.execute(f"SELECT * FROM products WHERE name = '{name}'")

# ✅ CORRECT - Parameterized
cursor.execute("SELECT * FROM products WHERE name = ?", (name,))
```

---

### Common Mistake 3: Column Name Case Sensitivity

```python
# SQLite is flexible but...
cursor.execute("SELECT Name FROM products")  # Works
cursor.execute("SELECT name FROM products")  # Also works

# But stick to lowercase for consistency
```

---

### Common Mistake 4: Using Wrong Comparison

```python
# ❌ WRONG - = is assignment in Python, but = is equality in SQL!
# But in Python's cursor.execute(), this works fine because
# SQL uses = for equality

# Just remember:
# SQL: = (not ==)
# SQL: <> (not !=)
cursor.execute("SELECT * FROM products WHERE price <> 100")
```

-------------------------------------------------------------------------------
9. MEMORY REINFORCEMENT
-------------------------------------------------------------------------------

### Quick Reference

| Operation | SQL Syntax |
|-----------|------------|
| Get all | `SELECT * FROM table` |
| Get specific columns | `SELECT col1, col2 FROM table` |
| Filter | `WHERE column = value` |
| Sort | `ORDER BY column [ASC/DESC]` |
| Limit | `LIMIT number` |
| Update | `UPDATE table SET col = value WHERE condition` |
| Delete | `DELETE FROM table WHERE condition` |

### Operators

| Operator | Meaning |
|----------|---------|
| = | Equal |
| <> or != | Not equal |
| >, < | Greater/Less |
| >=, <= | Greater/Less or equal |
| AND | Both conditions |
| OR | Either condition |
| IN | In a list |
| LIKE | Pattern match |
| BETWEEN | In a range |

### Mnemonic

**"S-F-W-O-L"**
- **S**elect - what to get
- **F**rom - where to get it
- **W**here - filter conditions
- **O**rder - sort results
- **L**imit - how many

-------------------------------------------------------------------------------
10. MINI TEST
-------------------------------------------------------------------------------

### Question 1: Concept Check

**What does `SELECT *` mean?**

> **Answer:** Select all columns from the table. The asterisk (*) is a wildcard meaning "everything".

---

### Question 2: Prediction

**What does this return?**
```python
cursor.execute("SELECT name FROM products WHERE price > 500 ORDER BY price")
```

> **Answer:** Names of products that cost more than $500, sorted from lowest to highest price.

---

### Question 3: Problem Solving

**How would you get only the 3 most expensive products?**

> **Answer:**
> ```python
> SELECT * FROM products ORDER BY price DESC LIMIT 3
> ```

-------------------------------------------------------------------------------
11. LEETCODE PRACTICE
-------------------------------------------------------------------------------

### Problem: Employee Database

Create a simple employee management system:

```python
import sqlite3

class EmployeeDB:
    def __init__(self):
        self.conn = sqlite3.connect('employees.db')
        self.create_table()
    
    def create_table(self):
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department TEXT,
                salary REAL,
                hire_date TEXT
            )
        ''')
        self.conn.commit()
    
    def add_employee(self, name, department, salary, hire_date):
        self.conn.execute(
            "INSERT INTO employees (name, department, salary, hire_date) VALUES (?, ?, ?, ?)",
            (name, department, salary, hire_date)
        )
        self.conn.commit()
    
    def get_employees_by_dept(self, department):
        self.conn.execute(
            "SELECT * FROM employees WHERE department = ?",
            (department,)
        )
        return self.conn.fetchall()
    
    def get_employees_by_salary_range(self, min_sal, max_sal):
        self.conn.execute(
            "SELECT * FROM employees WHERE salary BETWEEN ? AND ?",
            (min_sal, max_sal)
        )
        return self.conn.fetchall()
    
    def get_total_salary_by_dept(self):
        self.conn.execute(
            "SELECT department, SUM(salary) as total FROM employees GROUP BY department"
        )
        return self.conn.fetchall()
    
    def close(self):
        self.conn.close()


# Test
emp_db = EmployeeDB()
emp_db.add_employee("Alice", "Engineering", 80000, "2023-01-15")
emp_db.add_employee("Bob", "Engineering", 90000, "2022-06-01")
emp_db.add_employee("Charlie", "Sales", 60000, "2023-03-20")

print("Engineering employees:")
for e in emp_db.get_employees_by_dept("Engineering"):
    print(f"  {e}")

print("\nSalary between 50000-85000:")
for e in emp_db.get_employees_by_salary_range(50000, 85000):
    print(f"  {e[1]}: ${e[3]}")

emp_db.close()
```

-------------------------------------------------------------------------------
12. BONUS CHALLENGE
-------------------------------------------------------------------------------

### Challenge: Add Aggregate Functions

Add these features to the EmployeeDB:

```python
def get_average_salary(self, department):
    # Return average salary in a department
    pass

def get_employee_count(self):
    # Return total number of employees
    pass

def get_highest_paid(self):
    # Return highest paid employee
    pass
```

**Solution:**
```python
def get_average_salary(self, department):
    self.conn.execute(
        "SELECT AVG(salary) FROM employees WHERE department = ?",
        (department,)
    )
    return self.conn.fetchone()[0]

def get_employee_count(self):
    self.conn.execute("SELECT COUNT(*) FROM employees")
    return self.conn.fetchone()[0]

def get_highest_paid(self):
    self.conn.execute("SELECT * FROM employees ORDER BY salary DESC LIMIT 1")
    return self.conn.fetchone()
```

-------------------------------------------------------------------------------
13. LESSON REFLECTION
-------------------------------------------------------------------------------

### What You Learned Today

1. **SELECT** - Querying data with various filters
2. **WHERE** - Filtering with conditions
3. **ORDER BY** - Sorting results
4. **LIMIT** - Restricting number of results
5. **UPDATE** - Modifying existing data
6. **DELETE** - Removing data

### Key Takeaways

- SQL uses = for equality (not ==)
- WHERE filters rows before returning
- ORDER BY sorts (ASC default, DESC for reverse)
- LIMIT restricts how many rows returned
- Always use parameterized queries

### Next Lesson Preview

**Lesson 95:** SQL JOINs — Combining tables

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 94 / 2000 |
| **Chapter** | 10 (Database) |
| **XP** | 940 |
| **Rank** | Intermediate |
| **Mastery** | SQL Basics |
| **Weaknesses** | Remembering all operators |
| **Recommended Focus** | Practice filtering and sorting |
| **Suggested Review** | Lesson 93 (SQLite) |
| **Next Lesson Readiness** | ✓ Ready for SQL JOINs |

---

**Type 95 to continue**