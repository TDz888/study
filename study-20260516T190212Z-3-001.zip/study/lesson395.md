# Bài 395 — Power of Three (Easy)

## 1. Ôn tập

Từ bài 394, ta đã học Power of Two. Hôm nay ta học **Power of Three**!

## 2. Mục tiêu bài học

- Kiểm tra n có phải power of 3 không
- Base conversion hoặc loop
- O(log n)

## 3. Code chính (có comment)

```python
def is_power_of_three(n):
    """
    Power of Three
    Input: n=27
    Output: True
    """
    if n <= 0:
        return False
    
    while n % 3 == 0:
        n //= 3
    
    return n == 1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 395 / 2000 |
| **Chapter** | Math |
| **XP** | 3950 |