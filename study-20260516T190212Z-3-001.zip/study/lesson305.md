# Bài 305 — Word Break (Medium)

## 1. Ôn tập

Từ bài 304, ta đã học Unique Paths. Hôm nay ta học **Word Break** - DP với string!

## 2. Mục tiêu bài học

- Kiểm tra string có thể split thành words không
- wordDict chứa các words hợp lệ
- dp[i] = True nếu s[:i] break được

## 3. Code chính (có comment)

```python
def word_break(s, word_dict):
    """
    Word Break
    Input: s="leetcode", word_dict=["leet","code"]
    Output: True
    """
    word_set = set(word_dict)
    n = len(s)
    
    # dp[i] = s[:i] có thể break
    dp = [False] * (n + 1)
    dp[0] = True
    
    for i in range(1, n + 1):
        for j in range(i):
            if dp[j] and s[j:i] in word_set:
                dp[i] = True
                break
    
    return dp[n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 305 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3050 |