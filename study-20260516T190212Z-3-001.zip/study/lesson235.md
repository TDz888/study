# Bài 235 — Number of Islands II (Hard)

## 1. Ôn tập

Từ bài 234, ta đã học Union-Find. Hôm nay ta học **Number of Islands II** - dynamic!

## 2. Mục tiêu bài học

- Thêm land cells theo thứ tự
- Track số islands sau mỗi lần thêm
- Dùng Union-Find cho O(α(n)) per operation

## 3. Code chính (có comment)

```python
def num_islands2(m: int, n: int, positions: List[List[int]]) -> List[int]:
    """
    Track số islands sau mỗi lần thêm land
    Input: m=3, n=3, positions=[[0,0],[0,1],[1,2],[2,1]]
    Output: [1,1,2,3]
    """
    parent = {}
    rank = {}
    islands = 0
    directions = [(1,0),(-1,0),(0,1),(0,-1)]
    result = []
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        nonlocal islands
        px, py = find(x), find(y)
        if px == py:
            return
        if rank[px] < rank[py]:
            px, py = py, px
        parent[py] = px
        if rank[px] == rank[py]:
            rank[px] += 1
        islands -= 1
    
    for r, c in positions:
        pos = (r, c)
        parent[pos] = pos
        rank[pos] = 0
        islands += 1
        
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            neighbor = (nr, nc)
            if 0 <= nr < m and 0 <= nc < n and neighbor in parent:
                union(pos, neighbor)
        
        result.append(islands)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 235 / 2000 |
| **Chapter** | Union-Find |
| **XP** | 2350 |