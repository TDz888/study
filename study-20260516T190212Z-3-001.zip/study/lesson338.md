# Bài 338 — Counting Bits (Easy)

## 1. Ôn tập

Từ bài 337, ta đã học Course Schedule II. Hôm nay ta học **Counting Bits**!

## 2. Mục tiêu bài học

- Đếm số 1 bits trong mỗi số từ 0→n
- DP: dp[i] = dp[i & (i-1)] + 1
- Bit manipulation

## 3. Code chính (có comment)

```python
def count_bits(n):
    """
    Counting Bits
    Input: n=5
    Output: [0,1,1,2,1,2]
    """
    result = [0] * (n + 1)
    
    for i in range(1, n + 1):
        # i & (i-1) clear lowest 1 bit
        result[i] = result[i & (i - 1)] + 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 338 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3380 |