# Bài 251 — Longest Univalue Path (Medium)

## 1. Ôn tập

Từ bài 250, ta đã học path sum. Hôm nay ta học **Longest Univalue Path**!

## 2. Mục tiêu bài học

- Tìm path dài nhất với cùng giá trị
- Không nhất thiết qua root
- DFS return length

## 3. Code chính (có comment)

```python
def longest_univalue_path(root: TreeNode) -> int:
    """
    Tìm path dài nhất với cùng giá trị
    Input: root = [1,4,5,4,4,null,5]
    Output: 2 (path: 4->4->4)
    """
    max_length = 0
    
    def dfs(node):
        nonlocal max_length
        if not node:
            return 0
        
        left = dfs(node.left)
        right = dfs(node.right)
        
        # Nếu left cùng giá trị
        if node.left and node.left.val == node.val:
            left += 1
        else:
            left = 0
        
        # Nếu right cùng giá trị
        if node.right and node.right.val == node.val:
            right += 1
        else:
            right = 0
        
        max_length = max(max_length, left + right)
        
        return max(left, right)
    
    dfs(root)
    return max_length
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 251 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2510 |