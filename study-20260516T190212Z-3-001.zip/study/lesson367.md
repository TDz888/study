# Bài 367 — Integer to Roman (Medium)

## 1. Ôn tập

Từ bài 366, ta đã học Reverse Words. Hôm nay ta học **Integer to Roman**!

## 2. Mục tiêu bài học

- Convert integer sang Roman numerals
- Dùng lookup table
- Subtractive notation

## 3. Code chính (có comment)

```python
def int_to_roman(num):
    """
    Integer to Roman
    Input: num=58
    Output: "LVIII"
    """
    values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
    symbols = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I']
    
    result = ''
    for val, sym in zip(values, symbols):
        while num >= val:
            result += sym
            num -= val
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 367 / 2000 |
| **Chapter** | Math |
| **XP** | 3670 |