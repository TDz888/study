# Bài 353 — Move Zeroes (Easy)

## 1. Ôn tập

Từ bài 352, ta đã học Contains Duplicate. Hôm nay ta học **Move Zeroes**!

## 2. Mục tiêu bài học

- Move all zeros to end
- Keep relative order của non-zeros
- In-place

## 3. Code chính (có comment)

```python
def move_zeroes(nums):
    """
    Move Zeroes
    Input: [0,1,0,3,12]
    Output: [1,3,12,0,0]
    """
    insert_pos = 0
    
    for num in nums:
        if num != 0:
            nums[insert_pos] = num
            insert_pos += 1
    
    while insert_pos < len(nums):
        nums[insert_pos] = 0
        insert_pos += 1
    
    return nums
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 353 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3530 |