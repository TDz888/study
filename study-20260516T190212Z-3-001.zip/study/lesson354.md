# Bài 354 — Reverse String (Easy)

## 1. Ôn tập

Từ bài 353, ta đã học Move Zeroes. Hôm nay ta học **Reverse String**!

## 2. Mục tiêu bài học

- Reverse string in-place
- Two pointers từ 2 đầu
- O(n)

## 3. Code chính (có comment)

```python
def reverse_string(s):
    """
    Reverse String
    Input: ['h','e','l','l','o']
    Output: ['o','l','l','e','h']
    """
    left, right = 0, len(s) - 1
    
    while left < right:
        s[left], s[right] = s[right], s[left]
        left += 1
        right -= 1
    
    return s
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 354 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 3540 |