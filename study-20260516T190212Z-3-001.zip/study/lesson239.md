# Bài 239 — Validate Binary Search Tree (Medium)

## 1. Ôn tập

Từ bài 238, ta đã học max path sum. Hôm nay ta học **Validate BST**!

## 2. Mục tiêu bài học

- Kiểm tra tree có phải BST không
- Mỗi node phải trong range (min, max)
- Recursive với bounds

## 3. Code chính (có comment)

```python
def is_valid_bst(root: TreeNode) -> bool:
    """
    Kiểm tra tree có phải BST không
    Input: root = [2,1,3]
    Output: True
    """
    def validate(node, min_val, max_val):
        if not node:
            return True
        
        # Kiểm tra node trong range
        if node.val <= min_val or node.val >= max_val:
            return False
        
        # Recursive với bounds mới
        return validate(node.left, min_val, node.val) and \
               validate(node.right, node.val, max_val)
    
    return validate(root, float('-inf'), float('inf'))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 239 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2390 |