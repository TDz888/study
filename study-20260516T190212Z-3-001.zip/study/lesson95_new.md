# Lesson 95 — SQL Advanced (P2)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 94 - SQL Basics (CRUD operations).

**Current Lesson:** Learning **SQL Advanced** — JOINs, GROUP BY, and aggregate functions.

**Why This Matters:**
- Real databases have multiple related tables
- JOINs let you connect data across tables
- Aggregations help analyze data (totals, averages, counts)
- These are essential for data analysis and reporting

**Connection:**
```
Lesson 94 (Basic SQL) → Lesson 95 (Advanced SQL)
     ↓                        ↓
  SELECT, WHERE          JOIN, GROUP BY
  INSERT, UPDATE         Aggregates, Subqueries
```

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- ORDER BY and LIMIT for sorting and pagination
- INNER JOIN and LEFT JOIN to connect tables
- GROUP BY with aggregate functions (COUNT, SUM, AVG, MAX, MIN)
- HAVING clause for filtering aggregated results

**Real-world analogy:**
- Tables are like separate Excel sheets
- JOIN connects them like VLOOKUP
- GROUP BY is like pivot table
- Aggregates are like calculating totals at the bottom

-------------------------------------------------------------------------------
3. CONCEPT FOUNDATION
-------------------------------------------------------------------------------

### ORDER BY - Sorting Results

ORDER BY sorts results by one or more columns:
- **ASC** = ascending (A→Z, 0→9) - default
- **DESC** = descending (Z→A, 9→0)

```python
# Sort by price, cheapest first (default ASC)
SELECT * FROM products ORDER BY price

# Sort by price, most expensive first
SELECT * FROM products ORDER BY price DESC

# Sort by category, then by price within each category
SELECT * FROM products ORDER BY category, price

# Multiple sort directions
SELECT * FROM products ORDER BY category ASC, price DESC
```

### LIMIT - Restricting Results

LIMIT restricts how many rows are returned:

```python
# Get only first 5 results
SELECT * FROM products LIMIT 5

# Get 5 most expensive products
SELECT * FROM products ORDER BY price DESC LIMIT 5

# OFFSET for pagination (skip first 10, get next 5)
SELECT * FROM products ORDER BY name LIMIT 5 OFFSET 10
```

### JOIN - Connecting Tables

Tables relate through keys:
- **Primary Key** - unique identifier in each table
- **Foreign Key** - references primary key in another table

**INNER JOIN** - returns only matching rows:
```python
# Only users who have orders
SELECT users.name, orders.total
FROM users
INNER JOIN orders ON users.id = orders.user_id
```

**LEFT JOIN** - returns all from left table:
```python
# All users, even those without orders
SELECT users.name, orders.total
FROM users
LEFT JOIN orders ON users.id = orders.user_id
# → No order = NULL
```

### GROUP BY - Grouping Data

GROUP BY groups rows for aggregate calculations:

```python
# Count orders per user
SELECT user_id, COUNT(*) as order_count
FROM orders
GROUP BY user_id

# Sum revenue per category
SELECT category, SUM(revenue) as total
FROM products
GROUP BY category
```

### Aggregate Functions

| Function | Purpose | Example |
|----------|---------|---------|
| COUNT() | Count rows | COUNT(*) |
| SUM() | Add values | SUM(price) |
| AVG() | Average value | AVG(price) |
| MAX() | Highest value | MAX(price) |
| MIN() | Lowest value | MIN(price) |

### HAVING - Filter Aggregated Results

WHERE filters before grouping, HAVING filters after:

```python
# ❌ WRONG - Can't use aggregate in WHERE
SELECT category, COUNT(*) FROM products WHERE COUNT(*) > 5

# ✅ CORRECT - Use HAVING
SELECT category, COUNT(*) as cnt
FROM products
GROUP BY category
HAVING cnt > 5
```

-------------------------------------------------------------------------------
4. TERMINOLOGY EXPLANATION
-------------------------------------------------------------------------------

| Term | Simple Meaning |
|------|----------------|
| **ORDER BY** | Sort results by column(s) |
| **LIMIT** | Restrict number of rows returned |
| **OFFSET** | Skip rows before starting |
| **JOIN** | Connect two tables together |
| **INNER JOIN** | Only matching rows from both tables |
| **LEFT JOIN** | All rows from left table, matches from right |
| **GROUP BY** | Group rows for aggregation |
| **HAVING** | Filter groups (like WHERE but for aggregates) |
| **Aggregate** | Function that summarizes multiple rows |
| **Alias** | Temporary name for column/table |

-------------------------------------------------------------------------------
5. MAIN CODE
-------------------------------------------------------------------------------

### 1. Setting Up Database with Multiple Tables

```python
import sqlite3

# Create connection
conn = sqlite3.connect('shop.db')
cursor = conn.cursor()

# Create users table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
''')

# Create products table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT,
        price REAL NOT NULL,
        stock INTEGER DEFAULT 0
    )
''')

# Create orders table (links users and products)
cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        product_id INTEGER,
        quantity INTEGER,
        total_price REAL,
        order_date TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )
''')

conn.commit()

# Insert sample data
users_data = [
    ('Alice', 'alice@email.com'),
    ('Bob', 'bob@email.com'),
    ('Charlie', 'charlie@email.com'),
    ('Diana', 'diana@email.com')
]
cursor.executemany("INSERT INTO users (name, email) VALUES (?, ?)", users_data)

products_data = [
    ('Laptop', 'Electronics', 999.99, 10),
    ('Phone', 'Electronics', 499.99, 20),
    ('Keyboard', 'Electronics', 79.99, 50),
    ('Desk', 'Furniture', 299.99, 5),
    ('Chair', 'Furniture', 199.99, 8),
    ('Monitor', 'Electronics', 349.99, 15)
]
cursor.executemany(
    "INSERT INTO products (name, category, price, stock) VALUES (?, ?, ?, ?)",
    products_data
)

orders_data = [
    (1, 1, 1, 999.99),      # Alice bought Laptop
    (1, 2, 2, 999.98),      # Alice bought 2 Phones
    (2, 4, 1, 299.99),      # Bob bought Desk
    (3, 6, 1, 349.99),      # Charlie bought Monitor
    (3, 3, 2, 159.98),      # Charlie bought 2 Keyboards
    (4, 5, 1, 199.99)       # Diana bought Chair
]
cursor.executemany(
    "INSERT INTO orders (user_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)",
    orders_data
)

conn.commit()
print("Database setup complete with users, products, and orders!")
```

### 2. ORDER BY and LIMIT Examples

```python
# Get all products sorted by price (cheapest first)
cursor.execute("SELECT * FROM products ORDER BY price")
print("All products by price (ascending):")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[3]:.2f}")

# Get most expensive products first
cursor.execute("SELECT * FROM products ORDER BY price DESC")
print("\nAll products by price (descending):")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[3]:.2f}")

# Get top 3 most expensive products
cursor.execute("SELECT * FROM products ORDER BY price DESC LIMIT 3")
print("\nTop 3 most expensive:")
for p in cursor.fetchall():
    print(f"  {p[1]}: ${p[3]:.2f}")

# Sort by multiple columns (category first, then price)
cursor.execute("SELECT * FROM products ORDER BY category, price")
print("\nBy category, then price:")
for p in cursor.fetchall():
    print(f"  {p[2]}: {p[1]} - ${p[3]:.2f}")

# Pagination: page 1 (first 3)
cursor.execute("SELECT * FROM products ORDER BY name LIMIT 3 OFFSET 0")
print("\nPage 1 (first 3):")
for p in cursor.fetchall():
    print(f"  {p[1]}")

# Pagination: page 2 (next 3)
cursor.execute("SELECT * FROM products ORDER BY name LIMIT 3 OFFSET 3")
print("\nPage 2 (next 3):")
for p in cursor.fetchall():
    print(f"  {p[1]}")
```

### 3. INNER JOIN Examples

```python
# Basic INNER JOIN - get orders with user and product info
cursor.execute('''
    SELECT 
        orders.id,
        users.name as customer,
        products.name as product,
        orders.quantity,
        orders.total_price
    FROM orders
    INNER JOIN users ON orders.user_id = users.id
    INNER JOIN products ON orders.product_id = products.id
''')
print("All orders with customer and product details:")
for row in cursor.fetchall():
    print(f"  Order #{row[0]}: {row[1]} bought {row[2]} x{row[3]} = ${row[4]:.2f}")

# INNER JOIN with WHERE filter
cursor.execute('''
    SELECT users.name, products.name as product, orders.total_price
    FROM orders
    INNER JOIN users ON orders.user_id = users.id
    INNER JOIN products ON orders.product_id = products.id
    WHERE products.category = 'Electronics'
    ORDER BY orders.total_price DESC
''')
print("\nElectronics orders (sorted by price):")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} - ${row[2]:.2f}")

# INNER JOIN - only matching records
# Alice has orders, Bob has order, Charlie has orders, Diana has order
# What if we add a user with NO orders?
cursor.execute("INSERT INTO users (name, email) VALUES ('NewUser', 'new@email.com')")
conn.commit()

# This user won't appear in INNER JOIN (no matching order)
cursor.execute('''
    SELECT users.name, orders.id as order_id
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
''')
print("\nUsers with INNER JOIN (only users with orders):")
for row in cursor.fetchall():
    print(f"  {row[0]} - Order #{row[1]}")
```

### 4. LEFT JOIN Examples

```python
# LEFT JOIN - includes ALL users, even without orders
cursor.execute('''
    SELECT users.name, orders.id as order_id
    FROM users
    LEFT JOIN orders ON users.id = orders.user_id
''')
print("Users with LEFT JOIN (all users):")
for row in cursor.fetchall():
    order_info = f"Order #{row[1]}" if row[1] else "NO ORDER"
    print(f"  {row[0]}: {order_info}")

# LEFT JOIN to find customers without orders
cursor.execute('''
    SELECT users.name
    FROM users
    LEFT JOIN orders ON users.id = orders.user_id
    WHERE orders.id IS NULL
''')
print("\nCustomers without any orders:")
for row in cursor.fetchall():
    print(f"  {row[0]}")

# LEFT JOIN with aggregate
cursor.execute('''
    SELECT 
        users.name,
        COUNT(orders.id) as order_count,
        COALESCE(SUM(orders.total_price), 0) as total_spent
    FROM users
    LEFT JOIN orders ON users.id = orders.user_id
    GROUP BY users.id
''')
print("\nUser spending summary:")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} orders, ${row[2]:.2f} total")
```

### 5. GROUP BY with Aggregates

```python
# COUNT - number of orders per user
cursor.execute('''
    SELECT user_id, COUNT(*) as order_count
    FROM orders
    GROUP BY user_id
''')
print("Orders per user:")
for row in cursor.fetchall():
    print(f"  User {row[0]}: {row[1]} orders")

# SUM - total revenue by product
cursor.execute('''
    SELECT 
        products.name,
        SUM(orders.quantity) as total_sold,
        SUM(orders.total_price) as revenue
    FROM products
    LEFT JOIN orders ON products.id = orders.product_id
    GROUP BY products.id
''')
print("\nRevenue by product:")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} sold, ${row[2]:.2f} revenue")

# AVG - average order value by user
cursor.execute('''
    SELECT 
        users.name,
        AVG(orders.total_price) as avg_order_value
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
    GROUP BY users.id
''')
print("\nAverage order value per user:")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[1]:.2f}")

# MAX/MIN - highest and lowest spending users
cursor.execute('''
    SELECT 
        users.name,
        SUM(orders.total_price) as total_spent
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
    GROUP BY users.id
    ORDER BY total_spent DESC
''')
print("\nUsers sorted by total spending:")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[1]:.2f}")

# GROUP BY with multiple columns
cursor.execute('''
    SELECT 
        category,
        COUNT(*) as product_count,
        AVG(price) as avg_price,
        MAX(price) as max_price,
        MIN(price) as min_price
    FROM products
    GROUP BY category
''')
print("\nProduct statistics by category:")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} products, avg ${row[2]:.2f}, range ${row[4]:.2f}-${row[3]:.2f}")
```

### 6. HAVING - Filter Aggregated Results

```python
# HAVING - filter groups after GROUP BY
# Users who spent more than $500
cursor.execute('''
    SELECT 
        users.name,
        SUM(orders.total_price) as total_spent
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
    GROUP BY users.id
    HAVING total_spent > 500
''')
print("Users who spent more than $500:")
for row in cursor.fetchall():
    print(f"  {row[0]}: ${row[1]:.2f}")

# Categories with more than 2 products
cursor.execute('''
    SELECT category, COUNT(*) as count
    FROM products
    GROUP BY category
    HAVING count > 2
''')
print("\nCategories with more than 2 products:")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} products")

# Products sold more than 1 time
cursor.execute('''
    SELECT 
        products.name,
        SUM(orders.quantity) as total_sold
    FROM products
    INNER JOIN orders ON products.id = orders.product_id
    GROUP BY products.id
    HAVING total_sold > 1
''')
print("\nProducts sold more than once:")
for row in cursor.fetchall():
    print(f"  {row[0]}: {row[1]} units")
```

### 7. Complex Query Example

```python
# Complete analysis: Top customers by category
cursor.execute('''
    SELECT 
        u.name as customer,
        p.category,
        COUNT(o.id) as orders,
        SUM(o.total_price) as spent
    FROM users u
    INNER JOIN orders o ON u.id = o.user_id
    INNER JOIN products p ON o.product_id = p.id
    GROUP BY u.id, p.category
    ORDER BY spent DESC
    LIMIT 10
''')

print("Top 10 customer-category combinations:")
for row in cursor.fetchall():
    print(f"  {row[0]} in {row[1]}: {row[2]} orders, ${row[3]:.2f}")

# Close connection
conn.close()
```

-------------------------------------------------------------------------------
6. EXECUTION TRACE
-------------------------------------------------------------------------------

### Trace: INNER JOIN Execution

```python
# Query:
cursor.execute('''
    SELECT users.name, orders.total_price
    FROM orders
    INNER JOIN users ON orders.user_id = users.id
''')

# Step 1: Start with orders table (FROM orders)
# Step 2: For each order, find matching user (JOIN users ON ...)
# Step 3: Only keep orders where user_id matches a user
# Step 4: Select name and total_price columns

# Orders table:        Users table:
# id | user_id |      id | name
# 1  | 1       |         1 | Alice
# 2  | 1       |         2 | Bob
# 3  | 3       |         3 | Charlie
# 4  | 99      |         (no user 99!)

# Result after INNER JOIN:
# name    | total_price
# Alice   | 999.99
# Alice   | 999.98
# Charlie | 349.99
# (order 4 is dropped - no matching user)
```

### Trace: GROUP BY Execution

```python
# Query:
cursor.execute('''
    SELECT category, COUNT(*) as count
    FROM products
    GROUP BY category
''')

# Step 1: Get all products
# Step 2: Group by category
#   Group "Electronics": Laptop, Phone, Keyboard, Monitor (4)
#   Group "Furniture": Desk, Chair (2)
# Step 3: Apply COUNT to each group
# Step 4: Return category and count

# Result:
# category    | count
# Electronics | 4
# Furniture   | 2
```

### Trace: ORDER BY with LIMIT

```python
# Query:
cursor.execute('''
    SELECT name, price
    FROM products
    ORDER BY price DESC
    LIMIT 2
''')

# Step 1: Get all products
# Step 2: Sort by price descending
#   Before: [999, 499, 349, 299, 199, 79]
#   After:  [999, 499, 349, 299, 199, 79] (already sorted)
# Step 3: Take first 2 rows

# Result:
# name   | price
# Laptop | 999.99
# Phone  | 499.99
```

-------------------------------------------------------------------------------
7. VISUAL THINKING MODE
-------------------------------------------------------------------------------

### SQL Query Order of Execution

```
┌─────────────┐
│    FROM     │  ← Start from table(s)
└─────────────┘
      │
      ▼
┌─────────────┐
│    JOIN     │  ← Connect tables
└─────────────┘
      │
      ▼
┌─────────────┐
│   WHERE     │  ← Filter rows
└─────────────┘
      │
      ▼
┌─────────────┐
│  GROUP BY   │  ← Group rows
└─────────────┘
      │
      ▼
┌─────────────┐
│   HAVING    │  ← Filter groups
└─────────────┘
      │
      ▼
┌─────────────┐
│   SELECT    │  ← Select columns
└─────────────┘
      │
      ▼
┌─────────────┐
│  ORDER BY   │  ← Sort results
└─────────────┘
      │
      ▼
┌─────────────┐
│   LIMIT     │  ← Restrict rows
└─────────────┘
```

### INNER JOIN vs LEFT JOIN

```
INNER JOIN:
┌────────┐     ┌────────┐
│ Users  │     │ Orders │
├────────┤     ├────────┤
│ Alice  │     │ Order1 │
│ Bob    │     │ Order2 │
│ Charlie│     └────────┘
└────────┘
   │
   ▼ ONLY matching rows
┌──────────────┐
│ Alice-Order1 │
│ Alice-Order2 │
└──────────────┘

LEFT JOIN:
┌────────┐     ┌────────┐
│ Users  │     │ Orders │
├────────┤     ├────────┤
│ Alice  │     │ Order1 │
│ Bob    │     │ Order2 │
│ Charlie│     └────────┘
└────────┘
   │
   ▼ ALL from left + matches
┌──────────────┐
│ Alice-Order1 │
│ Alice-Order2 │
│ Bob-NULL     │
│ Charlie-NULL │
└──────────────┘
```

### GROUP BY Flow

```
Products:
┌────┬─────────┬────────┐
│ id │ name    │ cat    │
├────┼─────────┼────────┤
│ 1  │ Laptop  │ Elec   │
│ 2  │ Phone   │ Elec   │
│ 3  │ Desk    │ Furn   │
│ 4  │ Chair   │ Furn   │
│ 5  │ Mouse   │ Elec   │
└────┴─────────┴────────┘

GROUP BY category:
┌──────────┬─────────────────┐
│ Electronics (3)           │
│   Laptop                  │
│   Phone                   │
│   Mouse                   │
├──────────┴─────────────────┤
│ Furniture (2)             │
│   Desk                    │
│   Chair                   │
└───────────────────────────┘

After COUNT(*):
┌──────────┬───────┐
│ Electronics│ 3   │
│ Furniture │ 2   │
└──────────┴───────┘
```

-------------------------------------------------------------------------------
8. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake 1: Using WHERE with Aggregates

```python
# ❌ WRONG - Can't use aggregate in WHERE
cursor.execute("""
    SELECT category, COUNT(*) as cnt
    FROM products
    WHERE COUNT(*) > 2  # This causes an error!
    GROUP BY category
""")

# ✅ CORRECT - Use HAVING for aggregated filters
cursor.execute("""
    SELECT category, COUNT(*) as cnt
    FROM products
    GROUP BY category
    HAVING cnt > 2
""")
```

**Why it happens:** WHERE filters rows BEFORE aggregation. Aggregates are calculated AFTER grouping.

**Prevention:** Use HAVING when filtering on aggregate results.

---

### Common Mistake 2: Forgetting GROUP BY with Aggregate

```python
# ❌ WRONG - No GROUP BY but using aggregate
cursor.execute("""
    SELECT category, MAX(price)  # Missing GROUP BY!
    FROM products
""")

# SQLite might not error, but result is wrong
# ✅ CORRECT - Always GROUP BY non-aggregated columns
cursor.execute("""
    SELECT category, MAX(price) as max_price
    FROM products
    GROUP BY category
""")
```

**Why it happens:** Aggregates collapse multiple rows into one. SQL needs to know which groups to aggregate.

---

### Common Mistake 3: Mixing Up JOIN Types

```python
# Want: All users, even those without orders
# ❌ WRONG - Using INNER JOIN (loses users without orders)
cursor.execute("""
    SELECT users.name, orders.id
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
""")

# ✅ CORRECT - Use LEFT JOIN
cursor.execute("""
    SELECT users.name, orders.id
    FROM users
    LEFT JOIN orders ON users.id = orders.user_id
""")

# LEFT JOIN keeps ALL users, NULL for those without orders
```

---

### Common Mistake 4: ORDER BY Before GROUP BY

```python
# ❌ WRONG - ORDER BY in wrong place
cursor.execute("""
    SELECT category, SUM(price)
    FROM products
    ORDER BY SUM(price) DESC  # Can't order by aggregate here
    GROUP BY category
""")

# ✅ CORRECT - ORDER BY after GROUP BY
cursor.execute("""
    SELECT category, SUM(price) as total
    FROM products
    GROUP BY category
    ORDER BY total DESC
""")
```

---

### Common Mistake 5: Column Alias in WHERE

```python
# ❌ WRONG - Can't use alias in WHERE
cursor.execute("""
    SELECT category, COUNT(*) as cnt
    FROM products
    WHERE cnt > 2  # Alias not available yet!
    GROUP BY category
""")

# ✅ CORRECT - Use HAVING for alias
cursor.execute("""
    SELECT category, COUNT(*) as cnt
    FROM products
    GROUP BY category
    HAVING cnt > 2
""")
```

-------------------------------------------------------------------------------
9. MEMORY REINFORCEMENT
-------------------------------------------------------------------------------

### Quick Reference

| Clause | Purpose | Position |
|--------|---------|-----------|
| FROM | Table source | 1 |
| JOIN | Connect tables | 2 |
| WHERE | Filter rows | 3 |
| GROUP BY | Group rows | 4 |
| HAVING | Filter groups | 5 |
| SELECT | Select columns | 6 |
| ORDER BY | Sort results | 7 |
| LIMIT | Restrict rows | 8 |

### JOIN Types Summary

| Type | Returns |
|------|---------|
| INNER JOIN | Only matching rows from both tables |
| LEFT JOIN | All from left + matches from right |
| RIGHT JOIN | All from right + matches from left (rare) |
| FULL JOIN | All from both tables |

### Aggregate Functions

| Function | Returns |
|----------|---------|
| COUNT(*) | Number of rows |
| SUM(column) | Sum of values |
| AVG(column) | Average value |
| MAX(column) | Highest value |
| MIN(column) | Lowest value |

### Mnemonic

**"F-J-W-G-H-S-O-L"**
- **F**rom - source table
- **J**oin - connect tables
- **W**here - filter rows
- **G**roup by - group data
- **H**aving - filter groups
- **S**elect - choose columns
- **O**rder by - sort
- **L**imit - restrict

-------------------------------------------------------------------------------
10. MINI TEST
-------------------------------------------------------------------------------

### Question 1: Concept Check

**What is the difference between WHERE and HAVING?**

> **Answer:** WHERE filters rows BEFORE grouping. HAVING filters groups AFTER GROUP BY. Use WHERE for regular columns, HAVING for aggregate results.

---

### Question 2: Prediction

**What does this query return?**
```python
cursor.execute("""
    SELECT category, COUNT(*) as cnt
    FROM products
    GROUP BY category
    HAVING cnt > 2
    ORDER BY cnt DESC
""")
```

> **Answer:** Categories with more than 2 products, sorted from highest count to lowest.

---

### Question 3: Problem Solving

**How do you find users who have spent more than $1000 total?**

> **Answer:**
```python
cursor.execute("""
    SELECT users.name, SUM(orders.total_price) as total
    FROM users
    INNER JOIN orders ON users.id = orders.user_id
    GROUP BY users.id
    HAVING total > 1000
""")
```

-------------------------------------------------------------------------------
11. LEETCODE PRACTICE
-------------------------------------------------------------------------------

### Problem: Sales Analysis

Create a sales analysis system that can answer business questions:

```python
import sqlite3

class SalesAnalysis:
    def __init__(self, db_name='sales.db'):
        self.conn = sqlite3.connect(db_name)
        self.setup_database()
    
    def setup_database(self):
        cursor = self.conn.cursor()
        
        # Products table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY,
                name TEXT,
                category TEXT,
                price REAL
            )
        ''')
        
        # Sales table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY,
                product_id INTEGER,
                quantity INTEGER,
                sale_date TEXT
            )
        ''')
        
        # Insert sample data
        products = [
            (1, 'Laptop', 'Electronics', 1000),
            (2, 'Phone', 'Electronics', 500),
            (3, 'Shirt', 'Clothing', 30),
            (4, 'Pants', 'Clothing', 50),
            (5, 'Book', 'Books', 20)
        ]
        
        sales = [
            (1, 1, 2, '2024-01-01'),
            (2, 2, 5, '2024-01-02'),
            (3, 3, 10, '2024-01-03'),
            (4, 1, 1, '2024-01-04'),
            (5, 4, 3, '2024-01-05'),
            (6, 2, 2, '2024-01-06'),
            (7, 5, 20, '2024-01-07')
        ]
        
        cursor.executemany("INSERT INTO products VALUES (?, ?, ?, ?)", products)
        cursor.executemany("INSERT INTO sales VALUES (?, ?, ?, ?)", sales)
        self.conn.commit()
    
    def total_revenue_by_category(self):
        """Calculate total revenue by category"""
        cursor = self.conn.execute('''
            SELECT p.category, 
                   SUM(p.price * s.quantity) as revenue
            FROM products p
            JOIN sales s ON p.id = s.product_id
            GROUP BY p.category
            ORDER BY revenue DESC
        ''')
        return cursor.fetchall()
    
    def top_products(self, n=3):
        """Get top n products by quantity sold"""
        cursor = self.conn.execute('''
            SELECT p.name, SUM(s.quantity) as total_sold
            FROM products p
            JOIN sales s ON p.id = s.product_id
            GROUP BY p.id
            ORDER BY total_sold DESC
            LIMIT ?
        ''', (n,))
        return cursor.fetchall()
    
    def products_by_category(self, category):
        """Get all products in a category with total sales"""
        cursor = self.conn.execute('''
            SELECT p.name, 
                   COALESCE(SUM(s.quantity), 0) as sold
            FROM products p
            LEFT JOIN sales s ON p.id = s.product_id
            WHERE p.category = ?
            GROUP BY p.id
        ''', (category,))
        return cursor.fetchall()
    
    def close(self):
        self.conn.close()


# Usage
analysis = SalesAnalysis()

print("Revenue by category:")
for cat, revenue in analysis.total_revenue_by_category():
    print(f"  {cat}: ${revenue}")

print("\nTop 3 products:")
for name, sold in analysis.top_products(3):
    print(f"  {name}: {sold} sold")

print("\nElectronics products:")
for name, sold in analysis.products_by_category('Electronics'):
    print(f"  {name}: {sold} sold")

analysis.close()
```

**Output:**
```
Revenue by category:
  Electronics: 4500
  Clothing: 450
  Books: 400

Top 3 products:
  Phone: 7 sold
  Shirt: 10 sold
  Book: 20 sold

Electronics products:
  Laptop: 3 sold
  Phone: 7 sold
```

-------------------------------------------------------------------------------
12. BONUS CHALLENGE
-------------------------------------------------------------------------------

### Challenge: Advanced Analytics

Add these methods to the SalesAnalysis class:

```python
def category_stats(self):
    """Return: category, product_count, total_revenue, avg_price"""
    pass

def top_spenders(self, limit=5):
    """Return top customers by total spending"""
    # (This would require a customers table)
    pass

def monthly_revenue(self):
    """Return revenue by month"""
    pass
```

**Solution:**
```python
def category_stats(self):
    cursor = self.conn.execute('''
        SELECT 
            p.category,
            COUNT(DISTINCT p.id) as product_count,
            COALESCE(SUM(p.price * s.quantity), 0) as revenue,
            COALESCE(AVG(p.price), 0) as avg_price
        FROM products p
        LEFT JOIN sales s ON p.id = s.product_id
        GROUP BY p.category
    ''')
    return cursor.fetchall()

def monthly_revenue(self):
    cursor = self.conn.execute('''
        SELECT 
            strftime('%Y-%m', sale_date) as month,
            SUM(p.price * s.quantity) as revenue
        FROM sales s
        JOIN products p ON s.product_id = p.id
        GROUP BY month
        ORDER BY month
    ''')
    return cursor.fetchall()
```

-------------------------------------------------------------------------------
13. LESSON REFLECTION
-------------------------------------------------------------------------------

### What You Learned Today

1. **ORDER BY** - Sorting results (ASC/DESC)
2. **LIMIT/OFFSET** - Restricting and paginating results
3. **INNER JOIN** - Connecting tables (matching rows only)
4. **LEFT JOIN** - Connecting tables (all from left)
5. **GROUP BY** - Grouping data for aggregation
6. **Aggregate functions** - COUNT, SUM, AVG, MAX, MIN
7. **HAVING** - Filtering aggregated results

### Key Takeaways

- JOINs connect separate tables through foreign keys
- GROUP BY must be used when mixing aggregates with regular columns
- WHERE filters before grouping, HAVING filters after
- LEFT JOIN keeps all rows from the left table
- Use COALESCE to handle NULL values

### Next Lesson Preview

**Lesson 96:** Regular Expressions — Pattern matching

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 95 / 2000 |
| **Chapter** | 10 (Database) |
| **XP** | 950 |
| **Rank** | Intermediate |
| **Mastery** | SQL Advanced |
| **Weaknesses** | JOIN types confusion |
| **Recommended Focus** | Practice LEFT JOIN and HAVING |
| **Suggested Review** | Lesson 94 (SQL Basics) |
| **Next Lesson Readiness** | ✓ Ready for Regular Expressions |

---

**Type 96 to continue**