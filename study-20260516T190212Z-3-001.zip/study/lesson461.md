# Bài 461 — Island Perimeter (Easy)

## 1. Ôn tập

Từ bài 460, ta đã học 01 Matrix. Hôm nay ta học **Island Perimeter**!

## 2. Mục tiêu bài học

- Tính perimeter của island
- Count edges với water
- O(m*n)

## 3. Code chính (có comment)

```python
def island_perimeter(grid):
    """
    Island Perimeter
    Input: [[0,1,0,0],[1,1,1,0],[0,1,0,0],[1,1,0,0]]
    Output: 16
    """
    rows, cols = len(grid), len(grid[0])
    perimeter = 0
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 1:
                # Check 4 sides
                if r == 0 or grid[r-1][c] == 0:
                    perimeter += 1
                if r == rows-1 or grid[r+1][c] == 0:
                    perimeter += 1
                if c == 0 or grid[r][c-1] == 0:
                    perimeter += 1
                if c == cols-1 or grid[r][c+1] == 0:
                    perimeter += 1
    
    return perimeter
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 461 / 2000 |
| **Chapter** | DFS/BFS |
| **XP** | 4610 |