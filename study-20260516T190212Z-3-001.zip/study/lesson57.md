# Bài 57 — Type Hints

---

## 1. Ôn tập
Học **Type Hints** — khai báo kiểu dữ liệu.

---

## 2. Mục tiêu
- Basic type hints
- Optional types
- Union types
- Type checking

---

## 3. Basic Type Hints

```python
def greet(name: str) -> str:
    return f"Hello {name}"

def process(items: list[int]) -> int:
    return sum(items)

def get_info(person: dict[str, int]) -> str:
    return f"Age: {person.get('age', 0)}"
```

---

## 4. Optional và Union

```python
from typing import Optional, Union

def find(item: list[int], target: int) -> Optional[int]:
    for i, v in enumerate(item):
        if v == target:
            return i
    return None

def process(value: Union[int, str]) -> str:
    return str(value)
```

---

## 5. Advanced Types

```python
from typing import TypeVar, Generic

T = TypeVar('T')

def first(items: list[T]) -> Optional[T]:
    return items[0] if items else None

# Callable
from typing import Callable
def apply(func: Callable[[int], int], x: int) -> int:
    return func(x)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 57 / 2000 |
| **XP** | 570 |
| **Level** | Advanced |