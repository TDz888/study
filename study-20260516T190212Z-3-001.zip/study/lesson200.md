# Lesson 200 — Final Project: Full-Stack Async API

---

## 1. KNOWLEDGE CONNECTION

Bạn đã học rất nhiều từ bài 1 đến bài 199:
- Python cơ bản → nâng cao
- Async programming
- Web development
- Database
- Testing
- DevOps basics

Hôm nay, bạn sẽ kết hợp TẤT CẢ kiến thức đó vào một project hoàn chỉnh.

**Tại sao bài này tồn tại?**
Vì trong thực tế, không ai viết code đơn lẻ - bạn cần biết cách kết hợp mọi thứ lại với nhau.

---

## 2. TODAY'S MISSION

**Mục tiêu hôm nay:**
Xây dựng hoàn chỉnh một Async REST API với đầy đủ tính năng production-ready.

**Bạn sẽ học được:**
- Cách thiết kế kiến trúc ứng dụng thực tế
- Kết hợp Flask + Async + Database
- Authentication với JWT
- Background workers
- Docker deployment
- CI/CD

**Real-world usage:**
Đây là kiến trúc phổ biến của hầu hết web apps hiện nay.

---

## 3. CONCEPT FOUNDATION

### Kiến trúc tổng quan

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Client    │────▶│  API Server │────▶│  Database   │
└─────────────┘     └─────────────┘     └─────────────┘
                          │
                          ▼
                    ┌─────────────┐
                    │   Workers   │
                    └─────────────┘
```

**Các thành phần:**

| Component | Công nghệ | Vai trò |
|-----------|-----------|---------|
| API Server | Flask + async | Xử lý requests |
| Database | SQLAlchemy async | Lưu trữ data |
| Auth | JWT | Xác thực người dùng |
| Workers | Celery/Background tasks | Xử lý nền |
| Container | Docker | Deployment |

---

## 4. TERMINOLOGY EXPLANATION

- **REST API** (Representational State Transfer) — kiểu thiết kế API phổ biến, sử dụng HTTP methods (GET, POST, PUT, DELETE) để thao tác với tài nguyên
- **JWT** (JSON Web Token) — chuỗi mã hóa chứa thông tin người dùng, dùng để xác thực
- **Async** — lập trình bất đồng bộ, cho phép xử lý nhiều tác vụ cùng lúc mà không chờ
- **Docker** — công cụ đóng gói ứng dụng vào container, giúp deploy dễ dàng
- **CI/CD** (Continuous Integration/Continuous Deployment) — quy trình tự động test và deploy code

---

## 5. MAIN CODE

```python
# main.py
from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, jwt_required, create_access_token
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
import asyncio
from datetime import datetime

# Cấu hình ứng dụng
app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'super-secret-key'
jwt = JWTManager(app)

# Database async
DATABASE_URL = "sqlite+aiosqlite:///db.sqlite"
engine = create_async_engine(DATABASE_URL, echo=True)
async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

# Models
class User:
    id: int
    username: str
    email: str
    created_at: datetime

# Routes
@app.route("/api/v1/health", methods=["GET"])
async def health_check():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "timestamp": datetime.utcnow().isoformat()})

@app.route("/api/v1/auth/login", methods=["POST"])
async def login():
    """Authentication endpoint"""
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    # Validate credentials (mock)
    if username == "admin" and password == "password":
        access_token = create_access_token(identity=username)
        return jsonify({"access_token": access_token}), 200
    
    return jsonify({"error": "Invalid credentials"}), 401

@app.route("/api/v1/resource", methods=["GET"])
@jwt_required()
async def get_resource():
    """Protected endpoint - requires auth"""
    async with async_session() as session:
        # Query database
        result = await session.execute("SELECT * FROM users")
        users = result.fetchall()
        return jsonify({"users": [{"id": u[0], "username": u[1]} for u in users]})

@app.route("/api/v1/resource", methods=["POST"])
@jwt_required()
async def create_resource():
    """Create new resource"""
    data = request.get_json()
    async with async_session() as session:
        await session.execute("INSERT INTO users (username, email) VALUES (?, ?)", 
                             (data.get("username"), data.get("email")))
        await session.commit()
    return jsonify({"message": "Created successfully"}), 201

# Background task (simplified)
async def background_task(task_name: str):
    """Simulate background processing"""
    await asyncio.sleep(2)
    print(f"Task {task_name} completed")

@app.route("/api/v1/tasks", methods=["POST"])
@jwt_required()
async def create_task():
    """Submit background task"""
    data = request.get_json()
    task_name = data.get("task_name")
    asyncio.create_task(background_task(task_name))
    return jsonify({"message": "Task submitted"}), 202

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8000)
```

---

## 6. EXECUTION TRACE

**Khi client gọi `GET /api/v1/resource`:**

1. Flask nhận request từ client
2. `@jwt_required()` decorator kiểm tra JWT token trong header
3. Nếu token hợp lệ → tiếp tục; nếu không → trả về 401
4. `async def get_resource()` được gọi
5. Tạo async session với database
6. Thực hiện SQL query `SELECT * FROM users`
7. Fetch kết quả
8. Convert sang JSON format
9. Trả về response cho client

**Khi client gọi `POST /api/v1/tasks`:**

1. Nhận task_name từ request body
2. Tạo asyncio task mới (`asyncio.create_task`)
3. Task chạy nền, không blocking main thread
4. Trả về 202 "Accepted" ngay lập tức

---

## 7. VISUAL THINKING MODE

```
Request Flow:
────────────

Client Request
      │
      ▼
┌─────────────┐
│  Flask App  │──── JWT Check ───▶ Valid? ──No──▶ 401 Error
└─────────────┘
      │ Yes
      ▼
┌─────────────┐
│   Handler   │
└─────────────┘
      │
      ▼
┌─────────────┐     ┌─────────────┐
│  Async DB  │────▶│  Execute    │
│  Session   │     │   Query     │
└─────────────┘     └─────────────┘
      │
      ▼
┌─────────────┐
│ JSON Output │
└─────────────┘
      │
      ▼
   Client
```

---

## 8. DEBUG THINKING MODE

### Các lỗi thường gặp:

| Lỗi | Nguyên nhân | Cách sửa |
|-----|-------------|----------|
| `RuntimeError: Session closed` | Dùng session sau khi close | Dùng `async with` hoặc `await session.close()` |
| `AttributeError: 'coroutine' object` | Quên `await` async function | Thêm `await` trước async calls |
| 401 Unauthorized | Token hết hạn hoặc sai | Kiểm tra JWT secret và token validity |
| Database lock | Multiple writes đồng thời | Dùng transaction hoặc connection pool |
| `ModuleNotFoundError` | Thiếu import | Import đầy đủ: `from flask import Flask, jsonify` |

### Debugging strategy:

```python
# 1. Kiểm tra imports
import sys
print(sys.modules.keys())

# 2. Kiểm tra async event loop
print(asyncio.get_running_loop())

# 3. Kiểm tra database connection
print(await engine.connect())
```

---

## 9. MEMORY REINFORCEMENT

### Key Concepts

- **Async Flask**: Dùng `async def` cho handlers
- **JWT Auth**: Decorator `@jwt_required()` bảo vệ routes
- **Async DB**: Dùng `AsyncSession` thay vì regular Session
- **Background Tasks**: Dùng `asyncio.create_task()` cho non-blocking tasks
- **Docker**: Containerize ứng dụng để deploy

### Syntax Patterns

```python
# Async route
@app.route("/path")
async def handler():
    await async_operation()
    return jsonify(data)

# Database async
async with async_session() as session:
    await session.execute(query)

# Background task
asyncio.create_task(background_job())
```

### Best Practices

✓ Dùng `async with` cho resource management
✓ Always use timeout cho async operations
✓ Handle exceptions in async code
✓ Use connection pooling
✓ Log important events

---

## 10. MINI TEST

**Câu hỏi 1:** Khi nào nên dùng `asyncio.create_task()`?

**Câu hỏi 2:** Tại sao cần `@jwt_required()` decorator?

**Câu hỏi 3:** Làm sao để tránh "Session closed" error khi dùng async database?

---

## 11. LEETCODE PRACTICE

### Problem: Rate Limiter (Medium)

**Problem Statement:**
Design a rate limiter cho API với:
- Cho phép 3 requests/phút cho mỗi user
- Trả về 429 khi vượt quota

**Starter Code:**

```python
from collections import defaultdict
import time

class RateLimiter:
    def __init__(self, max_requests: int, window_seconds: int):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = defaultdict(list)
    
    def allow_request(self, user_id: str) -> bool:
        # Implement
        pass
```

**Hints:**
- Dùng dictionary lưu timestamp của các requests
- Lọc bỏ requests cũ hơn window
- So sánh số requests còn lại với max_requests

---

## 12. BONUS CHALLENGE

Nếu bạn đã hoàn thành tốt, thử thêm:

1. **Pagination** - Thêm limit/offset cho API responses
2. **Filtering** - Cho phép filter theo fields
3. **Caching** - Dùng Redis cache kết quả
4. **WebSocket** - Thêm real-time updates

---

## 13. LESSON REFLECTION

### Bạn đã học được gì?

- Cách kết hợp Flask + Async + Database
- JWT authentication implementation
- Background task processing
- Docker deployment basics
- CI/CD pipeline

### Điểm mạnh:
- Kiến trúc hoàn chỉnh, production-ready
- Code rõ ràng, dễ mở rộng

### Cần cải thiện:
- Error handling chi tiết hơn
- Logging đầy đủ
- Unit tests cho mỗi component

### Bước tiếp theo:
- Thực hành với FastAPI (framework async chuyên dụng)
- Học thêm về Docker Compose
- Xây dựng project cá nhân

---

## Progress

- **Lesson:** 200 / 2000
- **Chapter:** Advanced Projects
- **XP:** 2000
- **Rank:** Master
- **Mastery:** 100%
- **Weaknesses:** Cần thêm thực hành production deployment
- **Recommended Focus:** Build personal project
- **Suggested Review:** Review all 200 lessons
- **Next Lesson Readiness:** ✅ READY — Bạn đã hoàn thành khóa học!

---

🎉 **CHÚC MỪNG! BẠN ĐÃ HOÀN THÀNH 200 BÀI PYTHON!**

**Next Steps:**
1. Practice với LeetCode
2. Build projects cá nhân
3. Contribute open source
4. Learn frameworks (FastAPI, Django)
5. Explore ML/AI