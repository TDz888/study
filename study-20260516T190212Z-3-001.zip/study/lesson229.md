# Bài 229 — Pacific Atlantic Water Flow (Medium)

## 1. Ôn tập

Từ bài 228, ta đã học topological sort. Hôm nay ta học **Pacific Atlantic** - nước chảy được!

## 2. Mục tiêu bài học

- Tìm cells mà nước chảy được đến cả hai oceans
- Reverse thinking: từ ocean vào trong
- Multi-source BFS

## 3. Code chính (có comment)

```python
def pacific_atlantic(heights: List[List[int]]) -> List[List[int]]:
    """
    Tìm cells mà nước chảy được đến cả hai oceans
    Input: heights=[[1,2,2,3,5],[3,2,3,4,4],[2,4,5,3,1],[5,4,3,2,1],[1,1,2,4,3]]
    Output: [[0,4],[1,3],[1,4],[2,2],[3,0],[3,1],[4,0]]
    """
    if not heights:
        return []
    
    rows, cols = len(heights), len(heights[0])
    
    # Tìm cells chảy được đến Pacific (hàng trên, cột trái)
    pacific = bfs_from_edge(heights, 0, 0, "pacific")
    
    # Tìm cells chảy được đến Atlantic (hàng dưới, cột phải)
    atlantic = bfs_from_edge(heights, rows-1, cols-1, "atlantic")
    
    # Intersection
    result = []
    for r in range(rows):
        for c in range(cols):
            if pacific[r][c] and atlantic[r][c]:
                result.append([r, c])
    
    return result

def bfs_from_edge(heights, start_r, start_c, ocean):
    rows, cols = len(heights), len(heights[0])
    visited = [[False]*cols for _ in range(rows)]
    queue = []
    
    # Add all edge cells
    for r in range(rows):
        queue.append((r, 0))
        visited[r][0] = True
    for c in range(1, cols):
        queue.append((0, c))
        visited[0][c] = True
    
    while queue:
        r, c = queue.pop(0)
        
        for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and not visited[nr][nc]:
                # Nước chảy được nếu cao hơn hoặc bằng
                if heights[nr][nc] >= heights[r][c]:
                    visited[nr][nc] = True
                    queue.append((nr, nc))
    
    return visited
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 229 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2290 |