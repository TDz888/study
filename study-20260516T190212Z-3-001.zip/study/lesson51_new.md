# Lesson 51 — Working with CSV

-------------------------------------------------------------------------------
1. TODAY'S MISSION
-------------------------------------------------------------------------------

Read and write CSV files using csv module.

-------------------------------------------------------------------------------
2. MAIN CODE
-------------------------------------------------------------------------------

```python
import csv

# Writing
with open("data.csv", "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Age"])
    writer.writerow(["Minh", 25])
    writer.writerow(["Lan", 30])

# Reading
with open("data.csv", "r") as f:
    reader = csv.reader(f)
    for row in reader:
        print(row)

# With DictReader/Writer
with open("data.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["Name"], row["Age"])
```

---

**Lesson 52 — JSON Deep Dive**

```python
import json

data = {"users": [{"name": "Minh", "scores": [90, 80]}]}
# Pretty print
print(json.dumps(data, indent=2))
```

---

**Lesson 53 — Pickle (Binary Serialization)**

```python
import pickle

data = {"key": "value"}
with open("data.pkl", "wb") as f:
    pickle.dump(data, f)

with open("data.pkl", "rb") as f:
    loaded = pickle.load(f)
```

---

**Lesson 54 — SQLite Database**

```python
import sqlite3

conn = sqlite3.connect("test.db")
c = conn.cursor()
c.execute("CREATE TABLE users (name TEXT, age INTEGER)")
c.execute("INSERT INTO users VALUES ('Minh', 25)")
conn.commit()

c.execute("SELECT * FROM users")
print(c.fetchall())
conn.close()
```

---

**Lessons 55-60:** OOP patterns, threading, multiprocessing, logging, unit testing basics, virtual environments

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 51-60 / 2000 |
| **XP** | 510-600 |

Type **61** to continue