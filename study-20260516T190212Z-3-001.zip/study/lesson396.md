# Bài 396 — Power of Four (Easy)

## 1. Ôn tập

Từ bài 395, ta đã học Power of Three. Hôm nay ta học **Power of Four**!

## 2. Mục tiêu bài học

- Kiểm tra n có phải power of 4 không
- Bit manipulation với pattern
- O(1)

## 3. Code chính (có comment)

```python
def is_power_of_four(n):
    """
    Power of Four
    Input: n=16
    Output: True
    """
    if n <= 0:
        return False
    
    # Power of 4: single 1 bit in even position
    return n & (n - 1) == 0 and n & 0x55555555 != 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 396 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3960 |