# Bài 103 — Working with Excel

---

## 1. openpyxl

```python
# pip install openpyxl
from openpyxl import Workbook, load_workbook

# Tạo workbook
wb = Workbook()
ws = wb.active
ws['A1'] = 'Name'
ws['B1'] = 'Age'
ws['A2'] = 'Alice'
ws['B2'] = 25
wb.save('data.xlsx')

# Đọc workbook
wb = load_workbook('data.xlsx')
ws = wb.active
print(ws['A1'].value)
```

---

## 2. pandas với Excel

```python
import pandas as pd

# Đọc Excel
df = pd.read_excel('data.xlsx')

# Ghi Excel
df.to_excel('output.xlsx', index=False)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 103 / 2000 |
| **XP** | 1030 |
| **Level** | Intermediate |