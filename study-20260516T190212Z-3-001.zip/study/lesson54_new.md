# Lesson 54 — Iterators

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 53 - Generators.

**Current Lesson:** Learning **Iterators** — the protocol for traversing data.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Iterator protocol (__iter__, __next__)
- Custom iterator implementation
- itertools module

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Custom Iterator

```python
class Counter:
    def __init__(self, limit):
        self.limit = limit
        self.current = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.current < self.limit:
            val = self.current
            self.current += 1
            return val
        raise StopIteration

for i in Counter(5):
    print(i, end=" ")  # 0 1 2 3 4
```

### itertools

```python
import itertools

# Count - infinite counter
for i in itertools.count(5):
    if i > 7: break
    print(i, end=" ")  # 5 6 7

# Cycle - repeat infinitely
c = itertools.cycle([1, 2])
print(next(c), next(c), next(c))  # 1 2 1

# Chain - combine iterables
print(list(itertools.chain([1,2], [3,4])))  # [1,2,3,4]

# Accumulate - cumulative sum
print(list(itertools.accumulate([1,2,3,4])))  # [1,3,6,10]
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What methods must a class implement to be an iterator?**

> **Answer:** __iter__() and __next__()

---

**Type 55 to continue**