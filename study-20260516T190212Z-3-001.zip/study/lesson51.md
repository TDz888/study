# Bài 51 — Advanced List Operations

---

## 1. Ôn tập
Bài 50 đã học tổng hợp. Giờ học các **thao tác nâng cao** với List.

---

## 2. Mục tiêu bài học
- List slicing nâng cao
- List comprehension lồng nhau
- Filter, map, reduce
- Unpacking

---

## 3. Slicing nâng cao

```python
lst = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Reverse
print(lst[::-1])  # [9,8,7,6,5,4,3,2,1,0]

# Bước nhảy âm
print(lst[::-2])  # [9,7,5,3,1]

# Lấy từ vị trí đến cuối
print(lst[5:])  # [5,6,7,8,9]

# Lấy từ đầu đến vị trí
print(lst[:5])  # [0,1,2,3,4]

# Đảo ngược một phần
print(lst[5:8][::-1])  # [7,6,5]
```

---

## 4. List Comprehension lồng nhau

```python
# Ma trận 3x3
matrix = [[i*3+j for j in range(3)] for i in range(3)]
print(matrix)  # [[0,1,2], [3,4,5], [6,7,8]]

# Flatten ma trận
flat = [x for row in matrix for x in row]
print(flat)  # [0,1,2,3,4,5,6,7,8]

# Lọc và biến đổi
result = [x**2 for row in matrix for x in row if x % 2 == 0]
print(result)  # [0,4,16,36,64]
```

---

## 5. Filter, Map, Reduce

```python
from functools import reduce

nums = [1, 2, 3, 4, 5]

# Map - biến đổi
squares = list(map(lambda x: x**2, nums))
print(squares)  # [1,4,9,16,25]

# Filter - lọc
evens = list(filter(lambda x: x % 2 == 0, nums))
print(evens)  # [2,4]

# Reduce - gộp
product = reduce(lambda x, y: x * y, nums)
print(product)  # 120
```

---

## 6. Unpacking

```python
# Unpacking list
a, b, c = [1, 2, 3]
print(a, b, c)  # 1 2 3

# *rest
first, *middle, last = [1, 2, 3, 4, 5]
print(first, middle, last)  # 1 [2,3,4] 5

# Zip - ghép nhiều list
names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]
combined = list(zip(names, ages))
print(combined)  # [('Alice',25), ('Bob',30), ('Charlie',35)]
```

---

## 7. Debug

```python
# Lỗi thường: thay đổi list khi iterate
lst = [1, 2, 3, 4, 5]
for x in lst:
    if x % 2 == 0:
        lst.remove(x)  # Lỗi! Thay đổi list khi iterate
# → Dùng list comprehension thay thế
lst = [x for x in lst if x % 2 != 0]
```

---

## 8. LeetCode Practice

### Flatten List
```python
# Input: [[1,2], [3,4], [5]]
# Output: [1,2,3,4,5]
nested = [[1,2], [3,4], [5]]
flat = [x for row in nested for x in row]
print(flat)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 51 / 2000 |
| **XP** | 510 |
| **Level** | Intermediate |