# Bài 258 — Preorder Traversal (Easy)

## 1. Ôn tập

Từ bài 257, ta đã học Inorder. Hôm nay ta học **Preorder Traversal** - duyệt trước root!

## 2. Mục tiêu bài học

- Duyệt: Root → Left → Right
- Dùng để clone cây, prefix expression
- Luôn visit root trước

## 3. Code chính (có comment)

```python
def preorder_traversal(root: TreeNode) -> list:
    """
    Preorder: Root → Left → Right
    Input: root = [1,2,3,None,4]
    Output: [1,2,4,3]
    """
    result = []
    
    def traverse(node):
        if not node:
            return
        # 1. Visit root TRƯỚC
        result.append(node.val)
        # 2. Duyệt cây con bên trái
        traverse(node.left)
        # 3. Duyệt cây con bên phải
        traverse(node.right)
    
    traverse(root)
    return result
```

## 4. Quy trình duyệt

```
       4
      / \
     2   6
    / \ / \
   1  3 5  7

Preorder: 4 → 2 → 1 → 3 → 6 → 5 → 7
```

## 5. Ứng dụng

| Ứng dụng | Mô tả |
|----------|-------|
| **Clone cây** | Tạo bản sao cây |
| **Serialize** | Lưu cây thành chuỗi |
| **Prefix expression** | Tính biểu thức toán |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 258 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2580 |