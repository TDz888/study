# Bài 335 — Jump Game (Medium)

## 1. Ôn tập

Từ bài 334, ta đã học Spiral Matrix. Hôm nay ta học **Jump Game**!

## 2. Mục tiêu bài học

- Kiểm tra có thể reach end không
- Greedy: track farthest reachable
- O(n) time

## 3. Code chính (có comment)

```python
def can_jump(nums):
    """
    Jump Game
    Input: [2,3,1,1,4]
    Output: True
    """
    farthest = 0
    
    for i, jump in enumerate(nums):
        if i > farthest:
            return False
        farthest = max(farthest, i + jump)
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 335 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3350 |