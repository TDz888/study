# Lesson 87 — Design Patterns (Creational)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 86 - Object-Oriented Design.

**Current Lesson:** Learning **Creational Design Patterns**.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Singleton pattern
- Factory pattern

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Singleton

```python
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

s1 = Singleton()
s2 = Singleton()
print(s1 is s2)  # True
```

### Factory

```python
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "Woof"

class Cat(Animal):
    def speak(self):
        return "Meow"

class AnimalFactory:
    def create_animal(self, animal_type):
        animals = {"dog": Dog, "cat": Cat}
        return animals[animal_type]()

factory = AnimalFactory()
dog = factory.create_animal("dog")
print(dog.speak())  # Woof
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does Singleton ensure?**

> **Answer:** Only one instance exists

---

**Type 88 to continue**