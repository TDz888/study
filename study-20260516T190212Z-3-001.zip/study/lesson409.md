# Bài 409 — Delete Node in BST (Medium)

## 1. Ôn tập

Từ bài 408, ta đã học Postorder Traversal. Hôm nay ta học **Delete Node in BST**!

## 2. Mục tiêu bài học

- Delete node trong BST
- Handle 3 cases: leaf, one child, two children
- Replace với inorder successor

## 3. Code chính (có comment)

```python
def delete_node(root, key):
    """
    Delete Node in BST
    Input: root, key
    Output: Tree sau khi delete
    """
    if not root:
        return None
    
    if key < root.val:
        root.left = delete_node(root.left, key)
    elif key > root.val:
        root.right = delete_node(root.right, key)
    else:
        # Found node
        if not root.left:
            return root.right
        if not root.right:
            return root.left
        
        # Two children: get inorder successor
        successor = root.right
        while successor.left:
            successor = successor.left
        root.val = successor.val
        root.right = delete_node(root.right, successor.val)
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 409 / 2000 |
| **Chapter** | Trees |
| **XP** | 4090 |