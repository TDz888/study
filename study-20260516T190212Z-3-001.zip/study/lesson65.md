# Bài 65 — Logging

---

## 1. Ôn tập
Học về **Logging** trong Python.

---

## 2. Mục tiêu
- logging module
- Log levels
- Formatters
- Handlers

---

## 3. Logging cơ bản

```python
import logging

# Cấu hình logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Log messages
logging.debug("Debug message")
logging.info("Info message")
logging.warning("Warning message")
logging.error("Error message")
logging.critical("Critical message")
```

---

## 4. Logger riêng

```python
# Tạo logger riêng
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# File handler
fh = logging.FileHandler('app.log')
fh.setLevel(logging.INFO)

# Formatter
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)

logger.addHandler(fh)

logger.info("This will be logged to file")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 65 / 2000 |
| **XP** | 650 |
| **Level** | Intermediate |