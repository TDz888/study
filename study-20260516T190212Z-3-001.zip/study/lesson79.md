# Bài 79 — Trees (P1)

---

## 1. Ôn tập
Học về **Trees** — cấu trúc cây.

---

## 2. Binary Tree

```python
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

# Tạo cây
root = TreeNode(1)
root.left = TreeNode(2)
root.right = TreeNode(3)
root.left.left = TreeNode(4)
root.left.right = TreeNode(5)
```

---

## 3. Tree Traversals

```python
# Inorder: Left -> Root -> Right
def inorder(root):
    if root:
        inorder(root.left)
        print(root.val, end=' ')
        inorder(root.right)

# Preorder: Root -> Left -> Right
def preorder(root):
    if root:
        print(root.val, end=' ')
        preorder(root.left)
        preorder(root.right)

# Postorder: Left -> Right -> Root
def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.val, end=' ')
```

---

## 4. Level Order (BFS)

```python
from collections import deque

def level_order(root):
    if not root:
        return
    
    queue = deque([root])
    while queue:
        node = queue.popleft()
        print(node.val, end=' ')
        
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 79 / 2000 |
| **XP** | 790 |
| **Level** | Advanced |