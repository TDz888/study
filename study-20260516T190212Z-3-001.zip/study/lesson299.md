# Bài 299 — Path Sum (Easy)

## 1. Ôn tập

Từ bài 298, ta đã học Symmetric Tree. Hôm nay ta học **kiểm tra path sum**!

## 2. Mục tiêu bài học

- Tìm path từ root đến leaf có sum = target
- Giảm target theo mỗi node
- Base case: leaf node

## 3. Code chính (có comment)

```python
def has_path_sum(root, target):
    """
    Kiểm tra có path với sum = target không
    Input: root, target sum
    Output: True/False
    """
    if not root:
        return False
    
    # Nếu là leaf và bằng target
    if not root.left and not root.right:
        return root.val == target
    
    # Recurse vào children với reduced target
    return (has_path_sum(root.left, target - root.val) or
            has_path_sum(root.right, target - root.val))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 299 / 2000 |
| **Chapter** | Trees |
| **XP** | 2990 |