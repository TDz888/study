# Bài 274 — Graph Introduction (Easy)

## 1. Ôn tập

Từ bài 273, ta đã học AVL Insert. Hôm nay ta bắt đầu **Graph** - cấu trúc dữ liệu mới!

## 2. Mục tiêu bài học

- Graph: tập hợp các đỉnh (vertices) và các cạnh (edges)
- Directed vs Undirected
- Weighted vs Unweighted

## 3. Các khái niệm cơ bản

| Khái niệm | Mô tả |
|-----------|-------|
| **Vertex (V)** | Đỉnh/Node |
| **Edge (E)** | Cạnh nối 2 đỉnh |
| **Degree** | Số cạnh kề với đỉnh |
| **Path** | Chuỗi các đỉnh nối nhau |
| **Cycle** | Path quay về điểm bắt đầu |

## 4. Biểu diễn Graph

```python
# Adjacency List (dùng nhiều nhất)
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D'],
    'C': ['A', 'D'],
    'D': ['B', 'C']
}

# Adjacency Matrix
#    A  B  C  D
# A  0  1  1  0
# B  1  0  0  1
# C  1  0  0  1
# D  0  1  1  0
```

## 5. Minh họa

```
    A
   / \
  B---C
   \ /
    D

Undirected Graph với 4 đỉnh, 4 cạnh
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 274 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2740 |