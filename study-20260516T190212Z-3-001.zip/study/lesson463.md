# Bài 463 — Squares of Sorted Array (Easy)

## 1. Ôn tập

Từ bài 462, ta đã học Merge Sorted Array. Hôm nay ta học **Squares of Sorted Array**!

## 2. Mục tiêu bài học

- Square mỗi element và sort
- Two pointers từ 2 đầu
- O(n)

## 3. Code chính (có comment)

```python
def sorted_squares(nums):
    """
    Squares of Sorted Array
    Input: [-4,-1,0,3,10]
    Output: [0,1,9,16,100]
    """
    n = len(nums)
    result = [0] * n
    left, right = 0, n - 1
    pos = n - 1
    
    while left <= right:
        if abs(nums[left]) > abs(nums[right]):
            result[pos] = nums[left] * nums[left]
            left += 1
        else:
            result[pos] = nums[right] * nums[right]
            right -= 1
        pos -= 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 463 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 4630 |