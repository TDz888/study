# Bài 176 — Iterator Protocol

## 1. Ôn tập

Generator là một loại iterator. Hôm nay ta học Iterator Protocol - cách tự tạo iterator cho class riêng!

## 2. Mục tiêu bài học

- Hiểu `__iter__` và `__next__`
- Tự tạo iterator cho custom class
- Phân biệt iterable và iterator

## 3. Code chính (có comment)

```python
# Iterator Protocol:
# 1. __iter__() → trả về chính object (self)
# 2. __next__() → trả về phần tử tiếp theo hoặc raise StopIteration

class Counter:
    """Iterator đếm số"""
    
    def __init__(self, start, end):
        self.current = start
        self.end = end
    
    def __iter__(self):
        return self  # Self là iterator
    
    def __next__(self):
        if self.current >= self.end:
            raise StopIteration
        value = self.current
        self.current += 1
        return value

# Dùng như generator!
for i in Counter(0, 5):
    print(i)  # 0, 1, 2, 3, 4

# Hoặc dùng next()
counter = Counter(10, 13)
print(next(counter))  # 10
print(next(counter))  # 11
print(next(counter))  # 12
# next(counter) → StopIteration
```

## 4. Trace chạy code

```
0
1
2
3
4
10
11
12
```

## 5. Debug tư duy

### Iterable vs Iterator
```python
# List là iterable - CÓ __iter__
lst = [1, 2, 3]
print(iter(lst))  # <list_iterator>

# Iterator là object được tạo từ iterable
# Generator vừa là iterable VỪA là iterator
```

### Mẹo: Iterator exhaustion
```python
it = Counter(0, 3)
list(it)  # [0, 1, 2]
list(it)  # [] - đã hết!
```

## 6. Ghi nhớ nhanh

| Method | Vai trò |
|--------|---------|
| `__iter__` | Trả về iterator |
| `__next__` | Lấy phần tử tiếp |
| `StopIteration` | Báo hết |

## 7. Mini test (3 câu)

**Câu 1:** Để class trở thành iterator cần gì?
- A) __start__
- B) __iter__ và __next__
- C) __call__
- D) __enter__

**Câu 2:** Khi hết phần tử, __next__ phải làm gì?
- A) Return None
- B) Raise StopIteration
- C) Return False
- D) Pass

**Câu 3:** List là gì?
- A) Iterator
- B) Iterable
- C) Generator
- D) Class

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Range Iterator"

```python
class RangeIterator:
    """Tương tự range()"""
    def __init__(self, start, stop):
        # Viết code
        pass
```

## 9. Bonus

Tạo:
- Alphabet iterator
- Fibonacci iterator
- File line iterator

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 176 / 2000 |
| **XP** | 1760 |