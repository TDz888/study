# Bài 318 — Word Search (Medium)

## 1. Ôn tập

Từ bài 317, ta đã học Remove Duplicates II. Hôm nay ta học **Word Search**!

## 2. Mục tiêu bài học

- Tìm word trong board (2D grid)
- DFS với backtracking
- Mark visited cells

## 3. Code chính (có comment)

```python
def exist(board, word):
    """
    Word Search
    Input: board=[[A,B],[C,D]], word="ABD"
    Output: True
    """
    rows, cols = len(board), len(board[0])
    
    def dfs(r, c, index):
        # Found complete word
        if index == len(word):
            return True
        
        # Out of bounds hoặc không match
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return False
        if board[r][c] != word[index]:
            return False
        
        # Mark visited
        temp = board[r][c]
        board[r][c] = '#'
        
        # Explore 4 directions
        found = (dfs(r+1, c, index+1) or
                 dfs(r-1, c, index+1) or
                 dfs(r, c+1, index+1) or
                 dfs(r, c-1, index+1))
        
        # Unmark
        board[r][c] = temp
        return found
    
    # Try từ mọi cell
    for r in range(rows):
        for c in range(cols):
            if dfs(r, c, 0):
                return True
    
    return False
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 318 / 2000 |
| **Chapter** | DFS/BFS |
| **XP** | 3180 |