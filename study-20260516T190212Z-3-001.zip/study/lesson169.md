# Bài 169 — Task Cancellation

## 1. Ôn tập

Ta đã học cách tạo task với `create_task`. Nhưng nếu cần DỪNG một task đang chạy thì sao?

## 2. Mục tiêu bài học

- Hiểu cancellation trong asyncio
- Dùng `asyncio.CancelledError`
- Xử lý graceful shutdown

## 3. Code chính (có comment)

```python
import asyncio

async def long_task(task_id):
    """Task chạy lâu - có thể bị cancel"""
    print(f"Task {task_id}: Bắt đầu")
    try:
        for i in range(10):
            await asyncio.sleep(0.5)
            print(f"Task {task_id}: Step {i}")
        print(f"Task {task_id}: Hoàn thành!")
        return f"Result {task_id}"
    except asyncio.CancelledError:
        print(f"Task {task_id}: Bị cancel!")
        # Cleanup nếu cần
        raise

async def main():
    # Tạo task
    task = asyncio.create_task(long_task(1))
    
    # Đợi 1.5 giây rồi cancel
    await asyncio.sleep(1.5)
    print("Cancel task!")
    task.cancel()
    
    # Đợi cho cancellation hoàn thành
    try:
        await task
    except asyncio.CancelledError:
        print("Task đã được cancel!")

asyncio.run(main())
```

## 4. Trace chạy code

```
Task 1: Bắt đầu
Task 1: Step 0
Task 1: Step 1
Cancel task!
Task 1: Bị cancel!
Task đã được cancel!
```

## 5. Debug tư duy

### Xử lý graceful cancellation
```python
async def graceful_task():
    try:
        while True:
            await asyncio.sleep(1)
    except asyncio.CancelledError:
        # Cleanup trước khi exit
        await cleanup()
        print("Cleaned up!")
        raise  # Re-raise để asyncio biết đã xử lý
```

### Timeout as cancellation
```python
async def with_timeout():
    try:
        await asyncio.wait_for(long_task(), timeout=2.0)
    except asyncio.TimeoutError:
        print("Timeout!")
```

### Shield - tránh bị cancel
```python
async def protected_task():
    # Task này KHÔNG bị cancel từ bên ngoài
    result = await asyncio.shield(some_task())
```

## 6. Ghi nhớ nhanh

| Phương thức | Công dụng |
|-------------|-----------|
| `task.cancel()` | Yêu cầu cancel task |
| `CancelledError` | Exception khi task bị cancel |
| `wait_for(task)` | Timeout cho task |
| `shield(task)` | Bảo vệ task khỏi bị cancel |

## 7. Mini test (3 câu)

**Câu 1:** Khi gọi task.cancel(), điều gì xảy ra?
- A) Task dừng ngay lập tức
- B) Gửi yêu cầu cancel, chờ cleanup
- C) Xóa task
- D) Chạy task từ đầu

**Câu 2:** Shield dùng để làm gì?
- A) Tăng tốc task
- B) Bảo vệ task khỏi bị cancel
- C) Tạo task mới
- D) Join task

**Câu 3:** CancelledError cần làm gì?
- A) Bỏ qua
- B) Cleanup rồi re-raise
- C) Return giá trị
- D) Pass

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Task Manager với Cancel"

```python
class TaskManager:
    def __init__(self):
        self.tasks = {}
    
    async def add(self, name, coro):
        task = asyncio.create_task(coro)
        self.tasks[name] = task
        return task
    
    async def cancel(self, name):
        if name in self.tasks:
            self.tasks[name].cancel()
    
    async def cancel_all(self):
        for task in self.tasks.values():
            task.cancel()
```

## 9. Bonus

Tạo:
- Worker pool với graceful shutdown
- Cancel tất cả workers khi có signal
- Đợi cleanup hoàn thành trước khi exit

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 169 / 2000 |
| **XP** | 1690 |