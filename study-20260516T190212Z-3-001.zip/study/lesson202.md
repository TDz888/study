# Bài 202 — LeetCode: Valid Palindrome (Easy)

## 1. Ôn tập

Từ bài 201, ta đã học Two Sum với hash table. Hôm nay ta học Palindrome - dùng Two Pointers!

## 2. Mục tiêu bài học

- Kiểm tra chuỗi có đối xứng không
- Two Pointers technique
- Xử lý ký tự đặc biệt

## 3. Code chính (có comment)

```python
def is_palindrome(s: str) -> bool:
    """
    Kiểm tra chuỗi có phải palindrome không
    Bỏ qua ký tự đặc biệt, không phân biệt hoa thường
    
    Input: "A man, a plan, a canal: Panama"
    Output: True
    """
    # Two pointers
    left, right = 0, len(s) - 1
    
    while left < right:
        # Skip ký tự không phải chữ/số
        while left < right and not s[left].isalnum():
            left += 1
        while left < right and not s[right].isalnum():
            right -= 1
        
        # So sánh (ignore case)
        if s[left].lower() != s[right].lower():
            return False
        
        left += 1
        right -= 1
    
    return True

# Test
print(is_palindrome("A man, a plan, a canal: Panama"))  # True
print(is_palindrome("race a car"))  # False
print(is_palindrome(" "))  # True (empty)
```

## 4. Trace chạy code

```
s = "A man, a plan, a canal: Panama"
left=0: 'A', right=30: 'a' → equal → left++, right--
left=1: ' ', skip → left=2
left=2: 'm', right=28: 'n' → equal → continue
...tiếp tục...
Kết quả: True
```

## 5. Debug tư duy

### Cần .isalnum() để bỏ khoảng trắng và punctuation!
```python
# Sai: Không bỏ ký tự đặc biệt
if s[left] != s[right]:  # Sẽ fail!

# Đúng: Skip non-alphanumeric
while left < right and not s[left].isalnum():
    left += 1
```

### Lowercase để so sánh ignore case!
```python
# Sai: Phân biệt hoa thường
if s[left] != s[right]:

# Đúng: Ignore case  
if s[left].lower() != s[right].lower():
```

## 6. Ghi nhớ nhanh

| Technique | Time | Space |
|-----------|------|-------|
| Two Pointers | O(n) | O(1) |
| Reverse String | O(n) | O(n) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 202 / 2000 |
| **XP** | 2020 |