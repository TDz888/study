# Bài 270 — Lowest Common Ancestor (Medium)

## 1. Ôn tập

Từ bài 269, ta đã học tạo BST từ array. Hôm nay ta học **tìm tổ tiên chung thấp nhất**!

## 2. Mục tiêu bài học

- Tìm node cao nhất (gần root nhất) là tổ tiên của cả 2 node
- Dùng BST property để tìm nhanh
- O(log n) cho BST

## 3. Code chính (có comment)

```python
def lowest_common_ancestor_bst(root: TreeNode, p: TreeNode, q: TreeNode) -> TreeNode:
    """
    Tìm LCA trong BST
    Input: root = [6,2,8,0,4,7,9,3,5], p = 2, q = 8
    Output: 6
    """
    # Root lớn hơn cả p và q → LCA ở bên trái
    if root.val > p.val and root.val > q.val:
        return lowest_common_ancestor_bst(root.left, p, q)
    
    # Root nhỏ hơn cả p và q → LCA ở bên phải
    if root.val < p.val and root.val < q.val:
        return lowest_common_ancestor_bst(root.right, p, q)
    
    # Root nằm giữa p và q → chính là LCA
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 270 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2700 |