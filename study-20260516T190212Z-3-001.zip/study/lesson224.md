# Bài 224 — Max Area of Island (Medium)

## 1. Ôn tập

Từ bài 223, ta đã học đếm islands. Hôm nay ta học tính **diện tích lớn nhất** của island!

## 2. Mục tiêu bài học

- Tính size của mỗi island
- Track max area
- DFS với return size

## 3. Code chính (có comment)

```python
def max_area_of_island(grid: List[List[int]]) -> int:
    """
    Tìm diện tích lớn nhất của island
    Input: grid = [[0,0,1,0,0],[0,1,1,1,0],[0,1,0,1,0],[0,0,0,0,0]]
    Output: 6
    """
    if not grid:
        return 0
    
    rows, cols = len(grid), len(grid[0])
    max_area = 0
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return 0
        if grid[r][c] != 1:
            return 0
        
        grid[r][c] = 0  # Mark visited
        
        # Tính size = 1 + các neighbors
        return 1 + dfs(r+1, c) + dfs(r-1, c) + dfs(r, c+1) + dfs(r, c-1)
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 1:
                area = dfs(r, c)
                max_area = max(max_area, area)
    
    return max_area
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 224 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2240 |