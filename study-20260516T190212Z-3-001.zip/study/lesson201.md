# Bài 201 — LeetCode: Two Sum (Easy)

## 1. Ôn tập

Bạn đã hoàn thành bài 200 - Final Project. Giờ ta sẽ ôn lại kiến thức Algorithm qua LeetCode!

## 2. Mục tiêu bài học

- Giải Two Sum - bài LeetCode kinh điển
- Hiểu brute force và hash table approach
- So sánh độ phức tạp thời gian

## 3. Code chính (có comment)

```python
from typing import List

# Problem: Tìm 2 số có tổng = target
# Input: nums = [2,7,11,15], target = 9
# Output: [0, 1] vì nums[0] + nums[1] = 9

# Approach 1: Brute Force - O(n²)
def two_sum_brute(nums: List[int], target: int) -> List[int]:
    """
    Brute force: So sánh tất cả cặp
    Time: O(n²) - space: O(1)
    """
    n = len(nums)
    for i in range(n):
        for j in range(i + 1, n):
            if nums[i] + nums[j] == target:
                return [i, j]
    return []

# Approach 2: Hash Table - O(n)
def two_sum_hash(nums: List[int], target: int) -> List[int]:
    """
    Dùng dict để lưu complement
    Time: O(n) - Space: O(n)
    """
    seen = {}  # {value: index}
    
    for i, num in enumerate(nums):
        complement = target - num
        
        if complement in seen:
            return [seen[complement], i]
        
        seen[num] = i
    
    return []

# Test
nums = [2, 7, 11, 15]
target = 9

print(two_sum_brute(nums, target))  # [0, 1]
print(two_sum_hash(nums, target))    # [0, 1]
```

## 4. Trace chạy code

```
# Hash Table approach:
# i=0, num=2, complement=7, seen={}
# complement(7) not in seen → seen={2:0}
# i=1, num=7, complement=2, seen={2:0}
# complement(2) IN seen! → return [0, 1]

# Output: [0, 1]
```

## 5. Debug tư duy

### Tại sao hash table nhanh hơn?
- Brute force: so sánh tất cả cặp → n * n = n²
- Hash: lookup O(1) → chỉ cần n lần lookup

### Cần return index, không phải value!
```python
# Sai
return [num1, num2]  # Return values

# Đúng  
return [i, j]  # Return indices
```

### Nhớ: Chỉ duyệt 1 lần!
```python
# Sai: Duyệt 2 lần, tốn thời gian
for i in nums:
    for j in nums:  # Không cần!

# Đúng: 1 lần duyệt + lookup
for i, num in enumerate(nums):
    if target - num in dict:
        ...
```

## 6. Ghi nhớ nhanh

| Approach | Time | Space | Notes |
|----------|------|-------|-------|
| Brute Force | O(n²) | O(1) | So sánh tất cả |
| Hash Table | O(n) | O(n) | Dùng complement |
| Two Pointers | O(n log n) | O(1) | Sort trước |

## 7. Mini test (3 câu)

**Câu 1:** Two Sum brute force có độ phức tạp?
- A) O(n)
- B) O(n²)
- C) O(log n)
- D) O(1)

**Câu 2:** Hash table approach cần bao nhiêu space?
- A) O(1)
- B) O(n)
- C) O(n²)
- D) O(log n)

**Câu 3:** Complement trong bài là gì?
- A) Số cần tìm
- B) target - num hiện tại
- C) Số lớn nhất
- D) Số nhỏ nhất

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode Practice

**Biến thể:** "Three Sum" - Tìm 3 số có tổng = 0
- Gợi ý: Dùng 2 pointers sau khi sort
- Độ phức tạp: O(n²)

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 201 / 2000 |
| **Chapter** | LeetCode Practice |
| **XP** | 2010 |