# Bài 401 — Implement Queue using Stacks (Easy)

## 1. Ôn tập

Từ bài 400, ta đã học Factorial Trailing Zeroes. Hôm nay ta học **Implement Queue using Stacks**!

## 2. Mục tiêu bài học

- Dùng 2 stacks để implement queue
- FIFO với LIFO operations
- Amortized O(1)

## 3. Code chính (có comment)

```python
class MyQueue:
    def __init__(self):
        self.stack1 = []
        self.stack2 = []
    
    def push(self, x):
        self.stack1.append(x)
    
    def pop(self):
        self._transfer()
        return self.stack2.pop() if self.stack2 else None
    
    def peek(self):
        self._transfer()
        return self.stack2[-1] if self.stack2 else None
    
    def _transfer(self):
        if not self.stack2:
            while self.stack1:
                self.stack2.append(self.stack1.pop())
    
    def empty(self):
        return not self.stack1 and not self.stack2
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 401 / 2000 |
| **Chapter** | Design |
| **XP** | 4010 |