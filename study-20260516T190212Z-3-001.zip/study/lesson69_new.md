# Lesson 69 — Pytest

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 68 - Unit Testing (P2).

**Current Lesson:** Learning **pytest** — popular testing framework.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- pytest basics
- Test discovery
- Fixtures
- Parametrized tests

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Pytest Basics

```python
# Install: pip install pytest

# test_example.py
def test_add():
    assert 1 + 1 == 2

def test_multiply():
    assert 2 * 3 == 6

# Run: pytest
# Verbose: pytest -v
# Filter: pytest -k "test_name"
```

### Fixtures

```python
import pytest

@pytest.fixture
def sample_data():
    return [1, 2, 3, 4, 5]

def test_sum(sample_data):
    assert sum(sample_data) == 15
```

### Parametrized Tests

```python
import pytest

@pytest.mark.parametrize("input,expected", [
    (1, 2),
    (2, 4),
    (3, 6)
])
def test_double(input, expected):
    assert input * 2 == expected
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does @pytest.fixture do?**

> **Answer:** Defines reusable test data/fixtures

---

**Type 70 to continue**