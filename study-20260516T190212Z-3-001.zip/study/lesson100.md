# Bài 100 — Process vs Thread

---

## 1. Ôn tập
Bài 99 đã học về concurrency cơ bản. Giờ học sự **khác biệt** giữa Process và Thread.

---

## 2. Mục tiêu bài học
- Hiểu Process là gì
- Hiểu Thread là gì
- Biết khi nào dùng Process hay Thread
- Hiểu GIL trong Python

---

## 3. Code chính (có comment)

### So sánh Process và Thread

```python
import multiprocessing
import threading
import time

# ============ PROCESS ============
def process_worker(x):
    """Chạy trong process riêng"""
    result = x * x
    print(f"Process: {x} -> {result}")
    return result

# Tạo process
p = multiprocessing.Process(target=process_worker, args=(5,))
p.start()
p.join()

# ============ THREAD ============
def thread_worker(x):
    """Chạy trong thread (chia sẻ bộ nhớ)"""
    result = x * x
    print(f"Thread: {x} -> {result}")
    return result

# Tạo thread
t = threading.Thread(target=thread_worker, args=(5,))
t.start()
t.join()
```

### So sánh bộ nhớ

```python
# Process: Mỗi process có bộ nhớ riêng
# ↓↓↓
# Process A: [独立内存] ← Cannot share
# Process B: [独立内存] ← Cannot share

# Thread: Chia sẻ bộ nhớ trong cùng process
# ↓↓↓
# Thread A: [共享内存] →
# Thread B: [共享内存] → Có thể truy cập same data
```

---

## 4. Trace chạy code

```
Process vs Thread:

Process:
1. Tạo process mới với PID riêng
2. Cấp phát bộ nhớ riêng
3. Chạy code độc lập
4. Kết thúc → giải phóng bộ nhớ

Thread:
1. Tạo thread trong process hiện tại
2. Dùng chung bộ nhớ với main thread
3. Chạy song song (trong Python bị GIL giới hạn)
4. Kết thúc → không cấp phát thêm bộ nhớ
```

---

## 5. Debug tư duy

### ❌ Lỗi 1 — Nhầm Process và Thread
```python
# Sai: Dùng thread cho CPU intensive
def calculate():
    for i in range(1000000):
        result += i*i

# Đúng: Dùng multiprocessing
from multiprocessing import Pool
with Pool(4) as p:
    results = p.map(calculate, range(4))
```

### ❌ Lỗi 2 — Không join() process/thread
```python
# LỖI! Process chạy nền, có thể chưa xong
p = multiprocessing.Process(target=work)
p.start()
print("Main continues")  # Có thể chạy trước khi process xong

# ✅ Sửa: Join để đợi
p = multiprocessing.Process(target=work)
p.start()
p.join()  # Đợi process hoàn thành
print("Main continues")
```

### ❌ Lỗi 3 — Hiểu sai về GIL
```python
# GIL chỉ ảnh hưởng threads trong CPython
# Không ảnh hưởng khi:
# - I/O bound (network, file)
# - Dùng multiprocessing
# - Dùng C extensions
```

---

## 6. Ghi nhớ nhanh

| Aspect | Process | Thread |
|--------|---------|--------|
| **Bộ nhớ** | Separate (riêng) | Shared (chia sẻ) |
| **Tốc độ** | Chậm hơn | Nhanh hơn |
| **Giao tiếp** | IPC phức tạp | Shared memory dễ |
| **GIL** | Không bị ảnh hưởng | Bị ảnh hưởng (Python) |
| **Dùng khi** | CPU intensive | I/O bound |

**MẸO NHỚ:**
- CPU bound (tính toán nặng) → Process
- I/O bound (đọc/ghi, network) → Thread

---

## 7. Mini test (3 câu)

**Câu 1:** Thread trong Python có bị GIL giới hạn không?
> Đáp án: **Có** - GIL chỉ cho phép 1 thread chạy Python code tại 1 thời điểm

**Câu 2:** Process hay Thread nhanh hơn cho I/O?
> Đáp án: **Thread** - Vì chia sẻ bộ nhớ, overhead thấp hơn

**Câu 3:** Muốn chạy 4 core CPU cho tính toán nặng, dùng gì?
> Đáp án: **Multiprocessing** - Process chạy trên các core riêng biệt

---

## 8. LeetCode Practice

### Bài tập: Parallel Processing
**Yêu cầu:** Tính tổng bình phương của 4 số song song

**Input:** `1 2 3 4`

**Output:** `30` (1² + 2² + 3² + 4² = 1 + 4 + 9 + 16 = 30)

**✅ Đáp án:**
```python
import multiprocessing

def square(x):
    return x * x

if __name__ == "__main__":
    numbers = list(map(int, input().split()))
    
    with multiprocessing.Pool(4) as p:
        results = p.map(square, numbers)
    
    print(sum(results))
```

---

## 9. Bonus (nếu học tốt)

**Thử thách:** Viết chương trình tải nhiều file song song

**Input:**
```
file1.txt
file2.txt
file3.txt
```

**Output:**
```
Downloading file1.txt... Done
Downloading file2.txt... Done
Downloading file3.txt... Done
Total time: X.XX seconds
```

**Gợi ý:** Dùng ThreadPoolExecutor

**✅ Đáp án:**
```python
import threading
import time

def download(filename):
    print(f"Downloading {filename}...")
    time.sleep(1)  # Giả lập download
    print(f"Done: {filename}")

files = [input() for _ in range(int(input()))]

start = time.time()
threads = []
for f in files:
    t = threading.Thread(target=download, args=(f,))
    t.start()
    threads.append(t)

for t in threads:
    t.join()

print(f"Total time: {time.time() - start:.2f} seconds")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 100 / 2000 |
| **Chapter** | 6 (Advanced) |
| **XP** | 1000 (+20 XP khi hoàn thành) |
| **Level** | Advanced |

---

**🎉 Bạn đã hoàn thành Bài 100!**

Gõ **101** để học tiếp Bài 101 (Web Scraping) →