# Bài 316 — Reverse Linked List II (Medium)

## 1. Ôn tập

Từ bài 315, ta đã học Count of Range Sum. Hôm nay ta học **Reverse Linked List II**!

## 2. Mục tiêu bài học

- Reverse portion của linked list
- Dùng dummy node và pointer manipulation
- Time: O(n), Space: O(1)

## 3. Code chính (có comment)

```python
def reverse_between(head, left, right):
    """
    Reverse Linked List II
    Input: 1→2→3→4→5, left=2, right=4
    Output: 1→4→3→2→5
    """
    dummy = ListNode(0)
    dummy.next = head
    
    prev = dummy
    # Move to node before left
    for _ in range(left - 1):
        prev = prev.next
    
    # Reverse from left to right
    current = prev.next
    for _ in range(right - left):
        temp = current.next
        current.next = temp.next
        temp.next = prev.next
        prev.next = temp
    
    return dummy.next
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 316 / 2000 |
| **Chapter** | Linked List |
| **XP** | 3160 |