# Bài 427 — Remove Linked List Elements (Easy)

## 1. Ôn tập

Từ bài 426, ta đã học Remove Nth Node. Hôm nay ta học **Remove Linked List Elements**!

## 2. Mục tiêu bài học

- Xóa tất cả nodes với giá trị = val
- Iterative với dummy
- O(n)

## 3. Code chính (có comment)

```python
def remove_elements(head, val):
    """
    Remove Linked List Elements
    Input: 1→2→6→3→4→5→6, val=6
    Output: 1→2→3→4→5
    """
    dummy = ListNode(0)
    dummy.next = head
    current = dummy
    
    while current.next:
        if current.next.val == val:
            current.next = current.next.next
        else:
            current = current.next
    
    return dummy.next
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 427 / 2000 |
| **Chapter** | Linked List |
| **XP** | 4270 |