# Bài 366 — Reverse Words in a String (Medium)

## 1. Ôn tập

Từ bài 365, ta đã học Strobogrammatic Number. Hôm nay ta học **Reverse Words in a String**!

## 2. Mục tiêu bài học

- Đảo ngược words trong string
- Trim extra spaces
- O(n)

## 3. Code chính (có comment)

```python
def reverse_words(s):
    """
    Reverse Words
    Input: s="  hello world  "
    Output: "world hello"
    """
    words = s.split()
    return ' '.join(reversed(words))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 366 / 2000 |
| **Chapter** | String |
| **XP** | 3660 |