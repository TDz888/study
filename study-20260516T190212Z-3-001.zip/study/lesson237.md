# Bài 237 — Binary Tree Zigzag Level Order (Medium)

## 1. Ôn tập

Từ bài 236, ta đã học level order. Hôm nay ta học **Zigzag Level Order**!

## 2. Mục tiêu bài học

- Duyệt xen kẽ left-to-right, right-to-left
- Sử dụng deque hoặc reverse
- Alternating pattern

## 3. Code chính (có comment)

```python
def zigzag_level_order(root: TreeNode) -> List[List[int]]:
    """
    Duyệt zigzag: left->right, right->left, left->right...
    Input: root = [3,9,20,null,null,15,7]
    Output: [[3],[20,9],[15,7]]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    left_to_right = True
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        if not left_to_right:
            level.reverse()
        
        result.append(level)
        left_to_right = not left_to_right
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 237 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2370 |