# Bài 307 — Longest Common Subsequence (Medium)

## 1. Ôn tập

Từ bài 306, ta đã học House Robber. Hôm nay ta học **LCS** - Dynamic Programming cơ bản!

## 2. Mục tiêu bài học

- Tìm longest common subsequence của 2 strings
- Không cần contiguous
- dp[i][j] = LCS length của text1[:i] và text2[:j]

## 3. Code chính (có comment)

```python
def longest_common_subsequence(text1, text2):
    """
    LCS
    Input: text1="abcde", text2="ace"
    Output: 3 ("ace")
    """
    m, n = len(text1), len(text2)
    # dp[i][j] = LCS của text1[:i], text2[:j]
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if text1[i-1] == text2[j-1]:
                dp[i][j] = dp[i-1][j-1] + 1
            else:
                dp[i][j] = max(dp[i-1][j], dp[i][j-1])
    
    return dp[m][n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 307 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3070 |