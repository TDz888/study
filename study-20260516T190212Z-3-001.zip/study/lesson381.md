# Bài 381 — Longest Substring Without Repeating Characters (Medium)

## 1. Ôn tập

Từ bài 380, ta đã học Minimum Size Subarray Sum. Hôm nay ta học **Longest Substring Without Repeating**!

## 2. Mục tiêu bài học

- Tìm longest substring không có duplicate
- Sliding window + set
- O(n)

## 3. Code chính (có comment)

```python
def length_of_longest_substring(s):
    """
    Longest Substring
    Input: s="abcabcbb"
    Output: 3 ("abc")
    """
    char_set = set()
    left = 0
    max_len = 0
    
    for right in range(len(s)):
        while s[right] in char_set:
            char_set.remove(s[left])
            left += 1
        char_set.add(s[right])
        max_len = max(max_len, right - left + 1)
    
    return max_len
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 381 / 2000 |
| **Chapter** | Sliding Window |
| **XP** | 3810 |