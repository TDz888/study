# Lesson 76 — Dynamic Programming (P1)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 75 - BFS and DFS.

**Current Lesson:** Learning **Dynamic Programming** — optimization technique.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- What DP is
- Memoization (top-down)
- Tabulation (bottom-up)

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Fibonacci with DP

```python
# Naive - O(2^n) - very slow!
def fib_naive(n):
    if n <= 1:
        return n
    return fib_naive(n-1) + fib_naive(n-2)

# Memoization - Top-down DP
memo = {}
def fib_memo(n):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fib_memo(n-1) + fib_memo(n-2)
    return memo[n]

# Tabulation - Bottom-up DP
def fib_tab(n):
    if n <= 1:
        return n
    dp = [0] * (n + 1)
    dp[1] = 1
    for i in range(2, n + 1):
        dp[i] = dp[i-1] + dp[i-2]
    return dp[n]
```

### Comparison

| Approach | Time | Space |
|----------|------|-------|
| Naive | O(2^n) | O(n) |
| Memoization | O(n) | O(n) |
| Tabulation | O(n) | O(n) |

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What is memoization?**

> **Answer:** Caching results of expensive function calls

---

**Type 77 to continue**