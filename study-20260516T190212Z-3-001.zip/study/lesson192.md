# Bài 192 — Config Manager

## 1. Project

Centralized config với env variables

## 2. Code

```python
import os
from dataclasses import dataclass

@dataclass
class Config:
    db_url: str
    api_key: str
    log_level: str

class ConfigManager:
    @staticmethod
    def load() -> Config:
        return Config(
            db_url=os.getenv("DB_URL", "sqlite://db.sqlite"),
            api_key=os.getenv("API_KEY", ""),
            log_level=os.getenv("LOG_LEVEL", "INFO")
        )
    
    @classmethod
    def get(cls) -> Config:
        if not hasattr(cls, "_instance"):
            cls._instance = cls.load()
        return cls._instance
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 192 / 2000 |
| **XP** | 1920 |