# Lesson 53 — Generators

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 52 - Advanced Dictionary Operations.

**Current Lesson:** Learning **Generators** — memory-efficient iterators.

**Why This Matters:**
- Generators use O(1) memory vs O(n) for lists
- Perfect for processing large datasets
- Lazy evaluation: compute only when needed

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- Generator functions with yield
- Generator expressions
- Memory efficiency
- Infinite sequences

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### 1. Generator Functions with yield

```python
# List version - stores all in memory
def squares_list(n):
    result = []
    for i in range(n):
        result.append(i**2)
    return result

# Generator version - yields one at a time
def squares_gen(n):
    for i in range(n):
        yield i**2

# Usage
gen = squares_gen(5)
print(list(gen))  # [0, 1, 4, 9, 16]

# Iterate one at a time
for sq in squares_gen(3):
    print(sq, end=" ")  # 0 1 4

# Manual iteration
gen = squares_gen(3)
print(next(gen))  # 0
print(next(gen))  # 1
print(next(gen))  # 4
```

### 2. Generator Expression

```python
# List comprehension - creates full list
squares_list = [x**2 for x in range(5)]  # [0, 1, 4, 9, 16]

# Generator expression - lazy evaluation
squares_gen = (x**2 for x in range(5))

print(list(squares_gen))  # [0, 1, 4, 9, 16]
print(list(squares_gen))  # [] - exhausted!
```

### 3. Infinite Generator

```python
def infinite_counter(start=0):
    while True:
        yield start
        start += 1

counter = infinite_counter(10)
print(next(counter))  # 10
print(next(counter))  # 11
print(next(counter))  # 12

# Fibonacci infinite
def fibonacci():
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b

fib = fibonacci()
for _ in range(10):
    print(next(fib), end=" ")  # 0 1 1 2 3 5 8 13 21 34
```

### 4. Sending Values to Generator

```python
def accumulator():
    total = 0
    while True:
        value = yield total
        if value is not None:
            total += value

acc = accumulator()
print(next(acc))  # 0 (initial)
print(acc.send(5))  # 5
print(acc.send(3))  # 8
print(acc.send(10))  # 18
```

-------------------------------------------------------------------------------
4. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake: Exhausted Generator

```python
# ❌ WRONG - Generator is one-time use!
gen = (x for x in range(3))
print(list(gen))  # [0, 1, 2]
print(list(gen))  # [] - Empty!

# ✅ CORRECT - Recreate or use in loop
for x in (x for x in range(3)):
    print(x)  # Works
```

-------------------------------------------------------------------------------
5. MINI TEST
-------------------------------------------------------------------------------

### Question 1

**What is the output?**
```python
def gen():
    for i in range(3):
        yield i
g = gen()
print(next(g))
print(next(g))
```

> **Answer:** 0, then 1

---

**Type 54 to continue**