# Bài 365 — Strobogrammatic Number (Easy)

## 1. Ôn tập

Từ bài 364, ta đã học Power of Three. Hôm nay ta học **Strobogrammatic Number**!

## 2. Mục tiêu bài học

- Kiểm tra số có đọc ngược giống nhau không
- 0,1,8 là strobogrammatic
- 6↔9 mirror

## 3. Code chính (có comment)

```python
def is_strobogrammatic(num):
    """
    Strobogrammatic
    Input: num="69"
    Output: True
    """
    pairs = {'0':'0', '1':'1', '6':'9', '8':'8', '9':'6'}
    
    left, right = 0, len(num) - 1
    
    while left <= right:
        if num[left] not in pairs or pairs[num[left]] != num[right]:
            return False
        left += 1
        right -= 1
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 365 / 2000 |
| **Chapter** | String |
| **XP** | 3650 |