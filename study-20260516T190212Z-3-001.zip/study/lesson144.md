# Bài 144 — typing (P2)

---

## 1. Advanced typing

```python
from typing import Any, Callable, Generator, Iterator, Type, TypeVar

# Any
def process_anything(x: Any) -> Any:
    return x

# Callable
def apply(func: Callable[[int], int], x: int) -> int:
    return func(x)

# Generator
def count_up_to(n: int) -> Generator[int, None, None]:
    for i in range(1, n + 1):
        yield i

# TypeVar
T = TypeVar('T')
def first(lst: list[T]) -> T:
    return lst[0]

# Type
class MyClass: pass
def create() -> Type[MyClass]:
    return MyClass
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 144 / 2000 |
| **XP** | 1440 |
| **Level** | Intermediate |