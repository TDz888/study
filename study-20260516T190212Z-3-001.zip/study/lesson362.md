# Bài 362 — Shortest Distance to Character (Easy)

## 1. Ôn tập

Từ bài 361, ta đã học Valid Anagram. Hôm nay ta học **Shortest Distance to Character**!

## 2. Mục tiêu bài học

- Tính khoảng cách đến character gần nhất
- Two passes: left→right và right→left
- O(n)

## 3. Code chính (có comment)

```python
def shortest_distance(s, c):
    """
    Shortest Distance
    Input: s="loveleetcode", c="e"
    Output: [3,2,1,0,1,0,0,0,1,0,2,0]
    """
    n = len(s)
    result = [float('inf')] * n
    
    # Left to right
    pos = float('-inf')
    for i in range(n):
        if s[i] == c:
            pos = i
        result[i] = i - pos
    
    # Right to left
    pos = float('inf')
    for i in range(n-1, -1, -1):
        if s[i] == c:
            pos = i
        result[i] = min(result[i], pos - i)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 362 / 2000 |
| **Chapter** | Array |
| **XP** | 3620 |