# Bài 250 — Path Sum III (Medium)

## 1. Ôn tập

Từ bài 249, ta đã học max path sum. Hôm nay ta học **Path Sum III**!

## 2. Mục tiêu bài học

- Đếm paths có sum = target
- Path không nhất thiết qua root
- Prefix sum technique

## 3. Code chính (có comment)

```python
def path_sum(root: TreeNode, target: int) -> int:
    """
    Đếm paths có sum = target
    Input: root = [10,5,-3,3,2,null,11,3,-2,null,1], target = 8
    Output: 3
    """
    count = 0
    prefix_sum = {0: 1}
    
    def dfs(node, path_sum):
        nonlocal count
        if not node:
            return
        
        path_sum += node.val
        
        # Check có prefix sum = path_sum - target
        count += prefix_sum.get(path_sum - target, 0)
        
        prefix_sum[path_sum] = prefix_sum.get(path_sum, 0) + 1
        
        dfs(node.left, path_sum)
        dfs(node.right, path_sum)
        
        prefix_sum[path_sum] -= 1
    
    dfs(root, 0)
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 250 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2500 |