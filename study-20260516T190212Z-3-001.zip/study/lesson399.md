# Bài 399 — Integer to English Words (Hard)

## 1. Ôn tập

Từ bài 398, ta đã học Reverse String II. Hôm nay ta học **Integer to English Words**!

## 2. Mục tiêu bài học

- Convert number thành English words
- Handle billion, million, thousand
- Group by 3 digits

## 3. Code chính (có comment)

```python
def number_to_words(num):
    """
    Number to Words
    Input: num=1234567891
    Output: "One Billion Two Hundred Thirty Four Million..."
    """
    if num == 0:
        return "Zero"
    
    below_20 = ["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine",
                "Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen",
                "Seventeen","Eighteen","Nineteen"]
    tens = ["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"]
    
    def helper(n):
        if n == 0:
            return ""
        elif n < 20:
            return below_20[n] + " "
        elif n < 100:
            return tens[n//10] + " " + helper(n%10)
        else:
            return below_20[n//100] + " Hundred " + helper(n%100)
    
    result = ""
    parts = [num//1000000000, num//1000000%1000, num//1000%1000, num%1000]
    names = ["Billion ","Million ","Thousand ",""]
    
    for i, part in enumerate(parts):
        if part != 0:
            result += helper(part) + names[i]
    
    return result.strip()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 399 / 2000 |
| **Chapter** | Math |
| **XP** | 3990 |