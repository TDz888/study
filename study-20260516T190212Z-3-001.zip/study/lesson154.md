# Bài 154 — Context Managers Advanced

---

## 1. Context Manager với class

```python
class Timer:
    def __init__(self, name=""):
        self.name = name
        self.start = None
    
    def __enter__(self):
        import time
        self.start = time.time()
        print(f"{self.name} started")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        import time
        elapsed = time.time() - self.start
        print(f"{self.name} took {elapsed:.4f}s")
        return False  # Don't suppress exceptions

with Timer("My Timer"):
    sum(range(1000000))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 154 / 2000 |
| **XP** | 1540 |
| **Level** | Advanced |