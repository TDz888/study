# Bài 363 — Most Common Word (Easy)

## 1. Ôn tập

Từ bài 362, ta đã học Shortest Distance. Hôm nay ta học **Most Common Word**!

## 2. Mục tiêu bài học

- Tìm word xuất hiện nhiều nhất (exclude banned)
- Parse và lowercase
- Counter

## 3. Code chính (có comment)

```python
def most_common_word(paragraph, banned):
    """
    Most Common Word
    Input: paragraph="Bob hit a ball, the hit ball flew far."
    Output: "ball"
    """
    from collections import Counter
    
    # Clean và parse
    words = paragraph.lower().split()
    banned_set = set(banned)
    
    counts = Counter()
    for word in words:
        # Remove punctuation
        clean = ''.join(c if c.isalnum() else ' ' for c in word).split()[-1]
        if clean and clean not in banned_set:
            counts[clean] += 1
    
    return counts.most_common(1)[0][0]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 363 / 2000 |
| **Chapter** | String |
| **XP** | 3630 |