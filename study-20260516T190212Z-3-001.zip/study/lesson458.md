# Bài 458 — Network Delay Time (Medium)

## 1. Ôn tập

Từ bài 457, ta đã học Evaluate Division. Hôm nay ta học **Network Delay Time**!

## 2. Mục tiêu bài học

- Tìm thời gian để signal đến tất cả nodes
- Dijkstra's algorithm
- O(E log V)

## 3. Code chính (có comment)

```python
import heapq

def network_delay_time(times, n, k):
    """
    Network Delay Time
    Input: times=[[2,1,1],[2,3,1],[3,4,1]], n=4, k=2
    Output: 2
    """
    graph = {i: [] for i in range(1, n+1)}
    for u, v, w in times:
        graph[u].append((v, w))
    
    dist = {i: float('inf') for i in range(1, n+1)}
    dist[k] = 0
    heap = [(0, k)]
    
    while heap:
        d, node = heapq.heappop(heap)
        if d > dist[node]:
            continue
        for neighbor, weight in graph[node]:
            if dist[neighbor] > d + weight:
                dist[neighbor] = d + weight
                heapq.heappush(heap, (dist[neighbor], neighbor))
    
    return max(dist.values()) if max(dist.values()) < float('inf') else -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 458 / 2000 |
| **Chapter** | Graph |
| **XP** | 4580 |