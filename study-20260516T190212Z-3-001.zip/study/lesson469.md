# Lesson 469 — Next Permutation

---

## 1. KNOWLEDGE CONNECTION

Từ bài 468, bạn đã học **Relative Sort Array** - sắp xếp theo thứ tự tùy chỉnh. Bài hôm nay sẽ học **Next Permutation** - tìm hoán vị tiếp theo của một mảng. Đây là nền tảng cho nhiều bài toán permutation.

## 2. TODAY'S MISSION

Hôm nay bạn sẽ học:
- Tìm hoán vị tiếp theo trong thứ tự lexicographical
- Thuật toán 3 bước cơ bản
- Áp dụng vào nhiều bài toán permutation

## 3. CONCEPT FOUNDATION

**Next Permutation** là tìm hoán vị kế tiếp lớn hơn hiện tại:

```
Input: [1,2,3] 
Các hoán vị theo thứ tự:
[1,2,3] → [1,3,2] → [2,1,3] → [2,3,1] → [3,1,2] → [3,2,1]

[1,3,2] → next là [2,1,3]
[3,2,1] → next là [1,2,3] (quay về đầu)
```

## 4. TERMINOLOGY EXPLANATION

- **Permutation**: Hoán vị, sắp xếp lại các phần tử
- **Lexicographical**: Thứ tự từ điển, so sánh từng phần tử
- **Pivot**: Điểm xoay, phần tử cần thay đổi

## 5. MAIN CODE

```python
def next_permutation(nums):
    """
    Tìm hoán vị tiếp theo
    
    Input: nums = [1,2,3]
    Output: [1,3,2]
    
    Giải thích thuật toán 3 bước:
    1. Tìm i lớn nhất sao cho nums[i] < nums[i+1]
    2. Tìm j lớn nhất sao cho nums[j] > nums[i]
    3. Swap i và j, đảo ngược từ i+1 đến cuối
    """
    n = len(nums)
    
    # Bước 1: Tìm pivot (i)
    # Tìm từ cuối, tìm phần tử đầu tiên giảm
    i = n - 2
    while i >= 0 and nums[i] >= nums[i + 1]:
        i -= 1
    
    if i >= 0:
        # Bước 2: Tìm phần tử lớn hơn nums[i] từ cuối
        j = n - 1
        while nums[j] <= nums[i]:
            j -= 1
        
        # Bước 3: Swap
        nums[i], nums[j] = nums[j], nums[i]
    
    # Bước 4: Đảo ngược phần sau i
    left = i + 1
    right = n - 1
    while left < right:
        nums[left], nums[right] = nums[right], nums[left]
        left += 1
        right -= 1
    
    return nums
```

## 6. EXECUTION TRACE

```python
# Test: nums = [1, 2, 3]
# Bước 1: Tìm i
# i = 1 (vì nums[1]=2 < nums[2]=3, dừng tại đây)

# Bước 2: Tìm j
# j = 2 (nums[2]=3 > nums[1]=2)

# Bước 3: Swap i, j
# nums = [1, 3, 2]

# Bước 4: Đảo ngược từ i+1=2
# Chỉ có 1 phần tử, không cần đảo

# Output: [1, 3, 2]
```

## 7. VISUAL THINKING MODE

```
[1, 2, 3] → tìm pivot

      i=1
      ↓
[1,   2,  3]
       ↓ swap
[1,   3,  2]

Output: [1, 3, 2]

─────────────────────────────────────────

[3, 2, 1] → Không có pivot (đã là max)

i = -1 → quay về đầu (reverse to sorted)
[1, 2, 3]
```

## 8. DEBUG THINKING MODE

**Common Mistakes:**
1. **Tìm sai pivot** → Dùng nums[i] > nums[i+1] thay vì nums[i] < nums[i+1]
2. **Quên đảo ngược** → Chỉ swap mà không reverse phần sau
3. **Index out of bounds** → Không kiểm tra i >= 0

**Cách sửa:**
```python
# ❌ Sai: i = n - 1
# ✅ Đúng: i = n - 2 (bắt đầu từ index thứ 2 từ cuối)

# ✅ Đúng: while i >= 0 and nums[i] >= nums[i+1]
```

## 9. MEMORY REINFORCEMENT

**Algorithm Summary:**
```
1. Tìm i: từ cuối, phần tử đầu tiên giảm (nums[i] < nums[i+1])
2. Tìm j: từ cuối, phần tử đầu tiên lớn hơn nums[i]
3. Swap nums[i] và nums[j]
4. Reverse từ i+1 đến cuối
```

**Time: O(n), Space: O(1)**

## 10. MINI TEST

1. Next permutation của [1,1,5]?
2. Next permutation của [5,4,3,2,1]?
3. Tại sao cần reverse phần sau pivot?

## 11. LEETCODE PRACTICE

**Problem:** Next Permutation (LeetCode 31)
- Medium level
- Classic algorithm

## 12. BONUS CHALLENGE

- Implement Previous Permutation
- Tìm k-th permutation

## 13. LESSON REFLECTION

Đã học thuật toán tìm next permutation trong O(n). Cần nắm vững 3 bước cơ bản.

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 469 / 2000 |
| **XP** | +25 |