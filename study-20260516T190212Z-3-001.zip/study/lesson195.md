# Bài 195 — REST API Advanced

## 1. Topics

- Authentication (JWT)
- Pagination
- Filtering
- Error handling

## 2. Code

```python
from flask import Flask, jsonify, request
from functools import wraps

app = Flask(__name__)

def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization")
        if not verify_token(token):
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

@app.route("/api/users")
@require_auth
def get_users():
    page = request.args.get("page", 1)
    limit = request.args.get("limit", 10)
    # Pagination logic
    return jsonify({"users": [...], "page": page})
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 195 / 2000 |
| **XP** | 1950 |