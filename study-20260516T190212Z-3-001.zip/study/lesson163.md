# Bài 163 — asyncio.Condition

## 1. Ôn tập

Ta đã học:
- **Lock**: Bảo vệ tài nguyên, chỉ 1 task vào
- **Event**: Thông báo một lần cho nhiều task

Nhưng nếu ta cần: chờ cho đến khi ĐIỀU KIỆN nào đó thỏa mãn, rồi chỉ cho phép một số task vào?

## 2. Mục tiêu bài học

- Hiểu `Condition` - kết hợp giữa Lock và Event
- Học cách chờ điều kiện cụ thể
- Dùng Condition cho producer-consumer

## 3. Code chính (có comment)

```python
import asyncio

class AsyncQueue:
    """Hàng đợi an toàn với Condition"""
    def __init__(self, maxsize=0):
        self.queue = []
        self.maxsize = maxsize
        self.condition = asyncio.Condition()
    
    async def put(self, item):
        async with self.condition:
            # Chờ cho queue chưa đầy
            while len(self.queue) >= self.maxsize:
                await self.condition.wait()  # Chờ có chỗ trống
            
            self.queue.append(item)
            print(f"Put: {item}, queue size: {len(self.queue)}")
            self.condition.notify()  # Báo cho người chờ biết có dữ liệu
    
    async def get(self):
        async with self.condition:
            # Chờ cho queue có dữ liệu
            while len(self.queue) == 0:
                await self.condition.wait()  # Chờ có dữ liệu
            
            item = self.queue.pop(0)
            print(f"Get: {item}, queue size: {len(self.queue)}")
            self.condition.notify()  # Báo cho người chờ biết có chỗ trống
            return item

async def producer(queue, n):
    for i in range(n):
        await queue.put(i)
        await asyncio.sleep(0.5)

async def consumer(queue, n):
    for _ in range(n):
        item = await queue.get()
        await asyncio.sleep(0.3)

async def main():
    queue = AsyncQueue(maxsize=3)
    
    # 5 producer, 5 consumer
    await asyncio.gather(
        producer(queue, 5),
        consumer(queue, 5)
    )

asyncio.run(main())
```

## 4. Trace chạy code

```
Put: 0, queue size: 1
Get: 0, queue size: 0
Put: 1, queue size: 1
Get: 1, queue size: 0
Put: 2, queue size: 1
Get: 2, queue size: 0
Put: 3, queue size: 1
Get: 3, queue size: 0
Put: 4, queue size: 1
Get: 4, queue size: 0
```

## 5. Debug tư duy

### Sai lầm thường gặp
**Sai:** Quên notify sau khi thay đổi điều kiện

```python
async with self.condition:
    self.queue.append(item)
    # Quên notify! Consumer sẽ chờ mãi
```

**Đúng:** Luôn notify sau khi thay đổi trạng thái

```python
async with self.condition:
    self.queue.append(item)
    self.condition.notify()  # Báo cho consumer
```

## 6. Ghi nhớ nhanh

| Phương thức | Công dụng |
|-------------|-----------|
| `condition.wait()` | Chờ cho đến khi được notify |
| `condition.notify()` | Báo cho 1 task đang chờ |
| `condition.notify_all()` | Báo cho tất cả task đang chờ |
| Cần `async with` | Vì Condition dùng Lock bên trong |

## 7. Mini test (3 câu)

**Câu 1:** Condition kết hợp những gì?
- A) Event + Semaphore
- B) Lock + Event
- C) Queue + Event
- D) Lock + Queue

**Câu 2:** notify() và notify_all() khác gì?
- A) Không khác
- B) notify() báo 1 task, notify_all() báo tất cả
- C) notify() nhanh hơn
- D) notify_all() chỉ dùng được 1 lần

**Câu 3:** Tại sao cần vòng while trong wait?
- A) Để code đẹp hơn
- B) Vì có thể bị wake up không đúng điều kiện (spurious wakeup)
- C) Để tránh lỗi
- D) Không cần thiết

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Bounded Buffer"

```python
class BoundedBuffer:
    def __init__(self, capacity):
        self.buffer = []
        self.capacity = capacity
        self.condition = asyncio.Condition()
    
    async def produce(self, item):
        # Viết code với condition
        pass
    
    async def consume(self):
        # Viết code với condition
        pass
```

## 9. Bonus

Tạo hệ thống:
- Producer tạo số chẵn → Consumer A xử lý
- Producer tạo số lẻ → Consumer B xử lý
- Dùng 2 Condition riêng biệt

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 163 / 2000 |
| **XP** | 1630 |