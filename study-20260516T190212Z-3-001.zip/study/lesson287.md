# Bài 287 — Populating Next Right Pointers (Medium)

## 1. Ôn tập

Từ bài 286, ta đã học Construct Binary Tree. Hôm nay ta học **connect next pointers** trong perfect binary tree!

## 2. Mục tiêu bài học

- Connect mỗi node đến next right node
- Dùng level-order hoặc O(1) space
- Xử lý perfect binary tree

## 3. Code chính (có comment)

```python
class Node:
    def __init__(self, val=0, left=None, right=None, next=None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next

def connect(root):
    """
    Connect next pointers
    Input: Perfect binary tree
    Output: Mỗi next trỏ đến right neighbor
    """
    if not root:
        return root
    
    leftmost = root
    
    while leftmost.left:
        head = leftmost
        while head:
            # Connection trong cùng level
            head.left.next = head.right
            
            # Connection sang next level
            if head.next:
                head.right.next = head.next.left
            
            head = head.next
        
        # Move to next level
        leftmost = leftmost.left
    
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 287 / 2000 |
| **Chapter** | Trees |
| **XP** | 2870 |