# Bài 193 — Testing Framework

## 1. Project

Build mini test framework

## 2. Code

```python
class TestCase:
    def __init__(self, name):
        self.name = name
        self.passed = 0
        self.failed = 0
    
    def assert_equal(self, actual, expected):
        if actual == expected:
            self.passed += 1
        else:
            self.failed += 1
            print(f"FAIL: {self.name} - {actual} != {expected}")

class TestSuite:
    def __init__(self):
        self.tests = []
    
    def add(self, test):
        self.tests.append(test)
    
    def run(self):
        for test in self.tests:
            test.run()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 193 / 2000 |
| **XP** | 1930 |