# Bài 341 — Longest Palindromic Substring (Medium)

## 1. Ôn tập

Từ bài 340, ta đã học String to Integer. Hôm nay ta học **Longest Palindromic Substring**!

## 2. Mục tiêu bài học

- Tìm longest palindrome substring
- Expand from center
- O(n²)

## 3. Code chính (có comment)

```python
def longest_palindrome(s):
    """
    Longest Palindromic Substring
    Input: "babad"
    Output: "bab" hoặc "aba"
    """
    if not s:
        return ""
    
    start = end = 0
    
    for i in range(len(s)):
        # Odd length palindrome
        len1 = expand(i, i, s)
        # Even length palindrome
        len2 = expand(i, i + 1, s)
        max_len = max(len1, len2)
        
        if max_len > end - start + 1:
            start = i - (max_len - 1) // 2
            end = i + max_len // 2
    
    return s[start:end + 1]

def expand(left, right, s):
    while left >= 0 and right < len(s) and s[left] == s[right]:
        left -= 1
        right += 1
    return right - left - 1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 341 / 2000 |
| **Chapter** | String |
| **XP** | 3410 |