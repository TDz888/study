# Bài 300 — Longest Increasing Subsequence (Medium)

## 1. Ôn tập

Từ bài 299, ta đã học Path Sum. Hôm nay ta học **Dynamic Programming cơ bản** - LIS!

## 2. Mục tiêu bài học

- Tìm longest increasing subsequence
- DP: dp[i] = length của LIS ending tại i
- Optimize với Binary Search: O(n log n)

## 3. Code chính (có comment)

```python
def length_of_lis(nums):
    """
    Longest Increasing Subsequence
    Input: [10,9,2,5,3,7,101,18]
    Output: 4 ([2,3,7,101] hoặc [2,5,7,101])
    """
    # Cách 1: DP - O(n²)
    # dp[i] = max(dp[j] + 1) với j < i và nums[j] < nums[i]
    
    # Cách 2: Binary Search - O(n log n)
    import bisect
    
    sub = []  # tails array
    
    for num in nums:
        pos = bisect.bisect_left(sub, num)
        if pos == len(sub):
            sub.append(num)
        else:
            sub[pos] = num
    
    return len(sub)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 300 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3000 |