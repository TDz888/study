# Bài 155 — Generator Advanced

---

## 1. yield from

```python
def chain(*iterables):
    for it in iterables:
        yield from it

result = list(chain([1,2], [3,4], [5,6]))
print(result)  # [1, 2, 3, 4, 5, 6]
```

---

## 2. throw, close

```python
def my_gen():
    try:
        yield 1
        yield 2
    except ValueError:
        yield "caught"

g = my_gen()
print(next(g))  # 1
print(g.throw(ValueError))  # caught
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 155 / 2000 |
| **XP** | 1550 |
| **Level** | Advanced |