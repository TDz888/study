# Bài 336 — Gas Station (Medium)

## 1. Ôn tập

Từ bài 335, ta đã học Jump Game. Hôm nay ta học **Gas Station**!

## 2. Mục tiêu bài học

- Tìm starting station có thể complete circuit
- Greedy: nếu total >= 0, có solution
- Track remaining gas

## 3. Code chính (có comment)

```python
def can_complete_circuit(gas, cost):
    """
    Gas Station
    Input: gas=[1,2,3,4,5], cost=[3,4,5,1,2]
    Output: 3
    """
    total_tank = 0
    curr_tank = 0
    start = 0
    
    for i in range(len(gas)):
        diff = gas[i] - cost[i]
        total_tank += diff
        curr_tank += diff
        
        if curr_tank < 0:
            start = i + 1
            curr_tank = 0
    
    return start if total_tank >= 0 else -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 336 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3360 |