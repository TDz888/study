# Bài 171 — Giới thiệu Generators

## 1. Ôn tập

Từ bài 160-170, ta đã học rất nhiều về asyncio. Bây giờ, ta sẽ chuyển sang một chủ đề mới: **Generators** - cách tạo iterator một cách hiệu quả.

## 2. Mục tiêu bài học

- Hiểu generator là gì và tại sao cần
- Nắm cú pháp `yield`
- Phân biệt generator với list

## 3. Code chính (có comment)

# Tạo list 1000 số - TỐN BỘ NHỚ
def create_list():
    return [i for i in range(1000)]

# Tạo generator - TIẾT KIỆM BỘ NHỚ
def create_generator():
    for i in range(1000):
        yield i  # yield = trả về và PAUSE

# Cách dùng
gen = create_generator()
print(type(gen))  # <class 'generator'>

# Lấy từng giá trị - không cần tạo cả list
print(next(gen))  # 0
print(next(gen))  # 1
print(next(gen))  # 2

# Hoặc dùng for
for num in create_generator():
    print(num)  # 0, 1, 2, ...
```

## 4. Trace chạy code

```
<class 'generator'>
0
1
2
0
1
2
3
...
```

## 5. Debug tư duy

### Tại sao dùng Generator?

| Cách | Bộ nhớ | Tốc độ |
|------|--------|--------|
| List 1000 phần tử | ~8KB | Nhanh ngay |
| Generator | ~1KB | Lazy (tính khi dùng) |

### Generator exhaustion
```python
gen = (i for i in range(3))
list(gen)  # [0, 1, 2]
list(gen)  # [] - đã hết!
```

## 6. Ghi nhớ nhanh

| Khái niệm | Ý nghĩa |
|-----------|---------|
| `yield` | Trả giá trị và tạm dừng |
| `next(gen)` | Lấy giá trị tiếp theo |
| Lazy evaluation | Tính toán khi cần, không lưu hết |
| Exhausted | Generator đã hết, cần tạo mới |

## 7. Mini test (3 câu)

**Câu 1:** yield khác return ở điểm nào?
- A) Không khác
- B) Return kết thúc hàm, yield tạm dừng
- C) yield chỉ dùng trong class
- D) return nhanh hơn

**Câu 2:** Generator có lưu tất cả giá trị trong bộ nhớ?
- A) Có
- B) Không - lazy evaluation
- C) Tùy trường hợp
- D) Chỉ lưu 1 phần

**Câu 3:** Sau khi dùng hết, generator cần làm gì?
- A) Xóa
- B) Tạo mới
- C) Reset
- D) Giữ nguyên

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Range Iterator"

```python
class RangeIterator:
    def __init__(self, start, end):
        self.current = start
        self.end = end
    
    def __iter__(self):
        return self
    
    def __next__(self):
        # Viết code để tạo iterator
        pass

for i in RangeIterator(1, 5):
    print(i)  # 1, 2, 3, 4
```

## 9. Bonus

Tạo generator:
- Fibonacci generator vô hạn
- Prime number generator
- File line reader

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 171 / 2000 |
| **XP** | 1710 |