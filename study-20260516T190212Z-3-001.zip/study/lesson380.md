# Bài 380 — Minimum Size Subarray Sum (Medium)

## 1. Ôn tập

Từ bài 379, ta đã học Valid Perfect Square. Hôm nay ta học **Minimum Size Subarray Sum**!

## 2. Mục tiêu bài học

- Tìm minimum length subarray với sum >= target
- Sliding window
- O(n)

## 3. Code chính (có comment)

```python
def min_subarray_len(target, nums):
    """
    Minimum Size Subarray Sum
    Input: target=7, nums=[2,3,1,2,4,3]
    Output: 2 ([4,3])
    """
    n = len(nums)
    left = 0
    current_sum = 0
    min_len = float('inf')
    
    for right in range(n):
        current_sum += nums[right]
        
        while current_sum >= target:
            min_len = min(min_len, right - left + 1)
            current_sum -= nums[left]
            left += 1
    
    return min_len if min_len != float('inf') else 0
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 380 / 2000 |
| **Chapter** | Sliding Window |
| **XP** | 3800 |