# Bài 146 — ABC (Abstract Base Classes)

---

## 1. ABC module

```python
from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def speak(self) -> str:
        pass
    
    def move(self) -> str:
        return "Moves"

class Dog(Animal):
    def speak(self) -> str:
        return "Woof!"

class Cat(Animal):
    def speak(self) -> str:
        return "Meow!"

# Cannot instantiate Animal
# animal = Animal()  # Error!

dog = Dog()
print(dog.speak())  # Woof!
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 146 / 2000 |
| **XP** | 1460 |
| **Level** | Advanced |