# Bài 400 — Factorial Trailing Zeroes (Medium)

## 1. Ôn tập

Từ bài 399, ta đã học Integer to English Words. Hôm nay ta học **Factorial Trailing Zeroes**!

## 2. Mục tiêu bài học

- Đếm trailing zeros trong n!
- Count factors of 10 = count of (2,5) pairs
- Count factors of 5 (vì 2 dư thừa)

## 3. Code chính (có comment)

```python
def trailing_zeroes(n):
    """
    Factorial Trailing Zeroes
    Input: n=5
    Output: 1 (5! = 120)
    """
    count = 0
    
    while n > 0:
        n //= 5
        count += n
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 400 / 2000 |
| **Chapter** | Math |
| **XP** | 4000 |