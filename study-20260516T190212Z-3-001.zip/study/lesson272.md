# Bài 272 — AVL Tree Basics (Medium)

## 1. Ôn tập

Từ bài 271, ta đã học Serialize BST. Hôm nay ta học **AVL Tree** - cây tự cân bằng!

## 2. Mục tiêu bài học

- AVL: cây tự cân bằng sau mỗi lần insert/delete
- Balance Factor = height(left) - height(right)
- |BF| ≤ 1 luôn

## 3. Code chính (có comment)

```python
class AVLNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None
        self.height = 1

def get_height(node):
    return node.height if node else 0

def get_balance(node):
    return get_height(node.left) - get_height(node.right) if node else 0

def right_rotate(y):
    x = y.left
    T2 = x.right
    
    x.right = y
    y.left = T2
    
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    x.height = 1 + max(get_height(x.left), get_height(x.right))
    
    return x
```

## 4. 4 trường hợp mất cân bằng

| Case | Pattern | Solution |
|------|---------|----------|
| LL | left-left | Right rotate |
| RR | right-right | Left rotate |
| LR | left-right | Left rotate → Right rotate |
| RL | right-left | Right rotate → Left rotate |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 272 / 2000 |
| **Chapter** | Advanced Trees |
| **XP** | 2720 |