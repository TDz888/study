# Bài 345 — Jump Game II (Medium)

## 1. Ôn tập

Từ bài 344, ta đã học Best Time II. Hôm nay ta học **Jump Game II**!

## 2. Mục tiêu bài học

- Minimum jumps để reach end
- Greedy: extend farthest
- O(n)

## 3. Code chính (có comment)

```python
def jump(nums):
    """
    Jump Game II
    Input: [2,3,1,1,4]
    Output: 2 (2->3->4)
    """
    jumps = 0
    current_end = 0
    farthest = 0
    
    for i in range(len(nums) - 1):
        farthest = max(farthest, i + nums[i])
        
        if i == current_end:
            jumps += 1
            current_end = farthest
    
    return jumps
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 345 / 2000 |
| **Chapter** | Greedy |
| **XP** | 3450 |