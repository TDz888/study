# Bài 373 — Reverse Linked List (Easy)

## 1. Ôn tập

Từ bài 372, ta đã học Swap Nodes. Hôm nay ta học **Reverse Linked List**!

## 2. Mục tiêu bài học

- Reverse linked list
- Iterative: 3 pointers
- Recursive approach

## 3. Code chính (có comment)

```python
def reverse_list(head):
    """
    Reverse Linked List
    Input: 1→2→3→4→5
    Output: 5→4→3→2→1
    """
    prev = None
    current = head
    
    while current:
        next_temp = current.next
        current.next = prev
        prev = current
        current = next_temp
    
    return prev
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 373 / 2000 |
| **Chapter** | Linked List |
| **XP** | 3730 |