# Bài 187 — Practice: API Gateway

## 1. Project

Simple API Gateway với:
- Request routing
- Rate limiting
- Authentication

## 2. Code

```python
class APIGateway:
    def __init__(self):
        self.routes = {}
        self.limiter = TokenBucket(rate=100)
    
    async def handle(self, request):
        if not self.limiter.allow():
            return 429, "Too many requests"
        
        route = self.find_route(request.path)
        if not route:
            return 404, "Not found"
        
        return await self.proxy(request, route)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 187 / 2000 |
| **XP** | 1870 |