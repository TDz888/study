# Bài 188 — Practice: Background Worker

## 1. Project

Async worker queue xử lý jobs background

## 2. Components

```python
class WorkerPool:
    def __init__(self, num_workers):
        self.queue = asyncio.Queue()
        self.workers = []
    
    async def start(self):
        self.workers = [
            asyncio.create_task(self.worker(i))
            for i in range(self.num_workers)
        ]
    
    async def submit(self, job):
        await self.queue.put(job)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 188 / 2000 |
| **XP** | 1880 |