# Bài 182 — Testing Async Code

## 1. Ôn tập

Ta đã biết pytest (bài 69). Hôm nay học test async code!

## 2. Mục tiêu bài học

- pytest-asyncio
- Test async functions
- Fixtures async

## 3. Code chính (có comment)

```python
# Cài đặt: pip install pytest-asyncio

# File: test_async.py
import pytest
import asyncio

# Test async function đơn giản
@pytest.mark.asyncio
async def test_async_add():
    result = await add(1, 2)
    assert result == 3

# Fixture async
@pytest.fixture
async def db():
    connection = await connect_db()
    yield connection
    await connection.close()

@pytest.mark.asyncio
async def test_db_query(db):
    result = await db.query("SELECT 1")
    assert result == [(1,)]

# Mocking async functions
from unittest.mock import AsyncMock, patch

@pytest.mark.asyncio
async def test_fetch():
    with patch('aiohttp.ClientSession.get') as mock_get:
        mock_get.return_value.__aenter__.return_value.json = AsyncMock(
            return_value={'data': 'test'}
        )
        result = await fetch_data()
        assert result == {'data': 'test'}
```

## 4. Config

```toml
# pyproject.toml
[tool.pytest.ini_options]
asyncio_mode = "auto"
```

## 5. Ghi nhớ nhanh

| Decorator | Ý nghĩa |
|-----------|---------|
| `@pytest.mark.asyncio` | Đánh dấu test async |
| `AsyncMock` | Mock async function |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 182 / 2000 |
| **XP** | 1820 |