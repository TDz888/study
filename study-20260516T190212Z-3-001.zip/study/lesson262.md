# Bài 262 — Minimum Depth of Binary Tree (Easy)

## 1. Ôn tập

Từ bài 261, ta đã học Maximum Depth. Hôm nay ta học tính **độ sâu tối thiểu** của cây!

## 2. Mục tiêu bài học

- Tìm độ sâu nhỏ nhất từ root đến leaf gần nhất
- Cẩn thận với cây lệch (chỉ có 1 con)
- Dùng BFS hiệu quả hơn cho bài này

## 3. Code chính (có comment)

```python
# Cách 1: DFS - Cẩn thận với cây lệch!
def min_depth(root: TreeNode) -> int:
    if not root:
        return 0
    
    # Nếu không có con bên trái → chỉ tính bên phải
    if not root.left:
        return 1 + min_depth(root.right)
    # Nếu không có con bên phải → chỉ tính bên trái
    if not root.right:
        return 1 + min_depth(root.left)
    
    # Có 2 con → tính min của cả 2
    return 1 + min(min_depth(root.left), min_depth(root.right))

# Cách 2: BFS - Dừng ngay khi tìm thấy leaf đầu tiên
from collections import deque

def min_depth_bfs(root):
    if not root:
        return 0
    
    queue = deque([root])
    depth = 1
    
    while queue:
        for _ in range(len(queue)):
            node = queue.popleft()
            # Nếu là leaf → return ngay
            if not node.left and not node.right:
                return depth
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        depth += 1
    
    return depth
```

## 4. Ví dụ

```
       2          Min depth = 2 (2 → 1)
      /
     1

       2          Min depth = 2 (2 → 1)
      / \
     1   3
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 262 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2620 |