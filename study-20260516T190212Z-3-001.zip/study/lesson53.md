# Bài 53 — Generators

---

## 1. Ôn tập
Giờ học **Generator** — cách tạo iterator tiết kiệm memory.

---

## 2. Mục tiêu
- Hiểu generator là gì
- yield keyword
- Generator expression
- Ứng dụng

---

## 3. Generator cơ bản

```python
# Hàm thông thường trả về list
def squares_list(n):
    result = []
    for i in range(n):
        result.append(i**2)
    return result

# Generator trả về từng giá trị
def squares_gen(n):
    for i in range(n):
        yield i**2

# Sử dụng
gen = squares_gen(5)
print(list(gen))  # [0, 1, 4, 9, 16]

# Duyệt từng giá trị
for sq in squares_gen(3):
    print(sq, end=" ")  # 0 1 4
```

---

## 4. Generator Expression

```python
# Thay vì list comprehension
squares = [x**2 for x in range(5)]  # List

# Dùng generator (tiết kiệm memory)
squares_gen = (x**2 for x in range(5))  # Generator

print(list(squares_gen))  # [0, 1, 4, 9, 16]
```

---

## 5. Infinite Generator

```python
def infinite_counter(start=0):
    while True:
        yield start
        start += 1

counter = infinite_counter(10)
print(next(counter))  # 10
print(next(counter))  # 11
print(next(counter))  # 12
```

---

## 6. So sánh

| Loại | Memory | Tốc độ |
|------|--------|--------|
| List | O(n) | Nhanh |
| Generator | O(1) | Chậm hơn |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 53 / 2000 |
| **XP** | 530 |
| **Level** | Advanced |