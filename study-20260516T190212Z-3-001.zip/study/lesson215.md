# Bài 215 — LeetCode: Intersection of Two Arrays (Easy)

## 1. Ôn tập

Bài 214 dùng Set để detect duplicate. Hôm nay ta dùng Set để tìm **INTERSECTION** - giao của 2 arrays!

## 2. Mục tiêu bài học

- Tìm giao của 2 arrays
- Dùng set operations
- Loại bỏ duplicates trong result

## 3. Code chính (có comment)

```python
def intersection(nums1: List[int], nums2: List[int]) -> List[int]:
    """
    Tìm giao của 2 arrays (unique elements)
    Input: nums1=[1,2,2,1], nums2=[2,2]
    Output: [2]
    """
    # Convert to set → intersection → list
    return list(set(nums1) & set(nums2))

# Without built-in
def intersection_manual(nums1: List[int], nums2: List[int]) -> List[int]:
    """Manual approach"""
    set1 = set(nums1)
    result = []
    
    for num in nums2:
        if num in set1:
            result.append(num)
            set1.remove(num)  # Tránh duplicates
    
    return result

# Test
print(intersection([1,2,2,1], [2,2]))  # [2]
```

## 4. Ghi nhớ nhanh

| Operation | Code |
|-----------|------|
| Union | set1 \| set2 |
| Intersection | set1 & set2 |
| Difference | set1 - set2 |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 215 / 2000 |
| **XP** | 2150 |