# Bài 204 — LeetCode: Merge Two Sorted Lists (Easy)

## 1. Ôn tập

Ta đã dùng Two Pointers để kiểm tra palindrome và xóa duplicates. Hôm nay dùng để MERGE hai sorted lists!

## 2. Mục tiêu bài học

- Merge hai sorted linked lists
- Dùng dummy node
- Hiểu cách linked list hoạt động

## 3. Code chính (có comment)

```python
# Định nghĩa ListNode
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next

def merge_two_lists(l1: ListNode, l2: ListNode) -> ListNode:
    """
    Merge 2 sorted lists thành 1 sorted list
    Input: l1=[1,2,4], l2=[1,3,4]
    Output: [1,1,2,3,4,4]
    """
    # Dummy node - tránh edge case
    dummy = ListNode(-1)
    current = dummy
    
    # So sánh từng node
    while l1 and l2:
        if l1.val <= l2.val:
            current.next = l1
            l1 = l1.next
        else:
            current.next = l2
            l2 = l2.next
        current = current.next
    
    # Nối phần còn lại (l1 hoặc l2)
    current.next = l1 if l1 else l2
    
    return dummy.next

# Test helper
def create_list(arr):
    dummy = ListNode()
    current = dummy
    for val in arr:
        current.next = ListNode(val)
        current = current.next
    return dummy.next

def print_list(node):
    result = []
    while node:
        result.append(node.val)
        node = node.next
    return result

# Run
l1 = create_list([1, 2, 4])
l2 = create_list([1, 3, 4])
result = merge_two_lists(l1, l2)
print(print_list(result))  # [1, 1, 2, 3, 4, 4]
```

## 4. Trace chạy code

```
l1=[1,2,4], l2=[1,3,4]
dummy →

Compare 1 vs 1: l1 <= l2 → dummy.next=l1(1)
Compare 2 vs 1: l2 < l1 → dummy.next.next=l2(1)  
Compare 2 vs 3: l1 < l2 → ...
...

Result: 1→1→2→3→4→4
```

## 5. Debug tư duy

### Tại sao cần dummy?
```python
# Không có dummy: phải handle head separately
if l1.val < l2.val:
    head = l1  # Complex!

# Có dummy: luôn append vào tail
dummy = ListNode(-1)  # Always works!
```

### Đừng quên .next!
```python
# Sai: Quên gán next
current = l1  # Wrong!

# Đúng: Gán next rồi mới move
current.next = l1
current = current.next
```

## 6. Ghi nhớ nhanh

| Method | Time | Space |
|--------|------|-------|
| This | O(n+m) | O(1) |
| Recursive | O(n+m) | O(n+m) |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 204 / 2000 |
| **XP** | 2040 |