# Bài 462 — Merge Sorted Array (Easy)

## 1. Ôn tập

Từ bài 461, ta đã học Island Perimeter. Hôm nay ta học **Merge Sorted Array**!

## 2. Mục tiêu bài học

- Merge 2 sorted arrays
- Merge từ cuối về
- O(m+n)

## 3. Code chính (có comment)

```python
def merge(nums1, m, nums2, n):
    """
    Merge Sorted Array
    Input: nums1=[1,2,3,0,0,0], m=3, nums2=[2,5,6], n=3
    Output: nums1=[1,2,2,3,5,6]
    """
    p1 = m - 1
    p2 = n - 1
    p = m + n - 1
    
    while p1 >= 0 and p2 >= 0:
        if nums1[p1] > nums2[p2]:
            nums1[p] = nums1[p1]
            p1 -= 1
        else:
            nums1[p] = nums2[p2]
            p2 -= 1
        p -= 1
    
    # Copy remaining
    while p2 >= 0:
        nums1[p] = nums2[p2]
        p2 -= 1
        p -= 1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 462 / 2000 |
| **Chapter** | Two Pointers |
| **XP** | 4620 |