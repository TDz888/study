# Bài 64 — HTTP Requests

---

## 1. Ôn tập
Học gửi **HTTP requests** trong Python.

---

## 2. Mục tiêu
- requests library
- GET, POST requests
- Headers
- Error handling

---

## 3. HTTP Requests

```python
import requests

# GET request
response = requests.get("https://api.github.com")
print(response.status_code)
print(response.json())

# GET với params
params = {"key": "value", "page": 1}
response = requests.get("https://api.example.com", params=params)

# POST request
data = {"username": "admin", "password": "123"}
response = requests.post("https://api.example.com/login", json=data)

# Headers
headers = {"Authorization": "Bearer token"}
response = requests.get("https://api.example.com", headers=headers)
```

---

## 4. Error Handling

```python
try:
    response = requests.get("https://api.example.com", timeout=5)
    response.raise_for_status()
    print(response.json())
except requests.exceptions.Timeout:
    print("Timeout")
except requests.exceptions.HTTPError as e:
    print(f"HTTP error: {e}")
except requests.exceptions.RequestException as e:
    print(f"Error: {e}")
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 64 / 2000 |
| **XP** | 640 |
| **Level** | Intermediate |