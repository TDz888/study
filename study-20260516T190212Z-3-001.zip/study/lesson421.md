# Bài 421 — All Elements in Two BSTs (Medium)

## 1. Ôn tập

Từ bài 420, ta đã học Minimum Difference in BST. Hôm nay ta học **All Elements in Two BSTs**!

## 2. Mục tiêu bài học

- Merge elements từ 2 BSTs thành sorted list
- Inorder traversals + merge
- O(m+n)

## 3. Code chính (có comment)

```python
def get_all_elements(root1, root2):
    """
    All Elements in Two BSTs
    Input: 2 BSTs
    Output: Sorted list của tất cả elements
    """
    def inorder(node, arr):
        if not node:
            return
        inorder(node.left, arr)
        arr.append(node.val)
        inorder(node.right, arr)
    
    vals1, vals2 = [], []
    inorder(root1, vals1)
    inorder(root2, vals2)
    
    # Merge sorted lists
    result = []
    i = j = 0
    while i < len(vals1) and j < len(vals2):
        if vals1[i] < vals2[j]:
            result.append(vals1[i])
            i += 1
        else:
            result.append(vals2[j])
            j += 1
    result.extend(vals1[i:])
    result.extend(vals2[j:])
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 421 / 2000 |
| **Chapter** | Trees |
| **XP** | 4210 |