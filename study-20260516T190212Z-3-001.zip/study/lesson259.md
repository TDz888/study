# Bài 259 — Postorder Traversal (Easy)

## 1. Ôn tập

Từ bài 258, ta đã học Preorder. Hôm nay ta học **Postorder Traversal** - duyệt sau root!

## 2. Mục tiêu bài học

- Duyệt: Left → Right → Root
- Dùng để xóa cây, postfix expression
- Luôn visit root CUỐI

## 3. Code chính (có comment)

```python
def postorder_traversal(root: TreeNode) -> list:
    """
    Postorder: Left → Right → Root
    Input: root = [1,2,3,None,None,4]
    Output: [4,3,2,1]
    """
    result = []
    
    def traverse(node):
        if not node:
            return
        # 1. Duyệt cây con bên trái
        traverse(node.left)
        # 2. Duyệt cây con bên phải
        traverse(node.right)
        # 3. Visit root CUỐI CÙNG
        result.append(node.val)
    
    traverse(root)
    return result
```

## 4. Quy trình duyệt

```
       4
      / \
     2   6
    / \ / \
   1  3 5  7

Postorder: 1 → 3 → 2 → 5 → 7 → 6 → 4
```

## 5. Ứng dụng

| Ứng dụng | Mô tả |
|----------|-------|
| **Xóa cây** | Xóa con trước rồi mới xóa cha |
| **Postfix expression** | Tính biểu thức toán |
| **Directory cleanup** | Xóa thư mục con trước |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 259 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2590 |