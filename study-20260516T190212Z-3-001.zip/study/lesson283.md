# Bài 283 — Maximum Area of Island (Medium)

## 1. Ôn tập

Từ bài 282, ta đã học Keys and Rooms. Hôm nay ta học **tìm island lớn nhất** trong grid!

## 2. Mục tiêu bài học

- Tìm max area của island (connected 1s)
- Dùng DFS để explore từng island
- Track max area

## 3. Code chính (có comment)

```python
def max_area_of_island(grid):
    """
    Tìm island lớn nhất
    Input: [[1,1,0,0],[1,1,0,1]]
    Output: 4 (island to nhất)
    """
    max_area = 0
    rows, cols = len(grid), len(grid[0])
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return 0
        if grid[r][c] == 0:
            return 0
        
        grid[r][c] = 0  # Mark as visited
        
        # Explore 4 directions
        return 1 + dfs(r+1,c) + dfs(r-1,c) + dfs(r,c+1) + dfs(r,c-1)
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 1:
                max_area = max(max_area, dfs(r, c))
    
    return max_area
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 283 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2830 |