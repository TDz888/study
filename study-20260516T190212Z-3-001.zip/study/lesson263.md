# Bài 263 — Same Tree (Easy)

## 1. Ôn tập

Từ bài 262, ta đã học Minimum Depth. Hôm nay ta học **so sánh 2 cây** có giống nhau không!

## 2. Mục tiêu bài học

- Kiểm tra 2 cây có cấu trúc và giá trị giống nhau
- Duyệt đồng thời 2 cây
- Base case: cả 2 đều None → True

## 3. Code chính (có comment)

```python
def is_same_tree(p: TreeNode, q: TreeNode) -> bool:
    """
    Kiểm tra 2 cây có giống nhau không
    Input: p = [1,2,3], q = [1,2,3]
    Output: True
    """
    # Base case: cả 2 đều None → giống nhau
    if not p and not q:
        return True
    
    # Một trong 2 là None → không giống
    if not p or not q:
        return False
    
    # Kiểm tra: giá trị root + cả 2 cây con
    return (p.val == q.val and
            is_same_tree(p.left, q.left) and
            is_same_tree(p.right, q.right))
```

## 4. Ví dụ

```
Cây p:     Cây q:     Kết quả:
   1          1          True (giống nhau)
  / \        / \
 2   3      2   3
```

```
Cây p:     Cây q:     Kết quả:
   1          1          False
  /            \
 2              2
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 263 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2630 |