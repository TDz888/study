# Bài 347 — Word Frequency (Medium)

## 1. Ôn tập

Từ bài 346, ta đã học Candy. Hôm nay ta học **Word Frequency**!

## 2. Mục tiêu bài học

- Đếm word frequency từ input
- Dùng Counter
- Sort by frequency

## 3. Code chính (có comment)

```python
from collections import Counter

def word_frequency(words):
    """
    Word Frequency
    Input: ["the","day","is","sunny","the","sunny","is","is"]
    Output: [("the",2),("is",3),("sunny",2),("day",1)]
    """
    counts = Counter(words)
    
    # Sort by frequency (desc) và alphabetical
    sorted_words = sorted(counts.items(), key=lambda x: (-x[1], x[0]))
    
    return sorted_words
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 347 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3470 |