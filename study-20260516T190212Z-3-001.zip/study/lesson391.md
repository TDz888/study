# Bài 391 — Number of 1 Bits (Easy)

## 1. Ôn tập

Từ bài 390, ta đã học Single Number. Hôm nay ta học **Number of 1 Bits**!

## 2. Mục tiêu bài học

- Đếm số bit 1 trong number
- Brian Kernighan's algorithm
- O(k) where k = số bits

## 3. Code chính (có comment)

```python
def hamming_weight(n):
    """
    Number of 1 Bits
    Input: n=11 (binary: 1011)
    Output: 3
    """
    count = 0
    
    while n:
        n &= n - 1  # Clear lowest 1 bit
        count += 1
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 391 / 2000 |
| **Chapter** | Bit Manipulation |
| **XP** | 3910 |