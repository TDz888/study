# Bài 129 — itertools (P1)

---

## 1. itertools - Infinite Iterators

```python
import itertools

# count(start, step)
for i in itertools.count(5, 2):
    if i > 15: break
    print(i, end=' ')  # 5 7 9 11 13 15

# cycle
colors = itertools.cycle(['red', 'green', 'blue'])
for _ in range(6):
    print(next(colors), end=' ')  # red green blue red green blue

# repeat
for i in itertools.repeat(5, 3):
    print(i, end=' ')  # 5 5 5
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 129 / 2000 |
| **XP** | 1290 |
| **Level** | Intermediate |