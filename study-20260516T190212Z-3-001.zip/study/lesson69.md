# Bài 69 — Pytest

---

## 1. Ôn tập
Học **pytest** — testing framework phổ biến.

---

## 2. Mục tiêu
- pytest installation
- Test discovery
- Fixtures
- Parametrized tests

---

## 3. Pytest cơ bản

```python
# Cài đặt
# pip install pytest

# Test file: test_example.py
def test_add():
    assert 1 + 1 == 2

def test_multiply():
    assert 2 * 3 == 6

# Run
# pytest
# pytest -v (verbose)
# pytest -k "test_name"
```

---

## 4. Fixtures

```python
import pytest

@pytest.fixture
def sample_data():
    return [1, 2, 3, 4, 5]

def test_sum(sample_data):
    assert sum(sample_data) == 15

# Fixture với cleanup
@pytest.fixture
def temp_file(tmp_path):
    file = tmp_path / "test.txt"
    file.write_text("content")
    yield file
    file.unlink()  # cleanup
```

---

## 5. Parametrized Tests

```python
@pytest.mark.parametrize("input,expected", [
    (1, 2),
    (2, 3),
    (3, 4),
])
def test_increment(input, expected):
    assert input + 1 == expected
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 69 / 2000 |
| **XP** | 690 |
| **Level** | Intermediate |