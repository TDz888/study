# Bài 173 — Generator Pipelines

## 1. Ôn tập

`yield from` cho phép kết hợp generators. Hôm nay ta học cách tạo **Generator Pipeline** - chuỗi xử lý dữ liệu!

## 2. Mục tiêu bài học

- Tạo pipeline xử lý dữ liệu
- Kết hợp map/filter/sort trên generator
- Memory efficient data processing

## 3. Code chính (có comment)

```python
# Pipeline: Input → Transform → Filter → Output

def numbers():
    """Nguồn dữ liệu"""
    for i in range(1, 11):
        yield i

def double(n):
    """Transform: nhân đôi"""
    return n * 2

def is_even(n):
    """Filter: chỉ lấy số chẵn"""
    return n % 2 == 0

def add_suffix(n):
    """Transform: thêm hậu tố"""
    return f"Number: {n}"

# Cách 1: Dùng for loop
def pipeline_basic():
    result = []
    for n in numbers():
        n = double(n)
        if is_even(n):
            n = add_suffix(n)
            result.append(n)
    return result

# Cách 2: Generator pipeline - TIẾT KIỆM MEMORY!
def pipeline_generator():
    return (
        add_suffix(n)
        for n in numbers()
        if is_even(double(n)))
    )

# Cách 3: Chain generators (pipeline thực sự)
def chain_pipeline():
    # numbers → double → filter → map
    nums = numbers()
    doubled = (double(n) for n in nums)        # Transform
    filtered = (n for n in doubled if is_even(n))  # Filter
    result = (add_suffix(n) for n in filtered)    # Transform
    
    return result

# Test
print("Basic:", pipeline_basic())
print("Generator:", list(pipeline_generator()))
print("Chain:", list(chain_pipeline()))
```

## 4. Trace chạy code

```
Basic: ['Number: 4', 'Number: 8', 'Number: 12', 'Number: 16', 'Number: 20']
Generator: ['Number: 4', 'Number: 8', 'Number: 12', 'Number: 16', 'Number: 20']
Chain: ['Number: 4', 'Number: 8', 'Number: 12', 'Number: 16', 'Number: 20']
```

## 5. Debug tư duy

### Tại sao dùng Pipeline?
- **Memory:** List cần tạo hết trong RAM → Generator chỉ cần 1 phần tử
- **Speed:** Xử lý từng phần tử ngay → không cần chờ tạo full list
- **Scalability:** Works với data lớn, thậm chí infinite!

### Infinite Pipeline
```python
def natural_numbers():
    n = 1
    while True:
        yield n
        n += 1

def infinite_pipeline():
    # Tất cả đều lazy!
    nums = natural_numbers()        # Vô hạn
    squared = (n**2 for n in nums)  # Lazy
    evens = (n for n in squared if n % 2 == 0)  # Lazy
    return evens

# Lấy 5 giá trị đầu
result = []
gen = infinite_pipeline()
for _ in range(5):
    result.append(next(gen))
print(result)  # [4, 16, 36, 64, 100]
```

## 6. Ghi nhớ nhanh

| Kỹ thuật | Cú pháp |
|----------|---------|
| Map | `(transform(x) for x in gen)` |
| Filter | `(x for x in gen if condition)` |
| Chain | `(... for ... in (gen1 for ...))` |
| Lazy | Không tính đến khi cần |

## 7. Mini test (3 câu)

**Câu 1:** Generator pipeline tiết kiệm gì so với list?
- A) CPU
- B) Memory
- C) Network
- D) Disk

**Câu 2:** Pipeline nào là lazy evaluation?
- A) list comprehension
- B) generator expression trong pipeline
- C) Cả hai đều lazy
- D) Không có

**Câu 3:** Có thể tạo pipeline với data vô hạn không?
- A) Không
- B) Có - Generator cho phép
- C) Chỉ với list
- D) Cần special code

**Đáp án:** 1-B, 2-B, 3-B

## 8. LeetCode practice

**Bài:** "Data Pipeline"

```python
# Tạo pipeline xử lý:
# 1. Lấy số từ 1-1000
# 2. Bình phương
# 3. Lọc số > 500
# 4. Lấy 10 số đầu

def create_pipeline():
    # Viết code
    pass
```

## 9. Bonus

Tạo:
- CSV reader → transform → write pipeline
- Log processor: parse → filter → aggregate
- Image processor: load → transform → save

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 173 / 2000 |
| **XP** | 1730 |