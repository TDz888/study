# Bài 303 — Edit Distance (Hard)

## 1. Ôn tập

Từ bài 302, ta đã học Longest Palindromic Subsequence. Hôm nay ta học **Edit Distance** - DP kinh điển!

## 2. Mục tiêu bài học

- Tìm min operations để convert word1 → word2
- Operations: insert, delete, replace
- dp[i][j] = min distance cho prefix lengths

## 3. Code chính (có comment)

```python
def min_distance(word1, word2):
    """
    Edit Distance
    Input: word1="horse", word2="ros"
    Output: 3 (horse→rorse→rose→ros)
    """
    m, n = len(word1), len(word2)
    # dp[i][j] = min ops cho word1[:i] → word2[:j]
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    
    # Base: empty string
    for i in range(m + 1):
        dp[i][0] = i  # Delete all
    for j in range(n + 1):
        dp[0][j] = j  # Insert all
    
    # Fill dp
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if word1[i-1] == word2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = min(dp[i-1][j],    # delete
                               dp[i][j-1],    # insert
                               dp[i-1][j-1]) + 1  # replace
    
    return dp[m][n]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 303 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3030 |