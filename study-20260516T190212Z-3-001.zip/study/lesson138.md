# Bài 138 — weakref module

---

## 1. weakref module

```python
import weakref

# Weak reference
class MyClass:
    def __init__(self, value):
        self.value = value

obj = MyClass(10)
ref = weakref.ref(obj)
print(ref()) is obj  # True

# WeakValueDictionary
class Database:
    def __init__(self):
        self.cache = weakref.WeakValueDictionary()
    
    def get(self, key):
        return self.cache.get(key)
    
    def set(self, key, value):
        self.cache[key] = value

db = Database()
db.set('name', 'Hello')
print(db.get('name'))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 138 / 2000 |
| **XP** | 1380 |
| **Level** | Advanced |