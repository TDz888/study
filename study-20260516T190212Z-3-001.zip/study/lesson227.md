# Bài 227 — Course Schedule (Medium)

## 1. Ôn tập

Từ bài 226, ta đã học Word Ladder. Hôm nay ta học **Course Schedule** - kiểm tra có cycle không!

## 2. Mục tiêu bài học

- Detect cycle trong directed graph
- Topological sort
- DFS với 3 states: unvisited, visiting, visited

## 3. Code chính (có comment)

```python
def can_finish(num_courses: int, prerequisites: List[List[int]]) -> bool:
    """
    Kiểm tra có thể hoàn thành tất cả courses không
    Input: num=2, prereq=[[1,0]]
    Output: True
    """
    # Build graph: course -> các courses phụ thuộc
    graph = [[] for _ in range(num_courses)]
    for dest, src in prerequisites:
        graph[src].append(dest)
    
    # 0=unvisited, 1=visiting, 2=visited
    state = [0] * num_courses
    
    def has_cycle(course):
        if state[course] == 1:  # Cycle detected
            return True
        if state[course] == 2:  # Already processed
            return False
        
        state[course] = 1  # Đánh dấu đang visit
        
        for next_course in graph[course]:
            if has_cycle(next_course):
                return True
        
        state[course] = 2  # Hoàn thành
        return False
    
    for i in range(num_courses):
        if has_cycle(i):
            return False
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 227 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2270 |