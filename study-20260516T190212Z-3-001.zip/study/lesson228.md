# Bài 228 — Course Schedule II (Medium)

## 1. Ôn tập

Từ bài 227, ta đã học kiểm tra cycle. Hôm nay ta học **Course Schedule II** - tìm order!

## 2. Mục tiêu bài học

- Tìm topological order
- Return valid course order
- Dùng Kahn's algorithm hoặc DFS

## 3. Code chính (có comment)

```python
def find_order(num_courses: int, prerequisites: List[List[int]]) -> List[int]:
    """
    Tìm thứ tự hoàn thành courses
    Input: num=4, prereq=[[1,0],[2,0],[3,1],[3,2]]
    Output: [0,1,2,3] hoặc [0,2,1,3]
    """
    # Build graph và in-degree
    graph = [[] for _ in range(num_courses)]
    in_degree = [0] * num_courses
    
    for dest, src in prerequisites:
        graph[src].append(dest)
        in_degree[dest] += 1
    
    # Start với courses có in-degree = 0
    queue = [i for i in range(num_courses) if in_degree[i] == 0]
    result = []
    
    while queue:
        course = queue.pop(0)
        result.append(course)
        
        for next_course in graph[course]:
            in_degree[next_course] -= 1
            if in_degree[next_course] == 0:
                queue.append(next_course)
    
    return result if len(result) == num_courses else []
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 228 / 2000 |
| **Chapter** | Graph Algorithms |
| **XP** | 2280 |