# Bài 189 — Practice: Async File Processor

## 1. Project

Xử lý file async: batch process large files

## 2. Code

```python
import asyncio
import aiofiles

async def process_file(filepath, chunk_size=1024*1024):
    async with aiofiles.open(filepath, 'rb') as f:
        while chunk := await f.read(chunk_size):
            await process_chunk(chunk)

async def process_batch(filepaths):
    sem = asyncio.Semaphore(10)
    async def limited_process(path):
        async with sem:
            await process_file(path)
    await asyncio.gather(*[limited_process(p) for p in filepaths])
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 189 / 2000 |
| **XP** | 1890 |