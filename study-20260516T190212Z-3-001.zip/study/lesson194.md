# Bài 194 — CLI Tool

## 1. Project

Build command-line tool với argparse

## 2. Code

```python
import argparse

def main():
    parser = argparse.ArgumentParser(description="My CLI Tool")
    parser.add_argument("command", choices=["run", "stop", "status"])
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("-n", "--name", default="world")
    
    args = parser.parse_args()
    
    if args.verbose:
        print(f"Command: {args.command}")
        print(f"Name: {args.name}")
    
    if args.command == "run":
        print(f"Running {args.name}...")
    elif args.command == "stop":
        print(f"Stopping {args.name}...")

if __name__ == "__main__":
    main()
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 194 / 2000 |
| **XP** | 1940 |