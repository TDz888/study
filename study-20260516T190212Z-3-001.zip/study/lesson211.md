# Bài 211 — LeetCode: Binary Search (Easy)

## 1. Ôn tập

Bài 210 dùng pointers để reverse linked list. Hôm nay ta học **Binary Search** - O(log n) algorithm cơ bản nhất!

## 2. Mục tiêu bài học

- Tìm kiếm trong sorted array
- Công thức: mid = left + (right - left) // 2
- Handle edge cases

## 3. Code chính (có comment)

def search(nums: List[int], target: int) -> int:
    """
    Binary Search - tìm target trong sorted array
    Input: nums = [-1,0,3,5,9,12], target = 9
    Output: 4 (nums[4]=9)
    """
    left, right = 0, len(nums) - 1
    
    while left <= right:
        # Tránh overflow
        mid = left + (right - left) // 2
        
        if nums[mid] == target:
            return mid
        elif nums[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1  # Not found

# Test
nums = [-1, 0, 3, 5, 9, 12]
print(search(nums, 9))    # 4
print(search(nums, 2))    # -1
```

## 4. Trace chạy code

```
nums = [-1,0,3,5,9,12], target=9

left=0, right=5, mid=2, nums[2]=3 < 9 → left=3
left=3, right=5, mid=4, nums[4]=9 == 9 → return 4
```

## 5. Ghi nhớ nhanh

| Condition | Action |
|-----------|--------|
| nums[mid] == target | Return mid |
| nums[mid] < target | left = mid + 1 |
| nums[mid] > target | right = mid - 1 |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 211 / 2000 |
| **XP** | 2110 |