# Lesson 473 — Set Mismatch

---

## 1. KNOWLEDGE CONNECTION

Từ bài 472, bạn đã học **Find Disappeared** - đánh dấu trên array. Bài hôm nay **Set Mismatch** tìm cả số bị duplicate VÀ số bị mất. Kết hợp cả hai kỹ thuật.

## 2. TODAY'S MISSION

- Tìm duplicate và missing number
- Input có đúng 1 duplicate
- O(n) time, O(1) space

## 3. MAIN CODE

```python
def find_error_nums(nums):
    """
    Tìm số trùng và số thiếu
    
    Input: [1,2,2,4]
    Output: [2,3]
    """
    for num in nums:
        idx = abs(num) - 1
        if nums[idx] > 0:
            nums[idx] = -nums[idx]
        else:
            duplicate = abs(num)
    
    for i in range(len(nums)):
        if nums[i] > 0:
            missing = i + 1
    
    return [duplicate, missing]
```

## 4-13. Practice

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 473 / 2000 |
| **XP** | +25 |