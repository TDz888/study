# Bài 376 — Find Peak Element (Medium)

## 1. Ôn tập

Từ bài 375, ta đã học Search in Rotated Array. Hôm nay ta học **Find Peak Element**!

## 2. Mục tiêu bài học

- Tìm peak element (lớn hơn neighbors)
- Binary search approach
- O(log n)

## 3. Code chính (có comment)

```python
def find_peak(nums):
    """
    Find Peak Element
    Input: [1,2,3,1]
    Output: 2 (3 is peak)
    """
    left, right = 0, len(nums) - 1
    
    while left < right:
        mid = (left + right) // 2
        
        if nums[mid] < nums[mid + 1]:
            left = mid + 1
        else:
            right = mid
    
    return left
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 376 / 2000 |
| **Chapter** | Binary Search |
| **XP** | 3760 |