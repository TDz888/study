# Bài 236 — Binary Tree Level Order Traversal (Medium)

## 1. Ôn tập

Từ bài 235, ta đã học Union-Find. Hôm nay ta chuyển sang **Binary Tree** - Level Order!

## 2. Mục tiêu bài học

- Duyệt tree theo từng level
- Dùng BFS với queue
- Output: list của các lists

## 3. Code chính (có comment)

```python
from collections import deque

def level_order(root: TreeNode) -> List[List[int]]:
    """
    Duyệt tree theo level
    Input: root = [3,9,20,null,null,15,7]
    Output: [[3],[9,20],[15,7]]
    """
    if not root:
        return []
    
    result = []
    queue = deque([root])
    
    while queue:
        level_size = len(queue)
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)
            
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 236 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2360 |