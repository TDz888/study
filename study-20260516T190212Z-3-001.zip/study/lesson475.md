# Lesson 475 — Minimum Number of Moves

---

## 1. KNOWLEDGE CONNECTION

Từ bài 474, bạn đã học **Find Lucky** với Counter. Bài hôm nay **Minimum Number of Moves** - đếm số bước để tất cả phần tử bằng nhau. Dùng median concept.

## 2. TODAY'S MISSION

- Move elements bằng cách increment/decrement
- Optimal: di chuyển đến median
- Sum of absolute differences

## 3. MAIN CODE

```python
def min_moves(nums):
    """
    Minimum moves to equal elements
    
    Input: [1,2,3]
    Output: 2 (1→2, 3→2)
    """
    nums.sort()
    median = nums[len(nums)//2]
    return sum(abs(x - median) for x in nums)
```

## 4-13. Progress

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 475 / 2000 |
| **XP** | +25 |