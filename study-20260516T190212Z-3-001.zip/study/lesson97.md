# Bài 97 — aiohttp (Async HTTP)

---

## 1. Async HTTP Requests

```python
import aiohttp
import asyncio

async def fetch(url):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            return await response.text()

async def main():
    html = await fetch('https://example.com')
    print(html[:100])

asyncio.run(main())
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 97 / 2000 |
| **XP** | 970 |
| **Level** | Advanced |