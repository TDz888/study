# Bài 209 — LeetCode: Container With Most Water (Medium)

## 1. Ôn tập

Bài 208 dùng Two Pointers + sort. Hôm nay ta dùng **Two Pointers từ hai đầu** để tìm max water!

## 2. Mục tiêu bài học

- Tìm container chứa nhiều nước nhất
- Nắm vững Two Pointers từ hai đầu
- Hiểu tại sao skip bước không cần thiết

## 3. Code chính (có comment)

```python
def max_area(height: List[int]) -> int:
    """
    Tìm max area giữa 2 lines
    Input: [1,8,6,2,5,4,8,3,7]
    Output: 49
    
    Area = min(height[i], height[j]) * (j - i)
    """
    left = 0
    right = len(height) - 1
    max_water = 0
    
    while left < right:
        # Tính area hiện tại
        h = min(height[left], height[right])
        w = right - left
        area = h * w
        
        max_water = max(max_water, area)
        
        # Di chuyển pointer có height nhỏ hơn
        if height[left] < height[right]:
            left += 1
        else:
            right -= 1
    
    return max_water

# Test
height = [1, 8, 6, 2, 5, 4, 8, 3, 7]
print(max_area(height))  # 49
```

## 4. Trace chạy code

```
height = [1,8,6,2,5,4,8,3,7]

l=0, r=8: h=min(1,7)=1, w=8, area=8 → max=8
        height[0]=1 < 7 → l=1

l=1, r=8: h=min(8,7)=7, w=7, area=49 → max=49 ✓
        height[1]=8 > 7 → r=7

l=1, r=7: h=min(8,3)=3, w=6, area=18 → max=49
        height[7]=3 < 8 → l=2

...tiếp tục...
Output: 49
```

## 5. Debug tư duy

### Tại sao chỉ cần di chuyển pointer nhỏ hơn?
```
Nếu height[left] < height[right]:
- Nếu tăng left: area = min(height[new], height[right]) * (w-1)
  → height[new] <= height[left] < height[right]
  → area CHỈ có thể giảm hoặc equal!
- Nếu giảm right: area = min(height[left], height[new]) * (w-1)  
  → Có thể tăng nếu height[new] > height[left]

→ Chỉ cần thử giảm right!
```

### Không cần kiểm tra tất cả pairs!
```python
# Brute force: O(n²) pairs
# Two pointers: O(n) - mỗi step skip n-1 pairs!
```

## 6. Ghi nhớ nhanh

| Approach | Time | Pairs Checked |
|----------|------|---------------|
| Brute Force | O(n²) | n² |
| Two Pointers | O(n) | n |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 209 / 2000 |
| **XP** | 2090 |