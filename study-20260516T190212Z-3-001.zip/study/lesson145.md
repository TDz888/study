# Bài 145 — dataclasses (Advanced)

---

## 1. dataclasses advanced

```python
from dataclasses import dataclass, field
from typing import List

@dataclass
class Person:
    name: str
    age: int
    email: str = field(default="unknown")
    friends: List[str] = field(default_factory=list)
    
    def is_adult(self) -> bool:
        return self.age >= 18

p = Person("Alice", 25)
print(p)
print(p.is_adult())

# Order comparison
@dataclass(order=True)
class Student:
    name: str
    grade: int

s1 = Student("Bob", 90)
s2 = Student("Alice", 95)
print(s1 < s2)  # False (by name when order=True)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 145 / 2000 |
| **XP** | 1450 |
| **Level** | Intermediate |