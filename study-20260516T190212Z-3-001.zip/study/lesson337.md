# Bài 337 — Course Schedule II (Medium)

## 1. Ôn tập

Từ bài 336, ta đã học Gas Station. Hôm nay ta học **Course Schedule II**!

## 2. Mục tiêu bài học

- Return valid course ordering
- Topological sort để get order
- Kết hợp với detect cycle

## 3. Code chính (có comment)

```python
def find_order(num_courses, prerequisites):
    """
    Course Schedule II
    Input: 4, [[1,0],[2,0],[3,1],[3,2]]
    Output: [0,2,3,1] hoặc [0,1,2,3]
    """
    # Build graph và in-degree
    graph = {i: [] for i in range(num_courses)}
    in_degree = [0] * num_courses
    
    for course, prereq in prerequisites:
        graph[prereq].append(course)
        in_degree[course] += 1
    
    # BFS
    queue = [i for i in range(num_courses) if in_degree[i] == 0]
    result = []
    
    while queue:
        node = queue.pop(0)
        result.append(node)
        
        for neighbor in graph[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)
    
    return result if len(result) == num_courses else []
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 337 / 2000 |
| **Chapter** | Graphs |
| **XP** | 3370 |