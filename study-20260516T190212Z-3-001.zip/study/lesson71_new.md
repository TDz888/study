# Lesson 71 — Enum (Enumerations)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 70 - Mini Projects.

**Current Lesson:** Learning **Enum** — define named constants.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- What Enum is
- Creating Enum
- Using Enum in code

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Basic Enum

```python
from enum import Enum, auto

class Color(Enum):
    RED = 1
    GREEN = 2
    BLUE = 3

# Access Enum member
print(Color.RED)          # Color.RED
print(Color.RED.name)     # RED
print(Color.RED.value)    # 1

# Compare Enum
print(Color.RED == Color.GREEN)  # False
print(Color.RED == Color.RED)    # True
```

### Auto Enum

```python
from enum import Enum, auto

class Status(Enum):
    PENDING = auto()
    APPROVED = auto()
    REJECTED = auto()

print(Status.PENDING.value)  # 1
print(Status.APPROVED.value)  # 2
```

### Enum with Methods

```python
class Priority(Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    
    def color(self):
        colors = {1: 'blue', 2: 'yellow', 3: 'red'}
        return colors[self.value]

print(Priority.HIGH.color())  # red
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**How do you access the value of Color.RED?**

> **Answer:** Color.RED.value

---

**Type 72 to continue**