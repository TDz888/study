# Lesson 56 — Context Managers

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 55 - Decorators.

**Current Lesson:** Learning **Context Managers** — safe resource management.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Using `with` statement
- Creating custom context managers
- Resource cleanup
- contextlib decorator

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Basic Context Manager

```python
# File handling - automatically closes
with open("file.txt", "r") as f:
    content = f.read()
# File automatically closed after block
```

### Custom Context Manager

```python
import time

class Timer:
    def __enter__(self):
        self.start = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed = time.time() - self.start
        print(f"Time: {elapsed:.4f}s")

with Timer() as t:
    result = sum(range(1000000))
    print(f"Result: {result}")
```

### Using contextlib

```python
from contextlib import contextmanager

@contextmanager
def my_context():
    print("Enter")
    yield "Resource"
    print("Exit")

with my_context() as r:
    print(f"Got: {r}")
# Enter
# Got: Resource
# Exit
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What methods make a class a context manager?**

> **Answer:** __enter__ and __exit__

---

**Type 57 to continue**