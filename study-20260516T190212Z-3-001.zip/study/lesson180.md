# Bài 180 — Advanced Decorators

## 1. Ôn tập

Ta đã biết basic decorators ở bài 55. Hôm nay học advanced: decorator với arguments, stacking!

## 2. Mục tiêu bài học

- Decorator có arguments
- @wraps (giữ metadata)
- Stacking decorators

## 3. Code chính (có comment)

```python
from functools import wraps

# Decorator với arguments - cần factory function
def repeat(times):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(times=3)
def greet(name):
    print(f"Hello {name}!")

greet("Bob")
# Hello Bob!
# Hello Bob!
# Hello Bob!

# Stacking decorators
def uppercase(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs).upper()
    return wrapper

def exclaim(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs) + "!"
    return wrapper

@uppercase
@exclaim
def say():
    return "hello"

print(say())  # HELLO!
```

## 4. Trace chạy code

```
Hello Bob!
Hello Bob!
Hello Bob!
HELLO!
```

## 5. Ghi nhớ nianh

| Pattern | Cấu trúc |
|---------|----------|
| Basic | `@decorator` |
| With args | `@decorator(args)` + factory |
| Stacking | `@a` + `@b` trên cùng function |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 180 / 2000 |
| **XP** | 1800 |