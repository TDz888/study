# Lesson 68 — Unit Testing (P2)

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 67 - Unit Testing (P1).

**Current Lesson:** Advanced testing techniques.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Mock objects
- Patch
- Test coverage

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Mock and Patch

```python
from unittest.mock import Mock, patch, MagicMock

# Create mock
mock = Mock()
mock.return_value = 42
print(mock())  # 42

# Patch
class MyAPI:
    def get_data(self):
        return "real data"

@patch('__main__.MyAPI.get_data')
def test_api(mock_get):
    mock_get.return_value = "mock data"
    api = MyAPI()
    print(api.get_data())  # "mock data"

# MagicMock for more complex mocking
mock_obj = MagicMock()
mock_obj.method.return_value = "result"
```

### Test Coverage

```bash
# pip install coverage
coverage run -m unittest discover
coverage report
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does @patch decorator do?**

> **Answer:** Replaces a function/class with a mock during test

---

**Type 69 to continue**