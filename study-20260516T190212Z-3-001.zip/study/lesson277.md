# Bài 277 — Number of Islands (Medium)

## 1. Ôn tập

Từ bài 276, ta đã học DFS. Hôm nay ta học **đếm số đảo** trong matrix!

## 2. Mục tiêu bài học

- Grid: 1 = land, 0 = water
- Island: group của các ô 1 nối nhau (4 directions)
- Dùng DFS/BFS để flood fill

## 3. Code chính (có comment)

```python
def num_islands(grid):
    """
    Đếm số đảo trong grid
    Input: grid = [
      ["1","1","0","0","0"],
      ["1","1","0","0","0"],
      ["0","0","1","0","0"],
      ["0","0","0","1","1"]
    ]
    Output: 3
    """
    if not grid:
        return 0
    
    count = 0
    rows, cols = len(grid), len(grid[0])
    
    def dfs(r, c):
        # Kiểm tra boundary và có phải land không
        if r < 0 or r >= rows or c < 0 or c >= cols or grid[r][c] == "0":
            return
        
        # Mark là visited
        grid[r][c] = "0"
        
        # DFS 4 directions
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)
    
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == "1":
                count += 1
                dfs(r, c)
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 277 / 2000 |
| **Chapter** | Graphs |
| **XP** | 2770 |