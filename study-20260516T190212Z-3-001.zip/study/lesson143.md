# Bài 143 — typing (P1)

---

## 1. typing - Type Hints

```python
from typing import List, Dict, Tuple, Optional, Union

# List
def process(items: List[int]) -> int:
    return sum(items)

# Dict
def count(words: List[str]) -> Dict[str, int]:
    return {w: words.count(w) for w in set(words)}

# Tuple
def get_coords() -> Tuple[int, int]:
    return (10, 20)

# Optional
def find_user(name: Optional[str]) -> str:
    return name if name else "Guest"

# Union
def parse(value: Union[int, str]) -> int:
    return int(value)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 143 / 2000 |
| **XP** | 1430 |
| **Level** | Intermediate |