# Bài 166 — Context Manager với async

## 1. Ôn tập

Ta đã quen dùng `async with` cho Lock, Condition. Nhưng tự tạo async context manager thì sao?

## 2. Mục tiêu bài học

- Hiểu `__aenter__` và `__aexit__`
- Tự tạo async context manager
- Dùng cho resource management

## 3. Code chính (có comment)

```python
import asyncio

class AsyncDatabase:
    """Database connection với async context manager"""
    
    def __init__(self, name):
        self.name = name
        self.connected = False
    
    async def connect(self):
        await asyncio.sleep(0.5)  # Giả lập kết nối
        self.connected = True
        print(f"Connected to {self.name}")
    
    async def disconnect(self):
        await asyncio.sleep(0.1)
        self.connected = False
        print(f"Disconnected from {self.name}")
    
    async def query(self, sql):
        if not self.connected:
            raise Exception("Not connected!")
        await asyncio.sleep(0.2)
        return f"Result: {sql}"
    
    # Quan trọng: Định nghĩa async context manager
    async def __aenter__(self):
        await self.connect()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.disconnect()
        return False  # Không suppress exception

# Cách dùng
async def main():
    async with AsyncDatabase("users") as db:
        result = await db.query("SELECT * FROM users")
        print(result)
    
    # Tự động disconnect khi ra khỏi block!

asyncio.run(main())
```

## 4. Trace chạy code

```
Connected to users
Result: SELECT * FROM users
Disconnected from users
```

## 5. Debug tư duy

### Sai lầm thường gặp
**Sai:** Dùng __enter__ thay vì __aenter__

```python
class Wrong:
    def __enter__(self):  # Sync!
        return self
    
    async def __aenter__(self):  # Async
        return self
```

**Đúng:** Cả hai nếu muốn hỗ trợ cả sync và async

```python
class Both:
    def __enter__(self):
        return self
    
    async def __aexit__(self, *args):
        pass
```

## 6. Ghi nhớ nhanh

| Phương thức | Công dụng |
|-------------|-----------|
| `__aenter__` | Được gọi khi vào `async with` |
| `__aexit__` | Được gọi khi ra khỏi `async with` |
| `return self` trong enter | Để dùng `as db` |
| `return False` trong exit | Không suppress exception |

## 7. Mini test (3 câu)

**Câu 1:** Async context manager định nghĩa những phương thức nào?
- A) __enter__ và __exit__
- B) __aenter__ và __aexit__
- C) start và stop
- D) open và close

**Câu 2:** __aexit__ có bao nhiêu tham số?
- A) 1
- B) 2
- C) 3
- D) 4

**Câu 3:** Để dùng `as db` trong `async with` thì __aenter__ phải...
- A) Không return gì
- B) Return None
- C) Return self
- D) Return True

**Đáp án:** 1-B, 2-C, 3-C

## 8. LeetCode practice

**Bài:** "Async File Handler"

```python
class AsyncFileWriter:
    def __init__(self, filename):
        self.filename = filename
        self.file = None
    
    async def __aenter__(self):
        self.file = open(self.filename, 'w')
        return self
    
    async def __aexit__(self, *args):
        if self.file:
            self.file.close()
    
    async def write(self, text):
        # Viết async
        pass
```

## 9. Bonus

Tạo:
- AsyncFileReader
- Kết hợp cả đọc và ghi
- Test với contextlib.asynccontextmanager

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 166 / 2000 |
| **XP** | 1660 |