# Bài 253 — Search in BST (Easy)

## 1. Ôn tập

Từ bài 252, ta đã học merge trees. Hôm nay ta học **Search in BST**!

## 2. Mục tiêu bài học

- Tìm node trong BST
- BST property: left < root < right
- O(log n) cho balanced tree

## 3. Code chính (có comment)

```python
def search_bst(root: TreeNode, val: int) -> TreeNode:
    """
    Tìm node có giá trị val
    Input: root = [4,2,7,1,3], val = 2
    Output: node với val = 2
    """
    if not root or root.val == val:
        return root
    
    if val < root.val:
        return search_bst(root.left, val)
    return search_bst(root.right, val)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 253 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2530 |