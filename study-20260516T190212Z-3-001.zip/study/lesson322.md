# Bài 322 — Valid Sudoku (Medium)

## 1. Ôn tập

Từ bài 321, ta đã học Longest Consecutive Sequence. Hôm nay ta học **Valid Sudoku**!

## 2. Mục tiêu bài học

- Kiểm tra Sudoku board có valid không
- Check rows, columns, 3x3 boxes
- Dùng sets

## 3. Code chính (có comment)

```python
def is_valid_sudoku(board):
    """
    Valid Sudoku
    Input: 9x9 board
    Output: True/False
    """
    # Check rows
    for row in board:
        seen = set()
        for num in row:
            if num != '.':
                if num in seen:
                    return False
                seen.add(num)
    
    # Check columns
    for col in range(9):
        seen = set()
        for row in range(9):
            num = board[row][col]
            if num != '.':
                if num in seen:
                    return False
                seen.add(num)
    
    # Check 3x3 boxes
    for box_row in range(0, 9, 3):
        for box_col in range(0, 9, 3):
            seen = set()
            for r in range(box_row, box_row + 3):
                for c in range(box_col, box_col + 3):
                    num = board[r][c]
                    if num != '.':
                        if num in seen:
                            return False
                        seen.add(num)
    
    return True
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 322 / 2000 |
| **Chapter** | Hash Table |
| **XP** | 3220 |