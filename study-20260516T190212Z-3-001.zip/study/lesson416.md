# Bài 416 — Sum of Root to Leaf (Medium)

## 1. Ôn tập

Từ bài 415, ta đã học Invert Binary Tree. Hôm nay ta học **Sum of Root to Leaf**!

## 2. Mục tiêu bài học

- Tính sum tất cả root→leaf paths
- Treat binary như binary number
- DFS

## 3. Code chính (có comment)

```python
def sum_root_to_leaf(root):
    """
    Sum Root to Leaf
    Input: [1,0,1]
    Output: 3 (1→0 (10)=2, 1→1 (11)=3)
    """
    def dfs(node, path_val):
        if not node:
            return 0
        
        path_val = path_val * 2 + node.val
        
        if not node.left and not node.right:
            return path_val
        
        return dfs(node.left, path_val) + dfs(node.right, path_val)
    
    return dfs(root, 0)
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 416 / 2000 |
| **Chapter** | Trees |
| **XP** | 4160 |