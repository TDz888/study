# Bài 265 — Path Sum (Easy)

## 1. Ôn tập

Từ bài 264, ta đã học Symmetric Tree. Hôm nay ta học **kiểm tra đường đi có tổng bằng target không**!

## 2. Mục tiêu bài học

- Tìm đường đi từ root đến leaf có tổng = targetSum
- Trừ dần target khi đi xuống
- Leaf: node không có con

## 3. Code chính (có comment)

```python
def has_path_sum(root: TreeNode, target: int) -> bool:
    """
    Kiểm tra có đường đi nào = target không
    Input: root = [5,4,8,11,None,13,4,7,2,None,None,None,1], target = 22
    Output: True (5→4→11→2 = 22)
    """
    if not root:
        return False
    
    # Nếu là leaf → kiểm tra có bằng target không
    if not root.left and not root.right:
        return root.val == target
    
    # Trừ giá trị node hiện tại, đệ quy tiếp
    return (has_path_sum(root.left, target - root.val) or
            has_path_sum(root.right, target - root.val))
```

## 4. Minh họa

```
       5
      / \
     4   8
    /     \
   11     13
  /  \      \
 7    2      4

Target = 22

Đường đi: 5 + 4 + 11 + 2 = 22 ✓
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 265 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2650 |