# Bài 222 — LeetCode: Flood Fill (Easy)

## 1. Ôn tập

Từ bài 220-221, ta đã học DFS trên grid. Hôm nay ta học **Flood Fill** - thay đổi màu từ một điểm!

## 2. Mục tiêu bài học

- Thay đổi color từ start point
- Explore connected cells
- Handle boundary cases

## 3. Code chính (có comment)

```python
def flood_fill(image: List[List[int]], sr: int, sc: int, new_color: int) -> List[List[int]]:
    """
    Flood fill từ (sr, sc)
    Input: image=[[1,1,1],[1,1,0],[1,0,1]], sr=1, sc=1, new=2
    Output: [[2,2,2],[2,2,0],[2,0,1]]
    """
    if not image:
        return image
    
    rows, cols = len(image), len(image[0])
    original_color = image[sr][sc]
    
    # Nếu đã là new color rồi thì return
    if original_color == new_color:
        return image
    
    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols:
            return
        if image[r][c] != original_color:
            return
        
        # Fill
        image[r][c] = new_color
        
        # Explore 4 directions
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)
    
    dfs(sr, sc)
    return image
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 222 / 2000 |
| **XP** | 2220 |