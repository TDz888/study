# Bài 269 — Convert Sorted Array to BST (Easy)

## 1. Ôn tập

Từ bài 268, ta đã học construct tree. Hôm nay ta học **tạo BST từ sorted array**!

## 2. Mục tiêu bài học

- Array đã sort → dễ tạo balanced BST
- Chọn phần tử giữa làm root
- Đệ quy cho left và right half
- Luôn tạo cây cân bằng

## 3. Code chính (có comment)

```python
def sorted_array_to_bst(nums: list) -> TreeNode:
    """
    Tạo BST cân bằng từ sorted array
    Input: nums = [-10,-3,0,5,9]
    Output: [0,-3,9,-10,None,5,None]
    """
    def build(low, high):
        # Base case: không còn phần tử
        if low > high:
            return None
        
        # Chọn phần tử giữa làm root
        mid = (low + high) // 2
        root = TreeNode(nums[mid])
        
        # Đệ quy cho 2 nửa
        root.left = build(low, mid - 1)
        root.right = build(mid + 1, high)
        
        return root
    
    return build(0, len(nums) - 1)
```

## 4. Minh họa

```
nums = [-10, -3, 0, 5, 9]

Chọn mid = 2 (value = 0) làm root
      0
    /   \
  [-10,-3]  [5,9]

Mid = 0 → -3, Mid = 3 → 9

      0
    /   \
   -3    9
  /
-10

→ Balanced BST!
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 269 / 2000 |
| **Chapter** | Binary Trees |
| **XP** | 2690 |