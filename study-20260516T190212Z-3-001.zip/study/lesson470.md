# Lesson 470 — Array Partition I

---

## 1. KNOWLEDGE CONNECTION

Từ bài 469, bạn đã học **Next Permutation** - thuật toán sắp xếp. Bài hôm nay **Array Partition I** sẽ dạy bạn cách pair elements để maximize sum of minimums. Đây là ứng dụng của sorting.

## 2. TODAY'S MISSION

- Pair elements để mỗi pair lấy min, tính tổng max
- Secret: sort rồi lấy chẵn indices
- Cần hiểu tại sao approach này hoạt động

## 3. CONCEPT FOUNDATION

**Array Partition**:
```
Input: nums = [1,4,3,2]
Cặp: (1,2) → min=1, (3,4) → min=3
Tổng = 1 + 3 = 4

Cặp tối ưu: sort [1,2,3,4]
Pairs: (1,2), (3,4) → 1 + 3 = 4
```

## 4. TERMINOLOGY EXPLANATION

- **Pair**: Cặp, ghép 2 phần tử
- **Minimize**: Lấy giá trị nhỏ hơn trong cặp

## 5. MAIN CODE

```python
def array_pair_sum(nums):
    """
    Maximum sum of minimums of pairs
    
    Input: [1,4,3,2]
    Output: 4
    
    Giải thích:
    - Sort: [1,2,3,4]
    - Pair (1,2), (3,4)
    - Minimums: 1, 3
    - Sum = 1 + 3 = 4
    """
    nums.sort()
    return sum(nums[::2])
```

## 6. EXECUTION TRACE

```
nums = [1, 4, 3, 2]
sorted = [1, 2, 3, 4]
indices 0,1,2,3

Lấy nums[0] = 1, nums[2] = 3
Sum = 1 + 3 = 4
```

## 7. VISUAL THINKING MODE

```
[1,4,3,2] → sorted → [1,2,3,4]

┌─────┬─────┬─────┬─────┐
│  1  │  2  │  3  │  4  │
│  ✓  │     │  ✓  │     │
└─────┴─────┴─────┴─────┘
   ↓         ↓
  sum = 1 + 3 = 4
```

## 8. DEBUG THINKING MODE

**Lỗi thường gặp:**
- Pair sai → không lấy min của mỗi cặp
- Không sort trước

## 9. MEMORY REINFORCEMENT

**Key:** Sort rồi lấy elements tại chỉ số chẵn.

## 10-13. Practice & Bonus

Làm bài tương tự để nắm vững pattern.

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 470 / 2000 |
| **XP** | +25 |
| **Mastery** | Greedy + Sorting |