# Bài 68 — Unit Testing (P2)

---

## 1. Ôn tập
Học testing nâng cao.

---

## 2. Mục tiêu
- Mock objects
- Patch
- Test coverage

---

## 3. Mock và Patch

```python
from unittest.mock import Mock, patch, MagicMock

# Tạo mock
mock = Mock()
mock.return_value = 42
print(mock())  # 42

# Patch
class MyAPI:
    def get_data(self):
        return "real data"

@patch('__main__.MyAPI.get_data')
def test_api(mock_get):
    mock_get.return_value = "mock data"
    api = MyAPI()
    print(api.get_data())  # "mock data"

# MagicMock
mock_obj = MagicMock()
mock_obj.method.return_value = "result"
```

---

## 4. Test Coverage

```python
# Chạy với coverage
# pip install coverage
# coverage run -m unittest
# coverage report -m

# Ví dụ function cần test
def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 68 / 2000 |
| **XP** | 680 |
| **Level** | Intermediate |