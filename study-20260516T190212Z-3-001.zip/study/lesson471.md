# Lesson 471 — Missing Number

---

## 1. KNOWLEDGE CONNECTION

Từ bài 470, bạn đã học **Array Partition** - sử dụng sorting. Bài hôm nay **Missing Number** sẽ dạy bạn kỹ thuật XOR để tìm số thiếu trong dãy 0→n. Đây là kỹ thuật bit manipulation quan trọng.

## 2. TODAY'S MISSION

- Tìm số thiếu trong array từ 0 đến n
- Sử dụng XOR để O(1) space
- Hiểu tại sao XOR works

## 3. CONCEPT FOUNDATION

**Missing Number:**
```
Input: [3,0,1]
n = 3, missing = 2

Input: [0,1]
n = 2, missing = 2
```

## 4. TERMINOLOGY EXPLANATION

- **XOR**: Phép toán exclusive OR, same → 0, different → 1
- **Missing**: Số không có trong array

## 5. MAIN CODE

```python
def missing_number(nums):
    """
    Tìm số thiếu
    
    Input: [3,0,1]
    Output: 2
    
    Giải thích:
    - n = 3
    - XOR all: 3⊕0⊕1⊕0⊕1⊕2⊕3 = 2
    """
    missing = len(nums)  # Start với n
    
    for i, num in enumerate(nums):
        missing ^= i ^ num
    
    return missing
```

## 6. EXECUTION TRACE

```
nums = [3, 0, 1], n = 3
missing = 3

i=0, num=3: missing = 3⊕0⊕3 = 0
i=1, num=0: missing = 0⊕1⊕0 = 1  
i=2, num=1: missing = 1⊕2⊕1 = 2

Output: 2 ✓
```

## 7. VISUAL THINKING MODE

```
Property: a ⊕ a = 0
          a ⊕ 0 = a
          
3 ⊕ 0 ⊕ 1 ⊕ 0 ⊕ 1 ⊕ 2 ⊕ 3
= (3⊕3) ⊕ (0⊕0) ⊕ (1⊕1) ⊕ 2
= 0 ⊕ 0 ⊕ 0 ⊕ 2
= 2
```

## 8. DEBUG THINKING MODE

**Lỗi:** Quên XOR với index.

## 9. MEMORY REINFORCEMENT

**Pattern:** `missing = n ^ sum(range(n)) ^ sum(nums)`

## 10-13. Practice

Làm bài tương tự để thành thạo.

---

## Progress

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 471 / 2000 |
| **XP** | +25 |