# Bài 453 — Number of Islands (Medium)

## 1. Ôn tập

Từ bài 452, ta đã học Max Area of Island. Hôm nay ta học **Number of Islands**!

## 2. Mục tiêu bài học

- Đếm số islands trong grid
- Mark visited cells
- DFS/BFS

## 3. Code chính (có comment)

```python
def num_islands(grid):
    """
    Number of Islands
    Input: grid=[['1','1'],['2','2']]
    Output: 2
    """
    if not grid:
        return 0
    
    count = 0
    
    def dfs(r, c):
        if r < 0 or r >= len(grid) or c < 0 or c >= len(grid[0]):
            return
        if grid[r][c] == '0':
            return
        
        grid[r][c] = '0'
        dfs(r+1, c)
        dfs(r-1, c)
        dfs(r, c+1)
        dfs(r, c-1)
    
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            if grid[r][c] == '1':
                count += 1
                dfs(r, c)
    
    return count
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 453 / 2000 |
| **Chapter** | DFS/BFS |
| **XP** | 4530 |