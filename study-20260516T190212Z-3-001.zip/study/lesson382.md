# Bài 382 — Find All Anagrams in a String (Medium)

## 1. Ôn tập

Từ bài 381, ta đã học Longest Substring. Hôm nay ta học **Find All Anagrams**!

## 2. Mục tiêu bài học

- Tìm tất cả anagram positions
- Sliding window + Counter
- O(n)

## 3. Code chính (có comment)

```python
def find_anagrams(s, p):
    """
    Find Anagrams
    Input: s="cbaebabacd", p="abc"
    Output: [0,6] ("cba", "bac")
    """
    from collections import Counter
    
    p_count = Counter(p)
    s_count = Counter()
    result = []
    
    for i in range(len(s)):
        s_count[s[i]] += 1
        
        if i >= len(p):
            if s_count[s[i - len(p)]] == 1:
                del s_count[s[i - len(p)]]
            else:
                s_count[s[i - len(p)]] -= 1
        
        if s_count == p_count:
            result.append(i - len(p) + 1)
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 382 / 2000 |
| **Chapter** | Sliding Window |
| **XP** | 3820 |