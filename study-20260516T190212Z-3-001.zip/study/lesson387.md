# Bài 387 — First Unique Character (Easy)

## 1. Ôn tập

Từ bài 386, ta đã học Intersection II. Hôm nay ta học **First Unique Character**!

## 2. Mục tiêu bài học

- Tìm first non-repeating character
- Counter để đếm
- O(n)

## 3. Code chính (có comment)

```python
def first_unique_char(s):
    """
    First Unique Character
    Input: s="leetcode"
    Output: 0 ('l')
    """
    from collections import Counter
    
    count = Counter(s)
    
    for i, char in enumerate(s):
        if count[char] == 1:
            return i
    
    return -1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 387 / 2000 |
| **Chapter** | String |
| **XP** | 3870 |