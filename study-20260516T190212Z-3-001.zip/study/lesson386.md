# Bài 386 — Intersection of Two Arrays II (Easy)

## 1. Ôn tập

Từ bài 385, ta đã học Find Duplicate. Hôm nay ta học **Intersection II**!

## 2. Mục tiêu bài học

- Tìm intersection với duplicates
- Counter approach
- O(n+m)

## 3. Code chính (có comment)

```python
from collections import Counter

def intersect(nums1, nums2):
    """
    Intersection II
    Input: [1,2,2,1], [2,2]
    Output: [2,2]
    """
    count1 = Counter(nums1)
    result = []
    
    for num in nums2:
        if count1[num] > 0:
            result.append(num)
            count1[num] -= 1
    
    return result
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 386 / 2000 |
| **Chapter** | Array |
| **XP** | 3860 |