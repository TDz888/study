# Bài 410 — Search in BST (Easy)

## 1. Ôn tập

Từ bài 409, ta đã học Delete Node. Hôm nay ta học **Search in BST**!

## 2. Mục tiêu bài học

- Tìm node với value trong BST
- Leverage BST property
- O(h)

## 3. Code chính (có comment)

```python
def search_bst(root, val):
    """
    Search in BST
    Input: root, val
    Output: Node hoặc None
    """
    while root and root.val != val:
        if val < root.val:
            root = root.left
        else:
            root = root.right
    return root
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 410 / 2000 |
| **Chapter** | Trees |
| **XP** | 4100 |