# Lesson 52 — Advanced Dictionary Operations

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 51 - Advanced List Operations.

**Current Lesson:** Learning **Advanced Dictionary Operations** — powerful tools for data manipulation.

**Why This Matters:**
- Dictionaries are essential for real-world data processing
- defaultdict avoids repetitive None-checking
- Counter provides instant analytics
- Dict comprehension enables elegant transformations

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master today:**
- defaultdict: automatic default value creation
- OrderedDict: maintain insertion order with special methods
- Counter: advanced counting and analytics
- Dict comprehension: transform dictionaries elegantly

**Real-world analogy:**
- defaultdict: like a filing cabinet that creates folders automatically
- Counter: like a tally counter that tracks occurrences

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### 1. Defaultdict — Automatic Default Values

```python
from collections import defaultdict

# defaultdict(list) - creates empty list for new keys
fruits = defaultdict(list)
fruits["tropical"].append("mango")
fruits["tropical"].append("banana")
fruits["citrus"].append("orange")
print(fruits)
# {'tropical': ['mango', 'banana'], 'citrus': ['orange']}

# defaultdict(int) - creates 0 for new keys (perfect for counting)
word_counts = defaultdict(int)
words = ["apple", "banana", "apple", "cherry", "banana", "apple"]
for word in words:
    word_counts[word] += 1
print(dict(word_counts))
# {'apple': 3, 'banana': 2, 'cherry': 1}

# defaultdict(set) - creates empty set for unique collections
category_items = defaultdict(set)
category_items["colors"].add("red")
category_items["colors"].add("blue")
category_items["colors"].add("red")  # Ignored - already exists
print(dict(category_items))
# {'colors': {'blue', 'red'}}

# Using lambda for custom default
custom = defaultdict(lambda: "N/A")
custom["missing"]  # Returns "N/A"
```

### 2. OrderedDict — Special Ordered Dictionary

```python
from collections import OrderedDict

# In Python 3.7+, regular dict already maintains order!
# OrderedDict provides additional methods

od = OrderedDict()
od["first"] = 1
od["second"] = 2
od["third"] = 3
print(list(od.keys()))  # ['first', 'second', 'third']

# move_to_end: move key to the end
od.move_to_end("first")
print(list(od.keys()))  # ['second', 'third', 'first']

# move to beginning
od.move_to_end("second", last=False)
print(list(od.keys()))  # ['second', 'third', 'first']

# popitem with last=True/False
od.popitem(last=True)   # Removes last: 'first'
od.popitem(last=False)  # Removes first: 'second'
```

### 3. Counter — Advanced Counting

```python
from collections import Counter

# Basic counting
colors = Counter(["red", "blue", "red", "green", "blue", "blue"])
print(colors)  # Counter({'blue': 3, 'red': 2, 'green': 1})

# most_common(n) - top n most frequent
print(colors.most_common(2))  # [('blue', 3), ('red', 2)]

# elements() - expand into individual elements
print(list(colors.elements()))
# ['red', 'red', 'blue', 'blue', 'blue', 'green']

# Mathematical operations
c1 = Counter(a=3, b=1, c=2)
c2 = Counter(a=1, b=2, d=5)

# Addition: keeps maximum of each key
print(c1 + c2)  # Counter({'a': 4, 'b': 3, 'c': 2, 'd': 5})

# Subtraction: keeps only positive values
print(c1 - c2)  # Counter({'a': 2, 'c': 2})

# Intersection: keeps minimum
print(c1 & c2)  # Counter({'a': 1, 'b': 1})

# Union: keeps maximum
print(c1 | c2)  # Counter({'a': 3, 'b': 2, 'c': 2, 'd': 5})
```

### 4. Dict Comprehension — Transform Dictionaries

```python
# Create dict from two lists
keys = ["a", "b", "c"]
values = [1, 2, 3]
d = {k: v for k, v in zip(keys, values)}
print(d)  # {'a': 1, 'b': 2, 'c': 3}

# Filter dict by value
scores = {"Alice": 95, "Bob": 82, "Charlie": 78, "Diana": 88}
passing = {k: v for k, v in scores.items() if v >= 80}
print(passing)  # {'Alice': 95, 'Bob': 82, 'Diana': 88}

# Invert key-value pairs
original = {"a": 1, "b": 2, "c": 3}
inverted = {v: k for k, v in original.items()}
print(inverted)  # {1: 'a', 2: 'b', 3: 'c'}

# Initialize empty lists for each key
categories = defaultdict(list)
for category in ["fruits", "vegetables", "fruits"]:
    categories[category].append(category)

# Dict comprehension with condition
data = {"x": 1, "y": -2, "z": 3, "w": -1}
positive = {k: abs(v) for k, v in data.items() if v < 0}
print(positive)  # {'y': 2, 'w': 1}
```

-------------------------------------------------------------------------------
4. EXECUTION TRACE
-------------------------------------------------------------------------------

### Trace: defaultdict(int) Counting

```
words = ["apple", "banana", "apple"]

d = defaultdict(int)

Step 1: word = "apple"
  d["apple"] += 1
  "apple" not in d → create with default 0
  d["apple"] = 0 + 1 = 1

Step 2: word = "banana"
  d["banana"] += 1
  "banana" not in d → create with default 0
  d["banana"] = 0 + 1 = 1

Step 3: word = "apple"
  d["apple"] += 1
  "apple" exists → d["apple"] = 1 + 1 = 2

Result: {'apple': 2, 'banana': 1} ✓
```

### Trace: Counter Operations

```
c1 = Counter(a=3, b=1)
c2 = Counter(a=1, b=2, c=3)

c1 + c2 (addition):
  a: max(3,1) = 3
  b: max(1, 2) = 2
  c: 0 + 3 = 3
  Result: {'a': 3, 'b': 2, 'c': 3} ✓

c1 - c2 (subtraction):
  a: 3 - 1 = 2 (keep)
  b: 1 - 2 = -1 (discard)
  c: 0 - 3 = -3 (discard)
  Result: {'a': 2} ✓
```

-------------------------------------------------------------------------------
5. DEBUG THINKING MODE
-------------------------------------------------------------------------------

### Common Mistake 1: Using Regular Dict

```python
# ❌ WRONG - Crashes on missing key!
d = {}
d["missing"]  # KeyError!

# ✅ CORRECT - Use defaultdict
d = defaultdict(int)
d["missing"]  # Returns 0, no error
```

### Common Mistake 2: OrderedDict in Python 3.7+

```python
# ❌ UNNECESSARY - Regular dict maintains order
d = OrderedDict()
d["a"] = 1
d["b"] = 2
# Just use:
d = {}
d["a"] = 1
d["b"] = 2  # Already ordered!

# Only use OrderedDict if you need move_to_end() or popitem(last=False)
```

### Common Mistake 3: Counter Subtraction

```python
# ❌ WRONG - Negative values are discarded!
c1 = Counter(a=1, b=2)
c2 = Counter(a=5, b=1)
print(c1 - c2)  # Counter() - all values become negative!

# ✅ CORRECT - Use mathematical_max for proper subtraction
# Or manually handle:
result = Counter()
for key in c1:
    result[key] = max(0, c1[key] - c2.get(key, 0))
```

-------------------------------------------------------------------------------
6. MINI TEST
-------------------------------------------------------------------------------

### Question 1: Counting with defaultdict

**What is the output?**
```python
from collections import defaultdict
d = defaultdict(int)
for word in ["cat", "dog", "cat"]:
    d[word] += 1
print(dict(d))
```

> **Answer:** {'cat': 2, 'dog': 1}

---

### Question 2: most_common

**What does `Counter(['a','b','a']).most_common(1)` return?**

> **Answer:** [('a', 1)]
> 
> Returns list of tuples with most frequent element

---

### Question 3: Dict Comprehension

**How to invert a dictionary (key→value, value→key)?**

> **Answer:** `{v: k for k, v in d.items()}`

-------------------------------------------------------------------------------
7. LEETCODE PRACTICE
-------------------------------------------------------------------------------

### Problem: Most Common Character

**Solution:**
```python
from collections import Counter

s = input()
c = Counter(s)
most = c.most_common(1)
print(most[0][0])

# Challenge: Group words by length
words = ["cat", "dog", "elephant", "ant", "bat"]
from collections import defaultdict
grouped = defaultdict(list)
for word in words:
    grouped[len(word)].append(word)
print(dict(grouped))
```

-------------------------------------------------------------------------------
8. LESSON REFLECTION
-------------------------------------------------------------------------------

### What You Learned

1. **defaultdict** - automatic default values
2. **OrderedDict** - special order methods (rarely needed in Python 3.7+)
3. **Counter** - powerful counting and analysis
4. **Dict Comprehension** - transform dictionaries elegantly

### Key Takeaways

- defaultdict avoids repetitive None-checking
- Counter.most_common() finds top elements
- Dict comprehension is powerful for transformations

---

## Progress

| Field | Value |
|-------|-------|
| **Lesson** | 52 / 2000 |
| **XP** | 520 |

---

**Type 53 to continue**