# Bài 464 — Duplicate Zeros (Easy)

## 1. Ôn tập

Từ bài 463, ta đã học Squares of Sorted Array. Hôm nay ta học **Duplicate Zeros**!

## 2. Mục tiêu bài học

- Duplicate mỗi zero
- In-place shift
- Two pass

## 3. Code chính (có comment)

```python
def duplicate_zeros(arr):
    """
    Duplicate Zeros
    Input: [1,0,2,3,0,4,0,0]
    Output: [1,0,0,2,0,3,0,0]
    """
    i = 0
    extra_space = 0
    
    # First pass: calculate extra space needed
    while i + extra_space < len(arr):
        if arr[i] == 0:
            extra_space += 1
        i += 1
    
    # Second pass: from end
    i -= 1
    while i >= 0:
        if i + extra_space < len(arr):
            arr[i + extra_space] = arr[i]
            if arr[i] == 0:
                arr[i + extra_space - 1] = 0
                extra_space -= 1
        i -= 1
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 464 / 2000 |
| **Chapter** | Array |
| **XP** | 4640 |