# Bài 313 — Target Sum (Medium)

## 1. Ôn tập

Từ bài 312, ta đã học Decode Ways. Hôm nay ta học **Target Sum**!

## 2. Mục tiêu bài học

- Assign + hoặc - để sum = target
- Transform thành subset sum problem
- dp[sum] = ways

## 3. Code chính (có comment)

```python
def find_target_sum_ways(nums, target):
    """
    Target Sum
    Input: nums=[1,1,1,1], target=1
    Output: 5 (-1+1+1+1, +1-1+1+1, +1+1-1+1, +1+1+1-1, -1-1+1+1)
    """
    total = sum(nums)
    
    # Transform: P - N = target, P + N = sum(nums)
    # P = (target + sum) / 2
    
    if abs(target) > total:
        return 0
    if (target + total) % 2 == 1:
        return 0
    
    subset_sum = (target + total) // 2
    
    # Count subsets với sum = subset_sum
    dp = [0] * (subset_sum + 1)
    dp[0] = 1
    
    for num in nums:
        for i in range(subset_sum, num - 1, -1):
            dp[i] += dp[i - num]
    
    return dp[subset_sum]
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 313 / 2000 |
| **Chapter** | Dynamic Programming |
| **XP** | 3130 |