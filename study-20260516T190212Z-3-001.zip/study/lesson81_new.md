# Lesson 81 — Heap / Priority Queue

-------------------------------------------------------------------------------
1. KNOWLEDGE CONNECTION
-------------------------------------------------------------------------------

**Previous Lesson:** Lesson 80 - Binary Search Tree.

**Current Lesson:** Learning **Heap** — priority queue structure.

-------------------------------------------------------------------------------
2. TODAY'S MISSION
-------------------------------------------------------------------------------

**What you'll master:**
- Heap basics
- heapq module in Python

-------------------------------------------------------------------------------
3. MAIN CODE
-------------------------------------------------------------------------------

### Basic Heap (Min Heap)

```python
import heapq

# Create heap
heap = []

# Add elements
heapq.heappush(heap, 5)
heapq.heappush(heap, 2)
heapq.heappush(heap, 8)
heapq.heappush(heap, 1)

print(heap)  # [1, 2, 8, 5]

# Pop smallest
print(heapq.heappop(heap))  # 1
print(heapq.heappop(heap))  # 2
```

### Heap from List

```python
import heapq

# Create heap from list
arr = [5, 2, 8, 1, 9]
heapq.heapify(arr)
print(arr)  # [1, 2, 8, 5, 9]

# Heap sort
heapq.heapify(arr)
sorted_arr = []
while arr:
    sorted_arr.append(heapq.heappop(arr))
print(sorted_arr)  # [1, 2, 5, 8, 9]
```

### Max Heap (using negative)

```python
import heapq

heap = []
heapq.heappush(heap, -5)  # -5 for max
heapq.heappush(heap, -2)
heapq.heappush(heap, -8)

print(-heapq.heappop(heap))  # 8 (largest)
```

-------------------------------------------------------------------------------
4. MINI TEST
-------------------------------------------------------------------------------

### Question

**What does heapq.heappush do?**

> **Answer:** Adds element while maintaining heap property

---

**Type 82 to continue**