# Bài 207 — LeetCode: Valid Parentheses (Easy)

## 1. Ôn tập

Từ bài 205-206, ta đã học DP và one-pass algorithms. Hôm nay ta học **Stack** - cấu trúc dữ liệu hoàn hảo cho bài parentheses!

## 2. Mục tiêu bài học

- Kiểm tra chuỗi ngoặc hợp lệ
- Dùng Stack để matching
- Hiểu LIFO principle

## 3. Code chính (có comment)

```python
def is_valid(s: str) -> bool:
    """
    Kiểm tra chuỗi ngoặc có hợp lệ không
    Input: "()[]{}" → True
    Input: "(]" → False
    
    Stack approach:
    - Push khi gặp opening
    - Pop và check match khi gặp closing
    """
    stack = []
    mapping = {')': '(', ']': '[', '}': '{'}
    
    for char in s:
        if char in mapping:
            # Là closing bracket
            if not stack or stack[-1] != mapping[char]:
                return False
            stack.pop()
        else:
            # Là opening bracket
            stack.append(char)
    
    # Stack rỗng = valid
    return len(stack) == 0

# Test
print(is_valid("()[]{}"))  # True
print(is_valid("(]"))      # False
print(is_valid("([)]"))    # False
print(is_valid("{[]}"))     # True
```

## 4. Trace chạy code

```
s = "{[]}"

char='{': opening → stack=['{']
char='[': opening → stack=['{', '[']
char=']': closing → stack[-1]='[' matches → pop → stack=['{']
char='}': closing → stack[-1]='{' matches → pop → stack=[]

Stack empty → return True
```

## 5. Debug tư duy

### Cần mapping cho closing → opening!
```python
# Sai: Check char in stack
if char == '(' and stack[-1] == ')':  # Wrong!

# Đúng: Mapping closing to opening
mapping = {')': '(', ']': '[', '}': '{'}
if char in mapping:
    # Check match
```

### Stack rỗng khi gặp closing = invalid!
```python
# Input: ")"
# char=')': stack=[] → stack[-1] error!

# Fix:
if not stack or stack[-1] != mapping[char]:
    return False
```

## 6. Ghi nhớ nhanh

| Structure | Use Case |
|----------|----------|
| Stack | Parentheses, undo, DFS |
| Queue | BFS, scheduling |
| Deque | Sliding window |

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 207 / 2000 |
| **XP** | 2070 |