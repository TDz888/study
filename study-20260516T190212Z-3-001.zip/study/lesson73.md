# Bài 73 — Named Tuples

---

## 1. Ôn tập
Học về **Named Tuple**.

---

## 2. Mục tiêu
- Tạo named tuple
- Truy cập fields
- Methods

---

## 3. Named Tuple

```python
from collections import namedtuple

# Định nghĩa
Point = namedtuple('Point', ['x', 'y'])
Person = namedtuple('Person', 'name age city')

# Sử dụng
p = Point(10, 20)
print(p.x, p.y)  # 10 20
print(p[0], p[1])  # 10 20

person = Person("Alice", 25, "NYC")
print(person.name)  # Alice
print(person._fields)  # ('name', 'age', 'city')
```

---

## 4. Methods

```python
# _asdict - chuyển thành dict
print(person._asdict())  # {'name': 'Alice', 'age': 25, 'city': 'NYC'}

# _replace - tạo bản mới
new_person = person._replace(age=26)
print(new_person)  # Person(name='Alice', age=26, city='NYC')

# _make - tạo từ iterable
data = ["Bob", 30, "LA"]
person2 = Person._make(data)
print(person2)  # Person(name='Bob', age=30, city='LA')
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 73 / 2000 |
| **XP** | 730 |
| **Level** | Intermediate |