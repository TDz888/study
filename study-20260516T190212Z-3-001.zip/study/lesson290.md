# Bài 290 — Validate Binary Search Tree (Medium)

## 1. Ôn tập

Từ bài 289, ta đã học Subtree of Another Tree. Hôm nay ta học **validate BST**!

## 2. Mục tiêu bài học

- Kiểm tra tree có phải BST không
- Left < root < Right cho mọi node
- Dùng min/max bounds

## 3. Code chính (có comment)

```python
def is_valid_bst(root):
    """
    Validate BST
    Input: Tree
    Output: True nếu là BST
    """
    def validate(node, min_val, max_val):
        if not node:
            return True
        
        # Kiểm tra bounds
        if node.val <= min_val or node.val >= max_val:
            return False
        
        # Recursively check left và right
        return (validate(node.left, min_val, node.val) and
                validate(node.right, node.val, max_val))
    
    return validate(root, float('-inf'), float('inf'))
```

---

## Tiến độ

| Thông tin | Giá trị |
|-----------|---------|
| **Lesson** | 290 / 2000 |
| **Chapter** | Trees |
| **XP** | 2900 |